/* WANDERQUEST v3.0 — game engine. Depends on content.js and art.js. */
(() => {
"use strict";

/* ===================== helpers ===================== */
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const fill = (str, vars) => String(str).replace(/\{(\w+)\}/g, (_, k) => vars && vars[k] !== undefined ? vars[k] : "{"+k+"}");
const clone = o => JSON.parse(JSON.stringify(o));
const shuffle = a => { for (let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a; };

/* storage that never throws (private mode / blocked storage => in-memory) */
const store = (() => {
  let ok = true; const mem = {};
  try { const k="__wq_probe"; window.localStorage.setItem(k,"1"); window.localStorage.removeItem(k); } catch(e){ ok = false; }
  return {
    ok,
    get(k){ try { return ok ? window.localStorage.getItem(k) : (k in mem ? mem[k] : null); } catch(e){ return k in mem ? mem[k] : null; } },
    set(k,v){ mem[k]=v; try { if (ok) window.localStorage.setItem(k,v); } catch(e){ /* quota or blocked */ } },
    del(k){ delete mem[k]; try { if (ok) window.localStorage.removeItem(k); } catch(e){} }
  };
})();

const KEY = "wanderquest-v3-save";
function freshState(){
  return { v:3, lang:null, name:"", nat:"", natOther:"", registered:false, pid:"WQ-"+Math.random().toString(36).slice(2,8).toUpperCase(),
    screen:"lang", scene:"map", flags:{}, bag:[], clues:[], seen:[], hints:{}, tries:{},
    jig:null, logic:Array(16).fill(0), ov:{...OVERLAY.start}, potSeq:[], gateSel:[], st:{}, hIdx:0,
    t0:null, tEnd:null, ev:[] };
}
function loadState(){
  const base = freshState();
  try {
    const raw = store.get(KEY); if (!raw) return base;
    const s = JSON.parse(raw); if (!s || s.v !== 3) return base;
    const m = Object.assign(base, s);
    if (!Array.isArray(m.logic) || m.logic.length !== 16) m.logic = Array(16).fill(0);
    if (m.jig && !(Array.isArray(m.jig.board) && m.jig.board.length===16 && Array.isArray(m.jig.tray) && m.jig.tray.length===2 &&
        [...m.jig.board, ...m.jig.tray].slice().sort((a,b)=>a-b).every((v,i)=>v===i))) m.jig = null;
    ["bag","clues","seen","potSeq","gateSel","ev"].forEach(k => { if (!Array.isArray(m[k])) m[k] = []; });
    if (!m.ov || typeof m.ov.x !== "number" || typeof m.ov.k !== "number") m.ov = {...OVERLAY.start};
    if (!m.st || typeof m.st !== "object") m.st = {};
    if (m.screen === "story") m.screen = "tutorial";   // prologue video removed in v3.1
    if (m.screen === "history") m.hIdx = 0;
    if (m.screen === "profile") m.screen = "register";
    if (!m.registered && ["history","tutorial","game"].includes(m.screen)) m.screen = "register";
    if (!["lang","register","history","tutorial","game"].includes(m.screen)) m.screen = m.lang ? "game" : "lang";
    if (!m.lang) m.screen = "lang";
    return m;
  } catch(e){ return base; }
}
let S = loadState();
function save(){ store.set(KEY, JSON.stringify(S)); }
function logEv(type, data){ S.ev.push({t:Date.now(), type, data: data ?? ""}); if (S.ev.length > 400) S.ev.splice(0, S.ev.length-400); save(); }

/* ===================== i18n ===================== */
const lang = () => S.lang === "en" ? "en" : "zh";
const t = (k, vars) => { const v = UI[lang()][k]; if (v === undefined) { console.warn("missing UI key", k); return k; } return fill(v, vars); };
const L = (o, vars) => o ? fill(o[lang()] ?? o.zh, vars) : "";
const itemName = id => id === "acorn" ? t("tutAcorn") : L(ITEMS[id]);

/* ===================== puzzle logic (data-driven) ===================== */
function perms(n){ if (n===1) return [[0]]; const out=[]; perms(n-1).forEach(p=>{ for(let i=0;i<=p.length;i++){ const q=p.slice(); q.splice(i,0,n-1); out.push(q);} }); return out; }
function solveLogic(){ // returns every assignment person->thing consistent with ALL clues
  const forb = new Set(); LOGIC.clues.forEach(c => c.forbid.forEach(([p,th]) => forb.add(p+","+th)));
  return perms(LOGIC.people.length).filter(a => a.every((th,p) => !forb.has(p+","+th)));
}
const LOGIC_SOLUTIONS = solveLogic();
if (LOGIC_SOLUTIONS.length !== 1) console.error("Logic puzzle does not have a unique solution!", LOGIC_SOLUTIONS);
const LOGIC_ANSWER = LOGIC_SOLUTIONS[0];   // e.g. [0,1,2,3]: tea master->basket, traveler->map, maintenance->compass, porter->lantern

/* ===================== state helpers ===================== */
const F = k => !!S.flags[k];
const has = id => S.bag.includes(id);
function setFlag(k){ if (!S.flags[k] && (k === "logic" || k === "gate")) timeTick(); if (!S.flags[k]) { S.flags[k] = true; S.flags[k+"At"] = Date.now(); logEv("solved", k); save(); if (k === "logic") placeReported("station"); if (k === "gate") placeReported("valley"); } save(); }
function award(id){ if (!has(id)) { S.bag.push(id); logEv("item", id); toast(t("gotItem",{item:itemName(id)})); save(); } }
function addClue(id){ if (!S.clues.includes(id)) { S.clues.push(id); logEv("clue", id); save(); return true; } return false; }
function markSeen(id){ if (!S.seen.includes(id)) { S.seen.push(id); logEv("inspect", id); save(); } }
function tryCount(k){ S.tries[k] = (S.tries[k]||0) + 1; logEv("attempt", k); save(); }

function objective(){
  if (isGeneric(S.scene)) return placeDone(S.scene) ? t2("stnObjDone") : L(STN[S.scene].obj);
  if (S.scene === "map" && F("gate") || (S.scene === "map" && F("logic") && suggestedNext() && suggestedNext() !== "valley")) { const n = suggestedNext(); return n ? t2("mapNext",{name:nodeName(n)}) : t2("allDoneObj"); }
  if (S.scene === "valley" && F("gate")) { const n = suggestedNext(); return n ? t2("mapNext",{name:nodeName(n)}) : t2("allDoneObj"); }
  if (!F("jig")) return S.scene === "station" ? L(OBJ.jig) : L(OBJ.enterStation);
  if (!F("logic")) return L(OBJ.logic, {n:S.clues.length});
  if (S.scene !== "valley" && !F("plateUsed")) return L(OBJ.toValley);
  if (!F("plateUsed")) return L(OBJ.plate);
  if (!F("overlay")) return L(OBJ.overlay);
  if (!F("pot")) return L(OBJ.pot);
  if (!F("gate")) return L(OBJ.gate);
  return L(OBJ.done);
}
/* The ONE thing the player should tap next (where to go — never the puzzle answer). */
function nextTarget(){
  if (S.scene === "map") { const n = suggestedNext(); return n ? "node-"+n : null; }
  if (isGeneric(S.scene)) { if (placeDone(S.scene)) return "btn-stn-map"; const s = STN[S.scene];
    const unseen = s.hots.find(h => h.doc && !S.seen.includes(S.scene+":"+h.id)); return "hot-" + (unseen ? unseen.id : s.hots.find(h=>h.mech).id); }
  if (S.scene === "station") {
    if (!F("jig")) return "hot-frame";
    if (F("logic")) return "btn-go-valley";
    if (!S.clues.includes("c4")) return "hot-board";
    if (!S.clues.includes("c1") || !S.clues.includes("c2")) return "hot-log";
    if (!S.clues.includes("c3")) return "hot-porter";
    return "hot-cabinet";
  }
  if (S.scene === "valley") {
    if (!F("overlay")) return "hot-oldmap";
    if (!F("pot")) return "hot-potfield";
    if (!F("gate")) return "hot-gate";
  }
  return null;
}
function hintKey(){
  if (isGeneric(S.scene)) return placeDone(S.scene) ? null : "stn";
  if (S.scene === "map" && F("logic")) { const n = suggestedNext(); if (n && n !== "valley") return null; }
  if (!F("jig")) return "jigsaw";
  if (!F("logic")) return "logic";
  if (!F("plateUsed")) return S.scene === "valley" ? "plate" : "toValley";
  if (!F("overlay")) return "overlay";
  if (!F("pot")) return "potholes";
  if (!F("gate")) return "gate";
  return null;
}
function hintList(key){
  if (key === "stn") return STN[S.scene].hints[lang()].slice();
  const base = HINTS[key][lang()].slice();
  if (key === "overlay") { // third level generated from the same data the puzzle uses
    const r = (4 - OVERLAY.start.k % 4) % 4, dx = -OVERLAY.start.x, dy = -OVERLAY.start.y, zh = lang()==="zh";
    const parts = [];
    if (r) parts.push(zh ? `按 ↻ 旋轉 ${r} 次（讓北方箭頭朝上）` : `press ↻ ${r} time(s) (so the north arrow points up)`);
    if (dx) parts.push(zh ? (dx>0?`向右移 ${dx} 格`:`向左移 ${-dx} 格`) : (dx>0?`move ${dx} step(s) right`:`move ${-dx} step(s) left`));
    if (dy) parts.push(zh ? (dy<0?`向上移 ${-dy} 格`:`向下移 ${dy} 格`) : (dy<0?`move ${-dy} step(s) up`:`move ${dy} step(s) down`));
    base.push(zh ? `從起始狀態：${parts.join("，再")}。` : `From the starting position: ${parts.join(", then ")}.`);
  }
  if (key === "potholes") {
    const o = POTHOLES.order;
    base.push(lang()==="zh" ? `${o[0]} 最老；${o[1]} 切過 ${o[0]}；${o[2]} 切過 ${o[1]}；${o[3]} 切過 ${o[2]}。順序是 ${o.join(" → ")}。`
                            : `${o[0]} is oldest; ${o[1]} cuts ${o[0]}; ${o[2]} cuts ${o[1]}; ${o[3]} cuts ${o[2]}. The order is ${o.join(" → ")}.`);
  }
  return base;
}

/* ===================== DOM roots ===================== */
const root = document.getElementById("root");
const modalRoot = document.getElementById("modal");
let M = null;          // current modal descriptor {type, arg, fb}
let SEL = null;        // jigsaw selection (transient)
let TUT = null;        // tutorial state (transient)
let storyTimer = null, storyElapsed = 0, storyPaused = false, voice = false, spoken = -1;

function toast(msg){
  const el = document.getElementById("toast"); el.textContent = msg; el.classList.add("show");
  clearTimeout(toast._t); toast._t = setTimeout(() => el.classList.remove("show"), 2800);
}

/* ===================== shared components (also used by the tutorial) ===================== */
function topbar(opts = {}){
  const tut = !!opts.tutorial;
  const bagCount = tut ? (TUT && TUT.acorn ? 1 : 0) : S.bag.length;
  const pulse = k => (tut && TUT && TUT.pulse === k) ? " pulse-target" : "";
  return `<header class="topbar">
    <div class="brand">🍄 <span class="bw">WANDERQUEST</span> <small>${esc(t("brandSub"))}</small></div>
    <button data-act="${tut?"tutNoop":"goMap"}" id="btn-map" aria-label="${esc(t("btnMap"))}">🗺️ <span class="lbl-txt">${esc(t("btnMap"))}</span></button>
    <button class="bag-btn${pulse("bag")}" data-act="${tut?"tutBag":"openBag"}" aria-label="${esc(t("btnBag"))}" id="btn-bag">🎒 <span class="lbl-txt">${esc(t("btnBag"))}</span>${bagCount?`<span class="count">${bagCount}</span>`:""}</button>
    <button class="${pulse("npc").trim()}" data-act="${tut?"tutHint":"openHint"}" aria-label="${esc(t("btnHint"))}" id="btn-hint">💡 <span class="lbl-txt">${esc(t("btnHint"))}</span></button>
    <button data-act="toggleLang" aria-label="Language / 語言" id="btn-lang">🌐 ${esc(t("btnLang"))}</button>
    ${tut ? "" : `<button data-act="openMenu" id="btn-menu" aria-label="${esc(t("btnMenu"))}">☰ <span class="lbl-txt">${esc(t("btnMenu"))}</span></button>`}
  </header>`;
}
function hotHTML(h, scene, extra = ""){
  const seen = S.seen.includes(scene+":"+h.id);
  const nxt = !extra && nextTarget() === "hot-"+h.id;
  return `<button class="hot ${seen?"seen":"new"} ${nxt?"next":""} ${extra}" ${nxt?`data-next="👇 ${esc(L(MISC.nextLbl))}"`:""} style="left:${h.x}%;top:${h.y}%" data-act="hot" data-arg="${h.id}" id="hot-${h.id}">
    <span class="ico">${h.ico}</span><span class="htxt">${esc(L(h))}</span></button>`;
}
function npcbar(npc, line, act = "talk", pulseIt = false){
  const img = npc === "pebble" ? IMG.pebble : IMG.mossy;
  const name = L(DIALOGUE[npc].name);
  return `<div class="npcbar"><img src="${img}" alt="${esc(name)}"><p><b>${esc(name)}${lang()==="zh"?"：":": "}</b>${esc(line)}</p>
    <button class="talk btn-gold${pulseIt?" pulse-target":""}" data-act="${act}" data-arg="${npc}" id="btn-talk">💬 ${esc(t("talk"))}</button></div>`;
}
function tileHTML(piece, where, i, kind){
  // kind: "main" (16-piece picture), "practice" (2x2)
  let cls = "tile", style = "";
  if (kind === "practice") { const c = piece % 2, r = Math.floor(piece/2); cls += " pr"; style = `background-size:200% 200%;background-position:${c*100}% ${r*100}%`; }
  else if (piece >= 16) { cls += " dz"+(piece-16); style = "background-size:100% 100%"; }
  else { const c = piece % 4, r = Math.floor(piece/4); cls += " pz"; style = `background-size:400% 400%;background-position:${c*100/3}% ${r*100/3}%`; }
  const sel = SEL && SEL.where === where && SEL.i === i;
  const label = where === "tray" ? (lang()==="zh" ? `候選碎片 ${i+1}` : `Spare piece ${i+1}`) : (lang()==="zh" ? `第 ${Math.floor(i/(kind==="practice"?2:4))+1} 列第 ${i%(kind==="practice"?2:4)+1} 格` : `Row ${Math.floor(i/(kind==="practice"?2:4))+1}, column ${i%(kind==="practice"?2:4)+1}`);
  return `<button class="${cls}${sel?" sel":""}" style="${style}" data-act="${kind==="practice"?"tutTile":"tile"}" data-arg="${where}:${i}" data-piece="${piece}" aria-label="${esc(label)}" aria-pressed="${sel}"></button>`;
}
function docCard(key){
  const d = DOCS[key] || DOCS2[key], c = d[lang()];
  return `<div class="card"><span class="tag ${d.type}">${esc(t(d.type==="fact"?"factTag":"fictionTag"))}</span><h3>${esc(c.t)}</h3><p>${esc(c.b)}</p></div>`;
}
function clueCard(id){
  const c = LOGIC.clues.find(x => x.id === id);
  return `<div class="card clue"><span class="tag fiction">${esc(t("fictionTag"))}</span><p style="margin:.4em 0 0;font-weight:700">“${esc(L(c))}”</p></div>`;
}
function fbHTML(){ return M && M.fb ? `<div class="feedback ${M.fb.cls}" role="status" id="fb">${esc(M.fb.f())}</div>` : ""; }
const setFb = (cls, f) => { if (M) M.fb = {cls, f}; };

/* ===================== screens ===================== */
function render(){
  document.documentElement.lang = lang() === "en" ? "en" : "zh-Hant";
  document.title = lang() === "en" ? "WANDERQUEST · The Memory Network (Playtest)" : "WANDERQUEST · 記憶菌絲（試玩版）";
  if (S.screen !== "story") stopStory();
  const scr = S.screen;
  // every new visit starts with the bilingual language picker, then "welcome back" for returning players
  if (!langChosen()) { root.innerHTML = langScreen(); modalRoot.innerHTML = ""; return; }
  if (scr !== "lang" && scr !== "register" && S.registered && !sessionOK()) { root.innerHTML = loginScreen(); modalRoot.innerHTML = ""; return; }
  if (scr === "lang") root.innerHTML = langScreen();
  else if (scr === "history") root.innerHTML = historyScreen();
  else if (scr === "register") root.innerHTML = registerScreen();
  else if (scr === "story") { root.innerHTML = storyScreen(); startStory(); }
  else if (scr === "tutorial") root.innerHTML = tutorialScreen();
  else root.innerHTML = gameScreen();
  renderModal();
}

function langScreen(){
  return `<div class="overlay"><div class="ob-card" style="text-align:center">
    <div class="ob-kicker">The Memory Network · 記憶菌絲</div>
    <div class="ob-title">WANDERQUEST</div>
    <h2>${esc(UI.en.chooseLang)}</h2>
    <div class="lang-grid">
      <button data-act="pickLang" data-arg="zh" id="pick-zh">繁體中文<small>Traditional Chinese</small></button>
      <button data-act="pickLang" data-arg="en" id="pick-en">English<small>英文</small></button>
    </div>
    <p class="small" style="margin-top:18px">${esc(UI.en.langHint)}</p>
    <p class="small" style="opacity:.6">${VERSION}</p>
  </div></div>`;
}
function profileScreen(){
  return `<div class="overlay"><div class="ob-card">
    <div class="ob-kicker">WANDERQUEST · ${esc(t("brandSub"))}</div>
    <h1 style="color:#fbe9b6">${esc(t("profileTitle"))}</h1>
    <p>${esc(t("profileSub"))}</p>
    <label class="field"><span>${esc(t("nickname"))}</span><input id="in-name" maxlength="24" autocomplete="nickname" placeholder="${esc(t("nickPh"))}" value="${esc(S.name)}"></label>
    <label class="field"><span>${esc(t("region"))}</span><input id="in-region" maxlength="40" placeholder="${esc(t("regionPh"))}" value="${esc(S.region)}"></label>
    <div class="ob-actions">
      <button class="btn-gold" data-act="profileNext" id="btn-profile-next">${esc(t("next"))} →</button>
      <button class="btn-ghost" data-act="backLang">${esc(t("back"))}</button>
    </div></div></div>`;
}
function storyScreen(){
  return `<div class="overlay"><div class="ob-card">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">
      <div class="ob-kicker">${esc(t("storyKicker"))}</div>
      <button class="btn-ghost" style="color:#f3d58f" data-act="storySkip" id="btn-story-skip">${esc(t("skip"))} ⏭</button>
    </div>
    <div class="film s0" id="film">${ART.FILM_SVG}
      <div class="fade-title">THE FADING</div>
      <img class="mossy-in" src="${IMG.mossy}" alt="Mossy">
      <div class="subtitle" id="subtitle" aria-live="polite"></div>
    </div>
    <div class="timebar"><div id="timefill"></div></div>
    <div class="film-controls">
      <button data-act="storyPause" id="btn-pause">${esc(t("pause"))}</button>
      <button data-act="storyReplay">↺ ${esc(t("replay"))}</button>
      <button data-act="storyVoice" id="btn-voice">${esc(voice ? t("voiceOn") : t("voiceOff"))}</button>
    </div>
    <div class="ob-actions hidden" id="story-end">
      <button class="btn-gold" data-act="storySkip" id="btn-to-tutorial">${esc(t("toTutorial"))}</button>
      <button class="btn-ghost" data-act="skipTutorial" id="btn-skip-tutorial">${esc(t("skipAll"))}</button>
    </div></div></div>`;
}
/* Prologue timing: each line stays up for as long as it takes to READ it (or, with voice on,
   until the voice has finished speaking it), then a short breathing pause. No fixed time slots. */
const GAP = 0.7;                                   // pause after a line, seconds
function readDur(text){
  const cjk = (text.match(/[\u3400-\u9fff]/g) || []).length;
  const words = text.replace(/[\u3400-\u9fff]/g, "").split(/\s+/).filter(Boolean).length;
  const s = lang() === "zh" ? 1.0 + cjk * 0.19 : 1.0 + words * 0.33;
  return Math.max(3.0, Math.min(7.5, s));
}
let SL = null;   // {idx, el (seconds into line), voiceDone, voiceAt}
function storyTotal(){ return STORY.reduce((a,s)=>a+readDur(s[lang()])+GAP,0); }
function startStory(){
  stopStory(); storyPaused = false;
  SL = {idx:0, el:0, voiceDone:false, voiceAt:0, done:false};
  showLine();
  let prev = performance.now();
  storyTimer = setInterval(() => {
    const now = performance.now(), dt = Math.min(0.5, (now - prev)/1000); prev = now;
    if (storyPaused || !SL || SL.done) return;
    SL.el += dt;
    const text = STORY[SL.idx][lang()], est = readDur(text);
    let finished;
    if (voice && "speechSynthesis" in window) finished = (SL.voiceDone && SL.el >= SL.voiceAt + GAP && SL.el >= 1.5) || SL.el >= est*2.2 + 2;
    else finished = SL.el >= est + GAP;
    if (finished) {
      if (SL.idx < STORY.length - 1) { SL.idx++; SL.el = 0; SL.voiceDone = false; showLine(); }
      else { SL.done = true; const e = document.getElementById("story-end"); if (e) e.classList.remove("hidden"); }
    }
    updateBar();
  }, 100);
}
function showLine(){
  const film = document.getElementById("film"); if (!film || !SL) return;
  film.className = "film s" + SL.idx;
  const line = STORY[SL.idx][lang()];
  document.getElementById("subtitle").textContent = line;
  speak(line);
  updateBar();
}
function updateBar(){
  const fillEl = document.getElementById("timefill"); if (!fillEl || !SL) return;
  let before = 0; for (let i=0;i<SL.idx;i++) before += readDur(STORY[i][lang()]) + GAP;
  const cur = readDur(STORY[SL.idx][lang()]) + GAP;
  const pct = SL.done ? 100 : (before + Math.min(SL.el, cur)) / storyTotal() * 100;
  fillEl.style.width = pct + "%";
}
function pickVoice(){
  const vs = window.speechSynthesis.getVoices().filter(v => v.lang.toLowerCase().replace("_","-").startsWith(lang()==="zh" ? "zh" : "en"));
  const pref = lang()==="zh" ? vs.filter(v => /tw|hant/i.test(v.lang)) : vs.filter(v => /us|gb/i.test(v.lang));
  const pool = pref.length ? pref : vs;
  return pool.find(v => /female|mei-?jia|hsiao|hanhan|xiaoxiao|samantha|jenny|aria|zira|serena|karen|google/i.test(v.name)) || pool[0] || null;
}
function speak(text){
  if (!voice || !("speechSynthesis" in window)) return;
  const myLine = SL ? SL.idx : -1;
  const go = () => {
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text); u.lang = lang()==="zh" ? "zh-TW" : "en-US"; u.rate = 0.95; u.pitch = 1.1;
      const v = pickVoice(); if (v) u.voice = v;
      const finish = () => { if (SL && SL.idx === myLine && !SL.voiceDone) { SL.voiceDone = true; SL.voiceAt = SL.el; } };
      u.onend = finish; u.onerror = finish;
      window.speechSynthesis.speak(u);
    } catch(e){ if (SL) { SL.voiceDone = true; SL.voiceAt = SL.el; } }
  };
  if (window.speechSynthesis.getVoices().length) go();
  else { let fired = false; const once = () => { if (fired) return; fired = true; go(); };
         window.speechSynthesis.addEventListener("voiceschanged", once, {once:true}); setTimeout(once, 600); }
}
function stopStory(){ if (storyTimer) { clearInterval(storyTimer); storyTimer = null; } try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch(e){} }

/* ---------- tutorial (uses the same components as the real game) ---------- */
function startTutorial(){ TUT = {step:0, acorn:false, puz:[3,1,2,0], pulse:null}; S.screen = "tutorial"; save(); render(); }
function tutorialScreen(){
  if (!TUT) TUT = {step:0, acorn:false, puz:[3,1,2,0], pulse:null};
  const st = TUT.step; TUT.pulse = st===2 ? "bag" : st===4 ? "npc" : null;
  let body = "";
  if (st === 0) {
    body = `<div class="worldmap" style="max-width:760px;margin:0 auto">${ART.MAP_SVG}
      <button class="node open next" data-next="👇 ${esc(L(MISC.nextLbl))}" style="left:47%;top:48%" data-act="tutNode" id="tut-node"><span class="dot">🌱</span><span class="lbl">${esc(L(MISC.tutGrove))}</span></button></div>`;
  } else {
    const hot = {id:"stump", x:30, y:62, ico:"🪵", zh:UI.zh.tutStump, en:UI.en.tutStump};
    body = `<div class="scene-head"><div><span class="chapter">${esc(t("tutBanner"))}</span><h1>${esc(t("tutScene"))}</h1></div></div>
      <div class="scenebox" style="max-width:760px;margin:10px auto">${ART.VALLEY_SVG}
        <button class="hot ${TUT.acorn?"seen":"new"} ${st===1?"next":""}" ${st===1?`data-next="👇 ${esc(L(MISC.nextLbl))}"`:""} style="left:${hot.x}%;top:${hot.y}%" data-act="tutHot" id="tut-hot"><span class="ico">${hot.ico}</span><span class="htxt">${esc(L(hot))}</span></button>
      </div>
      ${st >= 3 ? `<div class="card"><h3>🧩 ${esc(t("tutPuzzle"))}</h3><div class="board n2" id="tut-board">${TUT.puz.map((p,i)=>tileHTML(p,"board",i,"practice")).join("")}</div></div>` : ""}
      ${npcbar("mossy", TUT_LINE(), "tutTalk", st===4)}
      ${st === 5 ? `<div class="card" style="text-align:center"><p><b>${esc(t("tutDone"))}</b></p><button class="btn-primary" data-act="tutFinish" id="btn-tut-go">${esc(t("tutGo"))}</button></div>` : ""}`;
  }
  return `<div class="app"><div class="tut-banner">${esc(t("tutBanner"))}</div>${topbar({tutorial:true})}
    <main class="view">${body}<div style="height:110px"></div></main></div>
    <div class="coach" id="coach"><img src="${IMG.mossy}" alt="Mossy"><div><div class="cstep">${st+1} / ${TUT_STEPS_LEN}</div><p id="coach-text">${esc(TUT_TEXT(st))}</p></div>
    <button data-act="skipTutorial" id="btn-tut-skip">${esc(t("tutSkip"))}</button></div>`;
}
const TUT_STEPS_LEN = 6;
const TUT_TEXT = st => (typeof TUT_STEPS !== "undefined" ? TUT_STEPS : [])[st] ? L(TUT_STEPS[st]) : "";
const TUT_LINE = () => TUT && TUT.step >= 5 ? t("tutDone") : TUT_TEXT(TUT ? TUT.step : 0);

/* ---------- main game ---------- */
function gameScreen(){
  requestAnimationFrame(() => document.querySelectorAll(".jchip.here").forEach(el => { const c = el.parentElement; c.scrollLeft = el.offsetLeft - c.offsetLeft - c.clientWidth/2 + el.offsetWidth/2; }));
  return `<div class="app">
    ${store.ok ? "" : `<div class="storage-warn">${esc(t("storageWarn"))}</div>`}
    ${topbar()}
    <div class="objective"><b>🎯 ${esc(t("objective"))}</b><span id="objective-text">${esc(objective())}</span></div>
    ${journeyHTML()}
    <main class="view" id="view">${S.scene === "map" ? mapView() : isGeneric(S.scene) ? genericSceneView(S.scene) : sceneView(S.scene)}</main>
  </div>`;
}
function nodeState(id){ return placeDone(id) ? "done" : placeOpen(id) ? "open" : "locked"; }
function mapView(){
  const nodes = ART.MAP_NODES.map(n => {
    const st = nodeState(n.id);
    const nxt = nextTarget() === "node-"+n.id;
    return `<button class="node ${st} ${nxt?"next":""}" ${nxt?`data-next="👇 ${esc(L(MISC.nextLbl))}"`:""} style="left:${n.x}%;top:${n.y}%" data-act="node" data-arg="${n.id}" id="node-${n.id}" aria-label="${esc(L(n))}">
      <span class="dot">${st==="locked"?"🔒":n.ico}</span><span class="lbl">${esc(L(n))}${st==="done"?" ✓":""}</span></button>`;
  }).join("");
  const prog = ORDER_ALL.filter(placeDone).length;
  return `<div class="mapwrap">
    <div><h1>🗺️ ${esc(t("mapTitle"))}</h1><div class="worldmap">${ART.MAP_SVG}${nodes}</div>
      <div class="legend"><span><i style="background:#c4553a"></i>${esc(t("routeA"))}</span><span><i style="background:#3d76b8"></i>${esc(t("routeB"))}</span><span><i style="background:#e2b45c"></i>${esc(t("playable"))}</span><span>🔒 ${esc(t("comingSoon"))}</span></div>
      <section class="sidecard about" id="about-maokong"><span class="tag fact">${esc(t("factTag"))}</span><h2>📜 ${esc(L(ABOUT.title))}</h2><p>${esc(L(ABOUT.intro))}</p>
        <ol class="timeline">${ABOUT.timeline.map(e=>`<li><b>${esc(L(e.y))}</b><span>${esc(L(e.t))}</span></li>`).join("")}</ol></section></div>
    <aside>
      <div class="sidecard"><p>${esc(t("mapIntro"))}</p><p class="small muted">${esc(t("playtestNote"))}</p>
        <p class="small"><b>${esc(t("progress"))}:</b> ${prog} / ${ORDER_ALL.length}</p></div>
    </aside></div>`;
}
function sceneSteps(scene){
  const st = scene === "station"
    ? [["jig", lang()==="zh"?"記憶圖":"Picture"], ["logic", lang()==="zh"?"值班表鎖":"Roster lock"]]
    : [["plateUsed", lang()==="zh"?"解讀符號":"Read symbols"], ["overlay", lang()==="zh"?"校準地圖":"Align maps"], ["pot", lang()==="zh"?"壺穴年代":"Pothole ages"], ["gate", lang()==="zh"?"菌絲門":"Gate"]];
  let nowSet = false;
  return `<div class="steps">${st.map(([k,lbl]) => { const d = F(k); const now = !d && !nowSet; if (now) nowSet = true; return `<span class="step ${d?"done":now?"now":""}">${d?"✓":now?"▶":"○"} ${esc(lbl)}</span>`; }).join("")}</div>`;
}
function npcLine(scene){
  if (scene === "station") return L(!F("jig") ? MISC.npcStation0 : !F("logic") ? MISC.npcStation1 : MISC.npcStation2);
  return L(!F("plateUsed") ? MISC.npcValley0 : !F("overlay") ? MISC.npcValley1 : !F("pot") ? MISC.npcValley2 : !F("gate") ? MISC.npcValley3 : MISC.npcValley4);
}
function sceneView(scene){
  const sc = SCENES[scene];
  const showSign = lang() === "en";
  let after = "";
  if (scene === "station" && F("logic")) after = `<div class="feedback ok">${esc(L(MISC.valleyOpened))} <button class="btn-gold" data-act="goMap" style="margin-left:8px">${esc(t2("goMapBtn"))}</button> <button class="btn-primary pulse-target" data-act="enterValley" id="btn-go-valley" style="margin-left:8px">${esc(t("goValley"))}</button></div>`;
  if (scene === "valley" && F("gate")) after = `<div class="feedback ok">${esc(t2("valleyDone"))}<div class="actions"><button class="btn-primary pulse-target" data-act="goMap" id="btn-valley-map">${esc(t2("goMapBtn"))}</button></div></div>`;
  return `<div class="scene-head"><div><span class="chapter">${esc(L(sc.chapter))}</span>
      <h1>${esc(L(sc.name))}${showSign?`<span class="zh-sign" lang="zh-Hant">${sc.sign}</span>`:""}</h1></div>
      <button data-act="goMap">← ${esc(t("btnMap"))}</button></div>
    <p class="muted" style="margin:0">${esc(L(sc.lead))}</p>
    <div class="scenebox">${scene==="station"?ART.STATION_SVG:ART.VALLEY_SVG}${sc.hots.map(h => hotHTML(h, scene)).join("")}</div>
    ${npcbar(sc.npc, npcLine(scene))}
    ${sceneSteps(scene)}
    ${after}`;
}
function playMinutes(){ const end = S.tEnd || Date.now(); return Math.max(1, Math.round((end - (S.t0 || end)) / 60000)); }
function totalHints(){ return Object.values(S.hints).reduce((a,b)=>a+b,0); }
function totalTries(){ return Object.values(S.tries).reduce((a,b)=>a+b,0); }
function endingCard(){
  return `<section class="card ending" id="ending-card">
    <div class="core">✨</div><h2>${esc(t("endTitle"))}</h2><p>${esc(t("endText"))}</p>
    <p><b>${esc(t("endAsk"))}</b></p>
    <a class="cta" href="${FEEDBACK_URL}" target="_blank" rel="noopener noreferrer" id="end-feedback">${esc(t("endFeedback"))}</a>
    <p class="small muted">${esc(t("endPid",{id:S.pid}))}</p></section>`;
}

/* ===================== modals ===================== */
function openModal(type, arg){ M = {type, arg, fb:null}; renderModal(); logEv("open", type); }
function closeModal(){ const was = M; M = null; SEL = null; renderModal(); if (S.screen === "game") root.innerHTML = gameScreen(); else if (S.screen === "tutorial") { tutAfterModal(was); } }
function sheet(title, body, wide){
  return `<div class="modal" data-act="backdrop"><div class="sheet${wide?" wide":""}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
    <div class="sheet-head"><h2>${esc(title)}</h2><button class="close" data-act="close" id="btn-close">✕ ${esc(t("close"))}</button></div>
    <div class="sheet-body">${body}</div></div></div>`;
}
function renderModal(){
  if (!M) { modalRoot.innerHTML = ""; return; }
  const f = MODALS[M.type]; if (!f) { modalRoot.innerHTML = ""; return; }
  // keep the scroll position when the same dialog re-renders (otherwise every tap jumps to the top)
  const old = modalRoot.querySelector(".sheet"), key = M.type + ":" + JSON.stringify(M.arg || null);
  const keep = old && renderModal._key === key ? old.scrollTop : 0;
  modalRoot.innerHTML = f(M.arg);
  renderModal._key = key;
  const nu = modalRoot.querySelector(".sheet"); if (nu && keep) nu.scrollTop = keep;
}
const MODALS = {
  info(a){ // generic: {title, text, clues:[], docs:[], items:[]}
    let b = a.text ? `<p style="white-space:pre-line">${esc(L(a.text))}</p>` : "";
    (a.clues||[]).forEach(c => b += clueCard(c));
    (a.docs||[]).forEach(d => b += docCard(d));
    if (a.img) b += `<div style="text-align:center"><img src="${a.img}" alt="" style="width:min(360px,100%);border-radius:12px;border:3px solid #c9d4bd"></div>`;
    (a.got||[]).forEach(id => b += `<div class="feedback ok">${ITEMS[id]?ITEMS[id].ico:"🌰"} ${esc(t("gotItem",{item:itemName(id)}))}</div>`);
    b += a.action ? `<div class="actions"><button class="btn-primary" data-act="${a.action.act}" data-arg="${a.action.arg}" id="btn-action">${esc(L(a.action.label))}</button><button data-act="close" id="btn-ok">${esc(t("close"))}</button></div>`
                  : `<div class="actions"><button class="btn-primary" data-act="close" id="btn-ok">${esc(L(MISC.continueBtn))}</button></div>`;
    return sheet(typeof a.title === "string" ? a.title : L(a.title), b);
  },
  jig(){
    if (!S.jig) newJigsaw();
    const J = S.jig, done = F("jig");
    let b = `<div class="jig"><div>
      <div class="board n4" id="jig-board">${J.board.map((p,i)=>tileHTML(p,"board",i,"main")).join("")}</div></div>
      <div>${done ? "" : `<p>${esc(t("jigIntro"))}</p><div class="tray-label">${esc(t("jigTray"))}</div>
        <div class="tray" id="jig-tray">${J.tray.map((p,i)=>tileHTML(p,"tray",i,"main")).join("")}</div>`}
        <p class="small muted">${esc(t("jigSwaps",{n:J.swaps||0}))}</p>
      </div></div>${fbHTML()}`;
    if (!done) b += `<div class="actions"><button class="btn-primary" data-act="jigCheck" id="btn-jig-check">✔ ${esc(t("check"))}</button>
      <button data-act="jigDeselect">${esc(t("deselect"))}</button><button data-act="jigReset">↺ ${esc(t("resetPuzzle"))}</button></div>
      <details style="margin-top:12px"><summary>📄 ${esc(t("jigNote"))}</summary>${docCard("otherValley")}</details>`;
    else b += `<div class="actions"><button class="btn-primary" data-act="close" id="btn-ok">${esc(L(MISC.continueBtn))}</button></div>`;
    return sheet(t("jigTitle"), b, true);
  },
  logic(){
    const found = S.clues.length, done = F("logic");
    const rows = LOGIC.people.map((p,pi) => `<tr><th scope="row">${esc(L(p))}</th>${LOGIC.things.map((th,ti) => {
      const v = S.logic[pi*4+ti];
      return `<td><button class="m${v}" data-act="logicCell" data-arg="${pi*4+ti}" id="cell-${pi}-${ti}" aria-label="${esc(L(p))} / ${esc(L(th))}: ${["—","✕","✓"][v]}" ${done?"disabled":""}>${["","✕","✓"][v]}</button></td>`; }).join("")}</tr>`).join("");
    const clues = LOGIC.clues.map(c => S.clues.includes(c.id) ? `<li>“${esc(L(c))}”</li>` : `<li class="missing">${esc(t("clueMissing",{where:L(c.where)}))}</li>`).join("");
    let b = `<p>${esc(t("logicIntro"))}</p><div class="logic-wrap"><div>
      <table class="logic"><thead><tr><th>${esc(t("person"))} \\ ${esc(t("itemCol"))}</th>${LOGIC.things.map(th=>`<th>${esc(L(th))}</th>`).join("")}</tr></thead><tbody>${rows}</tbody></table>
      <p class="small muted">${esc(t("logicHow"))}</p></div>
      <div><h3>${esc(t("logicClues",{n:found}))}</h3><ul class="cluelist">${clues}</ul></div></div>${fbHTML()}`;
    b += done ? `<div class="actions"><button class="btn-primary" data-act="close" id="btn-ok">${esc(L(MISC.continueBtn))}</button></div>`
              : `<div class="actions"><button class="btn-primary" data-act="logicCheck" id="btn-logic-check">✔ ${esc(t("check"))}</button><button data-act="logicReset">↺ ${esc(t("resetPuzzle"))}</button></div>`;
    return sheet(t("logicTitle"), b, true);
  },
  ov(){
    const used = F("plateUsed"), done = F("overlay");
    const h = S.ov.x - OVERLAY.start.x, v = S.ov.y - OVERLAY.start.y;
    const hs = h>0 ? `→ ${h}` : h<0 ? `← ${-h}` : "0", vs = v<0 ? `↑ ${-v}` : v>0 ? `↓ ${v}` : "0", rot = (((S.ov.k%4)+4)%4)*90;
    let b = `<p class="small" style="margin-top:0">${esc(t("ovIntro"))}</p><div class="ovwrap" id="ov-map">${ART.overlaySVG(S.ov, used, done)}</div>`;
    if (!used) {
      b += `<div class="feedback info">${esc(t("ovNeedPlate"))}</div><div class="actions"><button class="btn-gold pulse-target" data-act="openBag" id="btn-ov-bag">${esc(t("ovOpenBag"))}</button></div>`;
    } else {
      // controls sit directly under the map so the player can watch the map while pressing them
      b += `<div class="ovctl">${done ? "" : `<div class="pad">
          <span></span><button data-act="ovMove" data-arg="0,-1" id="ov-up" aria-label="${esc(t("ovUp"))}">↑</button><span></span>
          <button data-act="ovMove" data-arg="-1,0" id="ov-left" aria-label="${esc(t("ovLeft"))}">←</button><button class="btn-gold" data-act="ovRotate" id="ov-rotate" aria-label="${esc(t("ovRotate"))}" title="${esc(t("ovRotate"))}">↻</button><button data-act="ovMove" data-arg="1,0" id="ov-right" aria-label="${esc(t("ovRight"))}">→</button>
          <span></span><button data-act="ovMove" data-arg="0,1" id="ov-down" aria-label="${esc(t("ovDown"))}">↓</button><span></span></div>`}
        <div class="ovside"><p class="small" id="ov-shift" style="margin:0 0 8px">${esc(t("ovShift",{x:hs,y:vs,r:rot}))}</p>
          ${done ? `<button class="btn-primary" data-act="close" id="btn-ok">${esc(L(MISC.continueBtn))}</button>`
                 : `<button class="btn-primary" data-act="ovCheck" id="btn-ov-check">✔ ${esc(t("check"))}</button> <button data-act="ovReset">↺ ${esc(t("resetPuzzle"))}</button>`}</div></div>
        ${fbHTML()}
        <details class="card" open><summary><b>🪙 ${esc(t("ovLegend"))}</b></summary><div class="legendbox" style="margin-top:8px">${OVERLAY.marks.map(m=>`<span class="g">${m.glyph}</span><span>= ${m.ico} ${esc(L(m))}</span>`).join("")}
        ${OVERLAY.decoys.map(d=>`<span class="g">${d.glyph}</span><span class="muted">= ${esc(L(d))}</span>`).join("")}</div></details>`;
    }
    return sheet(t("ovTitle"), b, true);
  },
  pot(){
    const done = F("pot"), seq = done ? POTHOLES.order : S.potSeq;
    let b = `<p>${esc(t("potIntro"))}</p><div class="potwrap" id="pot-map">${ART.potholeSVG(seq)}</div>
      <div class="small" style="text-align:center;margin-top:8px">${esc(t("potSeq"))}</div>
      <div class="seq">${[0,1,2,3].map(i=>`<span class="${seq[i]?"f":""}">${seq[i]||"?"}</span>`).join(" → ")}</div>
      <details><summary>📄 ${esc(DOCS.crosscut[lang()].t)}</summary>${docCard("crosscut")}</details>${fbHTML()}`;
    b += done ? `<div class="actions"><button class="btn-primary" data-act="close" id="btn-ok">${esc(L(MISC.continueBtn))}</button></div>`
              : `<div class="actions"><button class="btn-primary" data-act="potCheck" id="btn-pot-check" ${S.potSeq.length<4?"disabled":""}>✔ ${esc(t("check"))}</button>
                 <button data-act="potUndo" ${S.potSeq.length?"":"disabled"}>${esc(t("potUndo"))}</button><button data-act="potReset">↺ ${esc(t("resetPuzzle"))}</button></div>`;
    return sheet(t("potTitle"), b, true);
  },
  gate(){
    const sel = S.gateSel;
    const slot = (label, id) => `<div class="socket ${id?"filled":""}"><div class="hole">${id?ITEMS[id].ico:"◌"}</div><div class="small">${esc(label)}</div></div>`;
    const choices = S.bag.filter(id => id !== "core" && !id.startsWith("r_"));
    let b = `<p>${esc(t("gateIntro"))}</p><div class="gate">${slot(t("gateLeft"), sel[0])}${slot(t("gateRight"), sel[1])}</div>
      <div class="bag-grid">${choices.map(id => `<div class="item ${sel.includes(id)?"sel":""}"><div class="ico">${ITEMS[id].ico}</div><b>${esc(itemName(id))}</b>
        <span class="small muted">${esc(L(ITEMS[id].d))}</span>
        <button data-act="gateToggle" data-arg="${id}" id="gate-${id}" aria-pressed="${sel.includes(id)}">${esc(sel.includes(id)?t("selected")+" ✓":t("selectForGate"))}</button></div>`).join("")}</div>${fbHTML()}
      <div class="actions"><button class="btn-primary" data-act="gateGo" id="btn-gate-go">${esc(t("gateActivate"))}</button></div>`;
    return sheet(t("gateTitle"), b, true);
  },
  bag(a){
    const tut = a && a.tutorial;
    const items = tut ? (TUT && TUT.acorn ? ["acorn"] : []) : S.bag;
    if (!items.length) return sheet(t("bagTitle"), `<p>${esc(t("bagEmpty"))}</p>`);
    const b = `<div class="bag-grid">${items.map(id => {
      const ico = id === "acorn" ? "🌰" : ITEMS[id].ico, desc = id === "acorn" ? t("tutAcornDesc") : L(ITEMS[id].d);
      const usable = id === "plate";
      const guide = usable && S.scene === "valley" && !F("plateUsed");
      return `<div class="item" id="item-${id}"><div class="ico">${ico}</div><b>${esc(itemName(id))}</b><span class="small">${esc(desc)}</span>
        <button class="${usable?"btn-gold":""}${guide?" pulse-target":""}" data-act="${tut?"tutUse":usable?"useItem":"viewItem"}" data-arg="${id}" id="use-${id}">${esc(usable||tut?t("use"):t("view"))}</button></div>`; }).join("")}</div>`;
    return sheet(t("bagTitle"), b);
  },
  hint(a){
    if (a && a.tutorial) return sheet(t("hintTitle"), `<div class="dlg"><img src="${IMG.mossy}" alt="Mossy"><div class="bubble">${esc(t("tutMossyHint"))}</div></div><div class="actions"><button class="btn-primary" data-act="close" id="btn-ok">OK</button></div>`);
    const key = hintKey();
    const npc = S.scene === "valley" ? "pebble" : "mossy";
    if (!key) return sheet(t("hintTitle"), `<p>${esc(t("hintNone"))}</p>`);
    const list = hintList(key), n = Math.max(1, Math.min(list.length, S.hints[key] || 0));
    const b = `<div class="dlg"><img src="${npc==="pebble"?IMG.pebble:IMG.mossy}" alt=""><div class="bubble">
      ${list.slice(0,n).map((h,i)=>`<p style="margin:0 0 8px" id="hint-${i+1}"><b>${esc(t("hintLevel",{n:i+1}))}</b><br>${esc(h)}</p>`).join("")}</div></div>
      <p class="small muted">${esc(t("hintNoPenalty"))}</p>
      <div class="actions">${n < list.length ? `<button class="btn-gold" data-act="hintMore" id="btn-hint-more">💡 ${esc(t("hintMore"))}</button>` : ""}<button data-act="close">${esc(t("close"))}</button></div>`;
    return sheet(t("hintTitle")+" · "+L(DIALOGUE[npc].name), b);
  },
  dialog(a){
    const D = DIALOGUE[a.npc]; const img = a.npc === "pebble" ? IMG.pebble : IMG.mossy;
    let bubble = esc(L(D.open)), extra = "";
    if (a.q !== undefined) { const q = D.q[a.q]; bubble = q.a ? esc(L(q.a)) : ""; if (q.doc) extra = docCard(q.doc); }
    const b = `<div class="dlg"><img src="${img}" alt="${esc(L(D.name))}"><div class="bubble">${bubble ? `<p style="margin:0">${bubble}</p>` : ""}${extra}</div></div>
      <div class="choices">${D.q.map((q,i)=>`<button data-act="ask" data-arg="${a.npc}:${i}" id="ask-${i}">💬 ${esc(L(q.q))}</button>`).join("")}</div>`;
    return sheet(L(D.name), b);
  },
  menu(){
    const b = `<div class="choices">
      <button data-act="menuStory">${esc(t("menuStory"))}</button>
      <button data-act="menuIntro" id="menu-intro">${esc(t("menuIntro"))}</button>
      <button data-act="menuExport">${esc(t("menuExport"))}</button>
      <button data-act="menuReset" id="menu-reset">${esc(t("menuReset"))}</button></div>
      <p class="small muted" style="margin-top:14px">${esc(t("menuPlayerId"))} <b>${esc(S.pid)}</b><br>${esc(t("menuVersion"))}: ${VERSION}</p>`;
    return sheet(t("menuTitle"), b);
  },
  ending(){
    const b = `<div class="ending"><div class="core">✨</div><h2>${esc(t("endTitle"))}</h2><p>${esc(t("endText"))}</p>
      <div class="dlg" style="text-align:left;margin:12px 0"><img src="${IMG.mossy}" alt="Mossy"><div class="bubble">${esc(t("endMossy",{name:S.name || "Wanderer"}))}</div></div>
      ${feedbackBlock("modal-end-feedback")}
      <div class="stats"><div>⏱️ ${esc(t("endTime",{m:playMinutes()}))}</div><div>💡 ${esc(t("endHints",{n:totalHints()}))}</div><div>🔁 ${esc(t("endTries",{n:totalTries()}))}</div></div>
      <div class="card" style="text-align:left"><b>${esc(t("endLearned"))}</b><ul>${UI[lang()].endFacts.map(f=>`<li>${esc(f)}</li>`).join("")}</ul></div>
      <div class="actions" style="justify-content:center"><button data-act="close" id="btn-keep">${esc(t("endKeep"))}</button></div></div>`;
    return sheet(t("endTitle"), b, true);
  }
};

/* ===================== puzzle actions ===================== */
function newJigsaw(){
  let ids;
  do { ids = shuffle([...Array(18).keys()]); } while (ids.slice(0,16).every((v,i)=>v===i));
  S.jig = {board: ids.slice(0,16), tray: ids.slice(16), swaps:0}; save();
}
function jigTap(where, i){
  if (F("jig")) return;
  if (!SEL) { SEL = {where, i}; renderModal(); return; }
  if (SEL.where === where && SEL.i === i) { SEL = null; renderModal(); return; }
  const A = S.jig[SEL.where], B = S.jig[where];
  [A[SEL.i], B[i]] = [B[i], A[SEL.i]];
  S.jig.swaps = (S.jig.swaps||0) + 1; SEL = null; M.fb = null; save(); renderModal();
}
function jigCheck(){
  const J = S.jig;
  const correct = J.board.every((p,i) => p === i);   // tiles are visually unique => position i must hold piece i
  if (correct) { setFlag("jig"); award("pic"); setFb("ok", () => t("jigOk")); renderModal(); return; }
  tryCount("jigsaw");
  if (J.tray.some(p => p < 16)) setFb("bad", () => t("jigTrayWrong"));
  else setFb("bad", () => t("jigWrong", {n: J.board.filter((p,i)=>p!==i).length}));
  renderModal();
}
function logicCheck(){
  const g = S.logic, P = LOGIC.people.length, T = LOGIC.things.length;
  for (let p=0;p<P;p++){ const n = g.slice(p*T,p*T+T).filter(v=>v===2).length; if (n !== 1){ tryCount("logic"); const row=p+1; setFb("bad", () => t("logicNeedRow",{row, n})); return renderModal(); } }
  for (let th=0;th<T;th++){ let n=0; for(let p=0;p<P;p++) if (g[p*T+th]===2) n++; if (n>1){ tryCount("logic"); setFb("bad", () => t("logicDupCol",{item:L(LOGIC.things[th])})); return renderModal(); } }
  const assign = []; for (let p=0;p<P;p++) assign.push(g.slice(p*T,p*T+T).indexOf(2));
  if (assign.every((th,p) => th === LOGIC_ANSWER[p])) {
    setFlag("logic"); award("plate"); setFb("ok", () => t("logicOk") + " " + L(MISC.cabinetGot)); renderModal(); return;
  }
  tryCount("logic");
  for (let p=0;p<P;p++){ const th = assign[p];
    const c = LOGIC.clues.find(c => c.forbid.some(([a,b]) => a===p && b===th));
    if (c) { if (S.clues.includes(c.id)) setFb("bad", () => t("logicContradict",{person:L(LOGIC.people[p]), item:L(LOGIC.things[th]), clue:L(c)}));
             else setFb("bad", () => L(MISC.logicHidden));
             return renderModal(); } }
  setFb("bad", () => t("wrongTry")); renderModal();
}
/* where an old-map cell lands on the new map for the current rotation k and offset */
function ovPlace(p, ov){
  const c = (OVERLAY.cols-1)/2, k = ((ov.k%4)+4)%4; let dx = p.x - c, dy = p.y - c;
  for (let i=0;i<k;i++) [dx,dy] = [-dy, dx];            // 90° clockwise in screen coordinates
  return {x: Math.round(dx + c + ov.x), y: Math.round(dy + c + ov.y)};
}
function ovCount(ov){
  const glyphs = [...OVERLAY.marks.map(m=>({x:m.x,y:m.y,k:m.k})), ...OVERLAY.decoys.map(d=>({x:d.x,y:d.y,k:"decoy"}))].map(g=>({...ovPlace(g,ov), k:g.k}));
  const right = OVERLAY.marks.filter(m => glyphs.some(g => g.x===m.x && g.y===m.y && g.k===m.k)).length;
  const wrong = OVERLAY.marks.filter(m => glyphs.some(g => g.x===m.x && g.y===m.y && g.k!==m.k)).length;
  return {right, wrong};
}
function ovCheck(){
  const {right, wrong} = ovCount(S.ov);
  if (right === 3) { setFlag("overlay"); setFb("ok", () => t("ovOk")); renderModal(); return; }
  tryCount("overlay");
  setFb("bad", () => t("ovWrong",{n:right}) + (wrong ? " " + L(MISC.ovWrongSym,{k:wrong}) : ""));
  renderModal();
}
function potCheck(){
  const seq = S.potSeq, ord = POTHOLES.order;
  if (seq.length === 4 && seq.every((k,i) => k === ord[i])) { setFlag("pot"); award("rubbing"); setFb("ok", () => t("potOk")); renderModal(); return; }
  tryCount("potholes");
  for (let i=0;i<seq.length;i++) for (let j=i+1;j<seq.length;j++) {
    if (ord.indexOf(seq[i]) > ord.indexOf(seq[j])) {   // seq[i] is actually younger than seq[j]
      const a = seq[i], b = seq[j];
      const touch = POTHOLES.cuts.some(([y,o]) => (y===a&&o===b)||(y===b&&o===a));
      setFb("bad", () => t(touch ? "potWrongPair" : "potWrongFar", {a, b})); return renderModal();
    }
  }
  setFb("bad", () => t("wrongTry")); renderModal();
}
function gateGo(){
  const sel = S.gateSel;
  if (sel.length !== 2) { tryCount("gate"); setFb("bad", () => t("gateNeedTwo",{n:sel.length})); return renderModal(); }
  const bad = sel.find(id => !["plate","rubbing"].includes(id));
  if (bad) { tryCount("gate"); setFb("bad", () => t("gateWrong",{item:itemName(bad)})); return renderModal(); }
  setFlag("gate"); award("core"); save();
  toast(t("gateOk"));
  if (ORDER_ALL.every(placeDone)) { S.tEnd = Date.now(); save(); M = {type:"ending", fb:null}; }
  else M = {type:"info", arg:{title:{zh:UI.zh.gateTitle,en:UI.en.gateTitle}, text:{zh:UI2.zh.valleyDone,en:UI2.en.valleyDone}, action:{act:"goMap", arg:"", label:{zh:UI2.zh.goMapBtn,en:UI2.en.goMapBtn}}}, fb:null};
  root.innerHTML = gameScreen(); renderModal();
}

/* ===================== hotspots ===================== */
function hot(id){
  const scene = S.scene; if (isGeneric(scene)) return genericHot(scene, id);
  markSeen(scene+":"+id);
  if (scene === "station") {
    if (id === "frame") return openModal("jig");
    if (id === "board") { const n = addClue("c4"); if (n) toast(t("newClue")); return openModal("info",{title:MISC.boardTitle, text:MISC.boardText, clues:["c4"], docs:["gondola","tea"]}); }
    if (id === "log") { award("log"); const n = addClue("c1") | addClue("c2"); if (n) toast(t("newClue")); return openModal("info",{title:MISC.logTitle, text:MISC.logText, clues:["c1","c2"]}); }
    if (id === "porter") { award("tally"); if (addClue("c3")) toast(t("newClue")); return openModal("info",{title:MISC.porterTitle, text:MISC.porterText, clues:["c3"], docs:["porters"]}); }
    if (id === "cabinet") {
      const n = addClue("c5"); if (n) toast(t("newClue"));
      if (!F("jig")) return openModal("info",{title:SCENES.station.hots[4], text:MISC.cabinetLocked, clues:["c5"]});
      if (!F("logic")) return openModal("logic");
      return openModal("info",{title:SCENES.station.hots[4], text:MISC.cabinetOpen});
    }
  } else {
    if (id === "oldmap") return openModal("ov");
    if (id === "rocks") return openModal("info",{title:MISC.rocksTitle, docs:["potholes"]});
    if (id === "sign") return openModal("info",{title:MISC.signTitle, docs:["name"]});
    if (id === "potfield") { if (!F("overlay")) return openModal("info",{title:SCENES.valley.hots[3], text:{zh:UI.zh.potLocked, en:UI.en.potLocked}}); return openModal("pot"); }
    if (id === "gate") { if (F("gate")) return openModal("info",{title:SCENES.valley.hots[4], text:{zh:UI2.zh.valleyDone,en:UI2.en.valleyDone}}); return openModal("gate"); }
  }
}

/* ===================== tutorial actions ===================== */
function tutAdvance(to){ if (TUT && TUT.step < to) { TUT.step = to; } root.innerHTML = tutorialScreen(); tutScroll(); }
function tutScroll(){ requestAnimationFrame(() => { const el = document.querySelector("#tut-board") && TUT && TUT.step === 3 ? document.querySelector("#tut-board") : document.querySelector(".view .pulse-target, #btn-tut-go"); if (el && el.scrollIntoView) el.scrollIntoView({block:"center", behavior:"smooth"}); }); }
function tutAfterModal(was){
  if (!TUT || !was) { root.innerHTML = tutorialScreen(); return; }
  if (was.type === "info" && TUT.step === 1) return tutAdvance(2);
  if (was.type === "bag" && TUT.step === 2 && TUT.acorn) return tutAdvance(3);
  if (was.type === "hint" && TUT.step === 4) return tutAdvance(5);
  root.innerHTML = tutorialScreen();
}
function finishTutorial(){
  S.flags.tutorial = true; S.screen = "game"; if (!S.t0) S.t0 = Date.now(); if (!S.scene) S.scene = "map";
  TUT = null; M = null; logEv("tutorial_done"); save(); render(); window.scrollTo(0,0);
}

/* ===================== actions (event delegation) ===================== */
const ACT = {
  pickLang(a){ S.lang = a; setLangChosen(); logEv("lang", a); if (S.registered) { if (S.screen === "lang") S.screen = "game"; save(); return render(); } return onboardNext(); logEv("lang", a); save(); render(); },
  backLang(){ S.screen = "lang"; save(); render(); },
  storySkip(){ stopStory(); startTutorial(); },
  skipTutorial(){ stopStory(); logEv("tutorial_skipped"); finishTutorial(); },
  storyPause(b){ storyPaused = !storyPaused; b.textContent = storyPaused ? t("resume") : t("pause");
    if (storyPaused) { try{speechSynthesis.cancel()}catch(e){} }
    else if (SL && !SL.done) { SL.el = 0; SL.voiceDone = false; showLine(); } },   // resume restarts the current line so voice and text stay in sync
  storyReplay(){ startStory(); const e = document.getElementById("story-end"); if (e) e.classList.add("hidden"); },
  storyVoice(b){ voice = !voice; b.textContent = voice ? t("voiceOn") : t("voiceOff");
    if (voice) { if (SL && !SL.done) { SL.el = 0; SL.voiceDone = false; showLine(); } } else { try{speechSynthesis.cancel()}catch(e){} } },
  toggleLang(){ S.lang = lang() === "zh" ? "en" : "zh"; logEv("lang_switch", S.lang); save(); render(); },
  goMap(){ if (M) M = null; timeTick(); S.scene = "map"; save(); render(); window.scrollTo(0,0); },
  node(id){ openModal("place",{id}); },
  enterValley(){ timeTick(); S.scene = "valley"; logEv("scene","valley"); save(); render(); window.scrollTo(0,0); },
  hot(id){ hot(id); },
  talk(npc){ openModal("dialog",{npc}); },
  ask(a){ const [npc,i] = a.split(":"); M = {type:"dialog", arg:{npc, q:+i}, fb:null}; logEv("ask", a); renderModal(); },
  openBag(){ openModal("bag"); },
  openHint(){ const k = hintKey(); if (k && !S.hints[k]) { S.hints[k] = 1; logEv("hint", k+":1"); save(); report("hint", S.scene, 1); } openModal("hint"); },
  hintMore(){ const k = hintKey(); if (!k) return; S.hints[k] = Math.min(hintList(k).length, (S.hints[k]||0)+1); logEv("hint", k+":"+S.hints[k]); save(); report("hint", S.scene, S.hints[k]); renderModal(); },
  openMenu(){ openModal("menu"); },
  menuStory(){ openModal("info",{title:t("menuStory").replace(/^\S+\s/,""), text:MISC.storyText}); },
  menuIntro(){ M = null; startTutorial(); },
  menuExport(){
    const data = {version:VERSION, playerId:S.pid, name:S.name, nationality:S.nat === "OTHER" ? S.natOther : S.nat, lang:S.lang, flags:S.flags, hints:S.hints, attempts:S.tries, startedAt:S.t0, finishedAt:S.tEnd, events:S.ev};
    try { const blob = new Blob([JSON.stringify(data,null,2)],{type:"application/json"}); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `wanderquest-${S.pid}.json`; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(a.href), 1000); } catch(e){ toast("Export failed"); }
  },
  menuReset(){ if (confirm(t("resetConfirm"))) { const l = S.lang; store.del(KEY); S = freshState(); S.lang = l; M = null; S.screen = "register"; save(); render(); } },
  close(){ closeModal(); },
  backdrop(_, el, ev){ if (ev.target === el) closeModal(); },
  viewItem(id){
    if (id === "log") return openModal("info",{title:ITEMS.log, text:MISC.logText, clues:["c1","c2"]});
    if (id === "tally") return openModal("info",{title:ITEMS.tally, text:MISC.porterText, clues:["c3"]});
    if (id === "pic") return openModal("info",{title:MISC.picTitle, img:ART.PUZZLE_URI});
    if (id === "rubbing") return openModal("info",{title:ITEMS.rubbing, text:MISC.rubbingView});
    openModal("info",{title:ITEMS[id], text:ITEMS[id].d});
  },
  useItem(id){
    if (id !== "plate") return toast(t("useNothing"));
    if (S.scene !== "valley") return toast(t("useNothing"));
    if (F("plateUsed")) { toast(L(MISC.plateAlready)); return openModal("ov"); }
    setFlag("plateUsed"); toast(t("ovPlateUsed")); M = {type:"ov", fb:{cls:"ok", f:()=>t("ovPlateUsed")}}; root.innerHTML = gameScreen(); renderModal();
  },
  tile(a){ const [w,i] = a.split(":"); jigTap(w, +i); },
  jigCheck(){ jigCheck(); },
  jigDeselect(){ SEL = null; renderModal(); },
  jigReset(){ newJigsaw(); SEL = null; M.fb = null; logEv("reshuffle"); renderModal(); },
  logicCell(a){ if (F("logic")) return; const i = +a; S.logic[i] = (S.logic[i]+1)%3; M.fb = null; save(); renderModal(); },
  logicCheck(){ logicCheck(); },
  logicReset(){ S.logic = Array(16).fill(0); M.fb = null; save(); renderModal(); },
  ovMove(a){ if (F("overlay") || !F("plateUsed")) return; const [dx,dy] = a.split(",").map(Number); const lim = OVERLAY.limit;
    S.ov.x = Math.max(-lim, Math.min(lim, S.ov.x+dx)); S.ov.y = Math.max(-lim, Math.min(lim, S.ov.y+dy)); M.fb = null; logEv("ov_move", S.ov.x+","+S.ov.y); save(); renderModal(); },
  ovRotate(){ if (F("overlay") || !F("plateUsed")) return; S.ov.k = (S.ov.k + 1) % 4; M.fb = null; logEv("ov_rotate", S.ov.k); save(); renderModal(); },
  ovCheck(){ ovCheck(); },
  ovReset(){ S.ov = {...OVERLAY.start}; M.fb = null; save(); renderModal(); },
  pot(k){ if (F("pot")) return; if (!S.potSeq.includes(k) && S.potSeq.length < 4) S.potSeq.push(k); M.fb = null; save(); renderModal(); },
  potCheck(){ potCheck(); },
  potUndo(){ S.potSeq.pop(); M.fb = null; save(); renderModal(); },
  potReset(){ S.potSeq = []; M.fb = null; save(); renderModal(); },
  gateToggle(id){ const s = S.gateSel; S.gateSel = s.includes(id) ? s.filter(x=>x!==id) : [...s, id]; M.fb = null; save(); renderModal(); },
  gateGo(){ gateGo(); },
  // tutorial
  tutNoop(){},
  tutNode(){ tutAdvance(1); },
  tutHot(){ if (TUT.step < 1) return; TUT.acorn = true; M = {type:"info", arg:{title:t("tutStump"), text:{zh:UI.zh.tutStumpText,en:UI.en.tutStumpText}, got:["acorn"]}, fb:null}; root.innerHTML = tutorialScreen(); renderModal(); },
  tutBag(){ openModal("bag",{tutorial:true}); },
  tutUse(){ toast(L(MISC.practiceAcornUse)); },
  tutTile(a){
    if (TUT.step < 3) return; const i = +a.split(":")[1];
    if (!SEL) { SEL = {where:"board", i}; } else if (SEL.i === i) { SEL = null; } else { const P = TUT.puz; [P[SEL.i],P[i]] = [P[i],P[SEL.i]]; SEL = null; if (P.every((p,k)=>p===k)) { toast(t("tutPuzzleOk")); return tutAdvance(4); } }
    root.innerHTML = tutorialScreen();
  },
  tutTalk(){ if (TUT.step >= 4) openModal("hint",{tutorial:true}); },
  tutHint(){ if (TUT.step >= 4) openModal("hint",{tutorial:true}); },
  tutFinish(){ finishTutorial(); }
};
/*@@STATIONS_ENGINE@@*/
document.addEventListener("click", ev => {
  const el = ev.target.closest("[data-act]"); if (!el) return;
  const fn = ACT[el.dataset.act]; if (!fn) return;
  if (el.dataset.act !== "backdrop") ev.stopPropagation();
  try { fn(el.dataset.arg, el, ev); } catch(e){ console.error(e); toast("⚠️ " + e.message); }
});
document.addEventListener("keydown", ev => {
  if (ev.key === "Escape" && M) closeModal();
  if ((ev.key === "Enter" || ev.key === " ") && ev.target.matches && ev.target.matches("g[data-act]")) { ev.preventDefault(); ev.target.dispatchEvent(new MouseEvent("click",{bubbles:true})); }
});
window.addEventListener("error", e => { console.error("WQ error", e.message); });

/* inject puzzle images as CSS classes (data URIs contain no double quotes) */
const pzStyle = document.createElement("style");
pzStyle.textContent = `.pz{background-image:url("${ART.PUZZLE_URI}")}.dz0{background-image:url("${ART.DECOY_URI[0]}")}.dz1{background-image:url("${ART.DECOY_URI[1]}")}.pr{background-image:url("${ART.PRACTICE_URI}")}`;
document.head.appendChild(pzStyle);

/* expose read-only hooks for automated tests */
window.WQ = { get state(){ return clone(S); }, LOGIC_ANSWER, LOGIC_SOLUTIONS, VERSION, ovCount, MECHDATA, placeDone };

if (S.screen === "tutorial") TUT = null;
render();
})();
