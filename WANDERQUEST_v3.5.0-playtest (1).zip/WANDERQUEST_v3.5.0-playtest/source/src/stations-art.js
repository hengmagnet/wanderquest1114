/* WANDERQUEST v3.2 — art for the data-driven stations (original vector art). */
const ART2 = (() => {
const uri = s => "data:image/svg+xml;charset=utf-8," + encodeURIComponent(s);

/* ---------- A2: then & now (400 x 260) ---------- */
function hillside(){ return `
<defs><linearGradient id="hs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a9d7e6"/><stop offset="1" stop-color="#eef3d6"/></linearGradient></defs>
<rect width="400" height="260" fill="url(#hs)"/>
<path d="M0 110 L70 80 L150 105 L240 70 L330 100 L400 85 V260 H0Z" fill="#9cc6a6"/>
<path d="M0 150 C120 130 260 150 400 125 V260 H0Z" fill="#5f9a6c"/>
${[150,172,194,216,238].map((y,i)=>`<path d="M0 ${y+8} C120 ${y-8+i*2} 260 ${y+6} 400 ${y-14}" stroke="#2f6b45" stroke-width="9" fill="none" stroke-linecap="round" stroke-dasharray="14 6"/>`).join("")}
<circle cx="350" cy="40" r="18" fill="#f6c95e"/>`; }
const SPOT_OLD = `<svg viewBox="0 0 400 260" xmlns="http://www.w3.org/2000/svg">${hillside()}
<path d="M180 260 C200 230 240 215 300 190" stroke="#c9a46a" stroke-width="6" fill="none" stroke-dasharray="8 6"/>
<text x="262" y="214" font-size="26">🧺</text><text x="40" y="140" font-size="22">🌳</text>
<text x="10" y="252" font-family="Georgia,serif" font-size="13" fill="#6b5a3a" font-style="italic">memory sketch</text></svg>`;
const SPOT_NEW = `<svg viewBox="0 0 400 260" xmlns="http://www.w3.org/2000/svg">${hillside()}
<line x1="0" y1="58" x2="400" y2="22" stroke="#263533" stroke-width="4"/>
<g transform="translate(205 34)"><line x1="0" y1="0" x2="0" y2="10" stroke="#263533" stroke-width="3"/><rect x="-12" y="10" width="24" height="18" rx="5" fill="#c4553a" stroke="#263533" stroke-width="2"/></g>
<rect x="30" y="140" width="84" height="12" fill="#8a6a45"/><path d="M34 140 v-16 M56 140 v-16 M78 140 v-16 M100 140 v-16 M110 140 v-16 M34 126 H112" stroke="#6d5236" stroke-width="3"/>
<rect x="306" y="94" width="50" height="30" rx="4" fill="#fff4d6" stroke="#7a5517" stroke-width="3"/><text x="331" y="116" font-size="16" text-anchor="middle">🍵</text><line x1="331" y1="124" x2="331" y2="150" stroke="#7a5517" stroke-width="3"/>
<path d="M170 260 C200 230 240 212 320 186" stroke="#7d8481" stroke-width="16" fill="none"/><path d="M170 260 C200 230 240 212 320 186" stroke="#f2f2e6" stroke-width="2" fill="none" stroke-dasharray="10 10"/>
<line x1="160" y1="150" x2="160" y2="200" stroke="#3b4a48" stroke-width="4"/><circle cx="160" cy="148" r="7" fill="#f6c95e" stroke="#3b4a48" stroke-width="2"/>
<text x="40" y="140" font-size="22">🌳</text></svg>`;

/* ---------- B3: night view 9-piece jigsaw (300 x 300) ---------- */
const NIGHT_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" width="300" height="300">
<defs><linearGradient id="ng" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0f1c36"/><stop offset=".6" stop-color="#26385e"/><stop offset="1" stop-color="#1b2a3a"/></linearGradient></defs>
<rect width="300" height="300" fill="url(#ng)"/>
<path d="M96 22 a26 26 0 1 0 22 40 a20 20 0 1 1 -22 -40z" fill="#f4e7b0"/>
${[[120,20],[135,48],[160,30],[180,70],[112,80],[150,88],[190,18],[24,90],[268,140],[35,130]].map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="${1.5+i%3}" fill="#fff"/>`).join("")}
<path d="M140 40 l8 8 M148 40 l-8 8" stroke="#fff" stroke-width="2"/>
<g transform="translate(200 52)">${Array.from({length:12},(_,i)=>{const a=i*Math.PI/6;return `<line x1="0" y1="0" x2="${Math.cos(a)*34}" y2="${Math.sin(a)*34}" stroke="${["#ff6b6b","#ffd166","#6bd3ff"][i%3]}" stroke-width="3" stroke-linecap="round"/>`}).join("")}<circle r="5" fill="#fff"/></g>
<g transform="translate(262 30)">${Array.from({length:8},(_,i)=>{const a=i*Math.PI/4;return `<circle cx="${Math.cos(a)*12}" cy="${Math.sin(a)*12}" r="2.5" fill="#c3a6ff"/>`}).join("")}</g>
<path d="M0 182 L60 168 L120 178 L150 170 L180 180 L240 164 L300 176 L300 200 L0 200Z" fill="#33496b"/><path d="M0 190 L40 150 L70 170 L100 140 L132 178 L132 200 L0 200Z" fill="#4c6e8f"/><rect x="34" y="166" width="22" height="16" fill="#2b3f55"/><path d="M30 167 L45 155 L60 167Z" fill="#2b3f55"/><rect x="38" y="170" width="6" height="6" fill="#ffd66b"/><rect x="47" y="170" width="6" height="6" fill="#ffd66b"/>
<path d="M168 186 L200 150 L230 160 L260 135 L300 165 L300 200 L168 200Z" fill="#6b4f8f"/>
<path d="M262 135 L256 104 M262 135 L268 104 M257 118 L267 118 M256 104 L268 104" stroke="#d9d4ea" stroke-width="2.5" fill="none"/><circle cx="262" cy="100" r="5" fill="#ff5a5a"/>
<path d="M150 108 L156 108 L158 120 L162 120 L163 145 L168 145 L170 200 L130 200 L132 145 L137 145 L138 120 L142 120 L144 108Z" fill="#3a4f74" stroke="#a9c3ff" stroke-width="1.5"/>
<line x1="150" y1="108" x2="150" y2="96" stroke="#a9c3ff" stroke-width="2"/>
${[0,1,2,3,4,5].map(i=>`<rect x="140" y="${150+i*8}" width="20" height="3" fill="#ffe08a"/>`).join("")}
<path d="M150 100 Q140 120 128 132" stroke="#ffd166" stroke-width="2" fill="none" stroke-dasharray="3 3"/>
<rect x="0" y="200" width="300" height="100" fill="#121d2b"/>
${Array.from({length:40},(_,i)=>{const x=(i*37)%200,y=210+((i*53)%80);return `<rect x="${x}" y="${y}" width="${3+i%3}" height="3" fill="${i%4?"#ffd98a":"#ffffff"}"/>`}).join("")}
<path d="M30 262 C80 250 140 272 186 258" stroke="#4d7aa8" stroke-width="5" fill="none"/>
<path d="M20 230 q14 -18 30 -6 M30 222 q8 6 4 14" stroke="#f2b8c6" stroke-width="3" fill="none"/>${[[28,222],[44,216],[36,234]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="4" fill="#f7c6d3"/>`).join("")}
<path d="M150 250 L200 222 L250 250Z" fill="#7a3e2f" stroke="#e7c38f" stroke-width="3"/><rect x="164" y="250" width="72" height="8" fill="#5b3a2a"/><rect x="170" y="258" width="6" height="42" fill="#5b3a2a"/><rect x="224" y="258" width="6" height="42" fill="#5b3a2a"/>
<text x="200" y="290" font-family="Arial" font-size="11" fill="#e7c38f" text-anchor="middle">望遠亭</text>
</svg>`;
const DAY_SVG = [
`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="#8fd0ef"/><circle cx="50" cy="45" r="20" fill="#ffd34d"/><circle cx="50" cy="45" r="28" fill="none" stroke="#ffd34d" stroke-width="3" stroke-dasharray="5 6"/></svg>`,
`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="#9ed6ee"/><g fill="#fff"><ellipse cx="40" cy="40" rx="24" ry="12"/><ellipse cx="60" cy="34" rx="18" ry="13"/></g><path d="M0 85 L35 62 L65 78 L100 60 V100 H0Z" fill="#6fae7a"/></svg>`
];

/* ---------- generic station backdrop (1600 x 900) ---------- */
const PROPS = {
 spot:["🔭","🍃","🪑"], sort:["⛩️","🫙","🐈","🐈"], pipes:["🌳","🪨","💧","🪜"], process:["🏛️","🍵","🌧️","🫖"],
 grid:["🏡","🔥","🌾","🐃"], jig9:["🏯","🌸","🌃"], simon:["🎐","🔔","🌳","🥁"], path:["⛰️","💦","🎋","🪨"]
};
function sceneSVG(stn){
  const [a,b] = stn.sky, g = stn.ground, props = PROPS[stn.kind] || [];
  const night = stn.kind === "jig9";
  return `<svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
  <defs><linearGradient id="gs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs>
  <rect width="1600" height="900" fill="url(#gs)"/>
  ${night ? Array.from({length:40},(_,i)=>`<circle cx="${(i*197)%1600}" cy="${(i*83)%360}" r="${1+i%3}" fill="#fff" opacity=".8"/>`).join("") : `<circle cx="1360" cy="130" r="60" fill="#f6dfa0" opacity=".9"/>`}
  <path d="M0 420 L240 280 L500 380 L760 250 L1040 360 L1300 240 L1600 330 V900 H0Z" fill="${night?"#2b4660":"#9cc6a6"}" opacity=".9"/>
  <path d="M0 540 C320 480 640 540 960 470 S1400 450 1600 470 V900 H0Z" fill="${g}"/>
  ${[600,660,720,780].map((y,i)=>`<path d="M0 ${y+20} C400 ${y-30+i*6} 1000 ${y+24} 1600 ${y-20}" stroke="${night?"#22394b":"#2f6b45"}" stroke-width="20" fill="none" opacity=".35" stroke-dasharray="40 16"/>`).join("")}
  ${props.map((p,i)=>`<text x="${180+i*380}" y="${520+((i*97)%120)}" font-size="${90-i*6}" opacity=".85">${p}</text>`).join("")}
  </svg>`;
}

/* ---------- A5: pipe tile ---------- */
const OPEN = {S:[["t","b"],["l","r"],["t","b"],["l","r"]], C:[["t","r"],["r","b"],["b","l"],["l","t"]], X:[[],[],[],[]]};
function pipeTile(type, rot, wet, isIn, isOut){
  const dirs = OPEN[type][rot%4], c = wet ? "#3b9ad9" : "#8a8f86";
  const seg = {t:"M50 50 V0", b:"M50 50 V100", l:"M50 50 H0", r:"M50 50 H100"};
  return `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><rect width="100" height="100" fill="${type==="X"?"#9b958a":"#d9cfb4"}"/>
   ${type==="X" ? `<circle cx="38" cy="44" r="18" fill="#7f796e"/><circle cx="64" cy="62" r="14" fill="#8c867a"/>` :
     `${dirs.map(d=>`<path d="${seg[d]}" stroke="#6f6a5e" stroke-width="30" stroke-linecap="butt"/>`).join("")}${dirs.map(d=>`<path d="${seg[d]}" stroke="${c}" stroke-width="18"/>`).join("")}<circle cx="50" cy="50" r="9" fill="${c}"/>`}
  </svg>`;
}

return {SPOT_OLD, SPOT_NEW, NIGHT_SVG, NIGHT_URI:uri(NIGHT_SVG), DAY_SVG, DAY_URI:DAY_SVG.map(uri), sceneSVG, pipeTile, OPEN};
})();
