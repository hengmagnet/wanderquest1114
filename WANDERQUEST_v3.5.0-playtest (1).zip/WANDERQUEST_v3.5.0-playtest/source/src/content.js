/* WANDERQUEST v3.0 — all player-facing text, in both languages.
   Rule: every key exists in BOTH zh and en. tests/check_i18n.js enforces this. */
const FEEDBACK_URL = "https://docs.google.com/forms/d/e/1FAIpQLSf5dCTCsEz6x8AaLq9NlYHxR8DTBQU8JEJxZrZIe1ujxjjjUw/viewform";
const VERSION = "v3.5.0-playtest";
/* ===== 後台（Google 試算表）=====
   把 Apps Script 部署後得到的網址貼在下面引號裡（以 https://script.google.com/macros/s/ 開頭、/exec 結尾）。
   留空 = 不上傳任何資料。 Paste the Apps Script web-app URL here; leave empty to disable uploads. */
const SHEET_ENDPOINT = "";

const UI = {
zh:{
  chooseLang:"Choose Your Language / 選擇語言",
  langHint:"You can switch language any time. / 遊戲中可隨時切換語言，進度不會遺失。",
  profileTitle:"記憶守護者，歡迎來到貓空",
  profileSub:"以下資料都可以不填。資料只存在你的瀏覽器，不會上傳。",
  nickname:"暱稱（選填）", nickPh:"例如：Wanderer",
  region:"國家或地區（選填）", regionPh:"例如：Japan、France、臺灣",
  next:"下一步", back:"返回", skip:"跳過", replay:"重播", start:"開始冒險",
  storyKicker:"序章",
  voiceOn:"🔊 語音：開（裝置語音）", voiceOff:"🔇 語音：關", pause:"Ⅱ 暫停", resume:"▶ 繼續",
  toTutorial:"進入操作教學 →", skipAll:"跳過教學，直接開始",
  tutBanner:"操作教學 · 練習林地（約 60 秒）",
  tutSkip:"跳過教學",
  brandSub:"記憶菌絲 · 試玩版",
  btnMap:"地圖", btnBag:"背包", btnHint:"提示", btnMenu:"選單", btnLang:"EN",
  objective:"目前目標",
  menuTitle:"選單", menuFeedback:"📝 填寫遊戲回饋", menuIntro:"🎓 重看操作教學", menuStory:"📖 世界觀",
  menuExport:"⬇️ 匯出遊玩紀錄（JSON）", menuReset:"🗑️ 重置進度", menuVersion:"版本",
  menuPlayerId:"你的匿名遊玩代碼（填回饋表單時可提供）：",
  resetConfirm:"確定要清除所有進度並從頭開始嗎？",
  storageWarn:"⚠️ 你的瀏覽器封鎖了本機儲存，遊戲可以玩，但重新整理後進度不會保留。",
  close:"關閉", backToScene:"返回場景",
  mapTitle:"記憶菌絲地圖",
  mapIntro:"貓空的地點由記憶菌絲相連。從貓空站出發，有兩條路線：路線 A 走茶文化，路線 B 走山村。點任何一個地點，都能先看它的歷史簡介。",
  routeA:"路線 A · 茶文化", routeB:"路線 B · 山村探索", playable:"本次試玩開放", comingSoon:"完整版開放",
  notInPlaytest:"「{name}」會在完整版開放，本次試玩先探索貓空站與壺穴步道。",
  lockedValley:"先在貓空站打開站務櫃，取得通往溪谷的線索。",
  enter:"進入", done:"已完成", playtestNote:"試玩版：11 個地點、兩條路線全部開放。",
  progress:"進度",
  bagTitle:"🎒 記憶背包", bagEmpty:"背包是空的。點擊場景中發光的物件來調查吧。",
  use:"使用", view:"查看", selectForGate:"選擇", selected:"已選擇",
  useNothing:"這裡沒有地方可以使用它。",
  gotItem:"獲得道具：{item}",
  newClue:"新線索已記入值班表！",
  hintTitle:"三層提示", hintLevel:"提示 {n} / 3", hintMore:"再給我一個提示", hintNone:"目前沒有需要提示的機關，四處探索看看吧！",
  hintNoPenalty:"提示沒有任何懲罰，可以放心使用。",
  talk:"對話",
  check:"檢查", resetPuzzle:"重來", deselect:"取消選取",
  wrongTry:"再試一次吧！", attempts:"嘗試次數：{n}",
  factTag:"史實", fictionTag:"虛構故事",
  readMore:"文化資料",
  goMap:"回到地圖 →", goValley:"前往壺穴步道 →",
  // jigsaw
  jigTitle:"機關 1｜18 選 16：失落的記憶圖",
  jigIntro:"十八片碎片裡，只有十六片屬於這張貓空記憶圖。點一片，再點另一片（或空格），兩片就會交換。把兩片「另一座山谷」的碎片留在候選區。",
  jigTray:"候選區（最後應該剩下 2 片不屬於這張圖的碎片）",
  jigSwaps:"已交換 {n} 次",
  jigOk:"記憶圖修復了！三個紅色車廂沿著鋼索一路通往山頂的貓空站。",
  jigTrayWrong:"候選區裡還有屬於這張圖的碎片。檢查它們的鋼索方向、車廂顏色與地形。",
  jigWrong:"還有 {n} 格位置不對。沿著鋼索、山稜線與車站屋頂檢查每一片的接縫。",
  jigDecoyOnBoard:"地圖上還有來自另一座山谷的碎片（{n} 片）。",
  jigNote:"調查筆記：另一座山谷",
  // logic
  logicTitle:"機關 2｜值班表鎖",
  logicIntro:"記憶菌絲打散了一晚的值班紀錄。四個人各帶了一件不同的物品。根據你在站裡找到的線索，在每一列標出一個 ✓。",
  logicHow:"點格子切換：空白 → ✕ 排除 → ✓ 確定。✕ 只是幫你記錄，不影響判定。",
  logicClues:"已找到的線索 {n} / 5",
  clueMissing:"？？？ 還沒找到。（提示：{where}）",
  logicNeedRow:"每一列都需要剛好一個 ✓（目前第 {row} 列有 {n} 個）。",
  logicDupCol:"「{item}」被標給了不只一個人。每件物品只屬於一個人。",
  logicContradict:"「{person} 帶 {item}」和這條線索矛盾：{clue}",
  logicOk:"值班表正確！帶著指南針的維護員，工具袋裡就放著站務櫃的鑰匙。",
  person:"人物", itemCol:"物品",
  // overlay
  ovTitle:"機關 3｜雙層地圖校準",
  ovIntro:"挑夫留下的舊地圖（半透明）用古老符號記下地標，而且整張圖被轉歪、又錯位了。用 ↻ 旋轉、用方向鍵平移，讓舊地圖上的三個地標與新地圖上的橋、老樹、石碑同時重合。",
  ovNeedPlate:"舊地圖上的符號看不懂……也許站務櫃裡帶出來的東西能幫忙。打開背包，對這張地圖「使用」它。",
  ovOpenBag:"🎒 打開背包",
  ovLegend:"銅片上的符號對照",
  ovShift:"舊地圖目前：旋轉 {r}°，水平 {x}，垂直 {y}",
  ovUp:"上移", ovRotate:"順時針旋轉 90°", ovDown:"下移", ovLeft:"左移", ovRight:"右移",
  ovOk:"三個地標完全重合！舊地圖上浮現一個記號：最古老的壺穴群就在溪床下游。",
  ovWrong:"還沒對齊：{n} / 3 個地標重合。注意，舊地圖上還有三個不是地標的記號。",
  ovPlateUsed:"你把銅片放在舊地圖上，符號的意思浮現了！",
  // potholes
  potTitle:"機關 4｜壺穴年代判讀",
  potIntro:"溪床上四個壺穴互相交疊。依照「截切關係」，從最古老到最年輕，依序點擊四個壺穴。",
  potSeq:"你的順序（最老 → 最年輕）",
  potOk:"判讀正確！小岩從最古老的壺穴邊緣拓下了岩紋。",
  potWrongPair:"你把 {a} 排在 {b} 前面（{a} 比較老）。仔細看它們交界的地方：誰的邊緣是完整的？",
  potWrongFar:"你把 {a} 排在 {b} 前面，但它們沒有直接相連。試著用中間的壺穴當作橋梁比較。",
  potUndo:"↶ 退一步",
  potLocked:"小岩：「我們還不知道最古老的壺穴在哪裡……挑夫的舊地圖上應該有標記。先把舊地圖校準吧！」",
  // gate
  gateTitle:"最終機關｜記憶菌絲門",
  gateIntro:"菌絲門上有兩個凹槽。從背包選出兩件道具放進去，讓兩個場景的記憶重新連結。",
  gateLeft:"左凹槽：刻著三座山的地標", gateRight:"右凹槽：波浪般的岩石紋理",
  gateActivate:"✨ 啟動菌絲門",
  gateNeedTwo:"請剛好選擇兩件道具（目前 {n} 件）。",
  gateWrong:"「{item}」放不進凹槽。凹槽一個刻著山的地標，一個是岩石紋理。",
  gateOk:"兩件道具同時發光！",
  // ending
  endTitle:"記憶重新連結了！",
  endText:"纜車、山路與溪谷的壺穴，原來是同一張記憶網的一部分。你找回的不只是線索，而是讓更多人認識貓空的故事。",
  endMossy:"謝謝你，{name}。兩條路線的記憶都找回來了，貓空的記憶菌絲網又亮起來了！",
  endTime:"遊玩時間 {m} 分鐘", endHints:"使用提示 {n} 次", endTries:"嘗試 {n} 次",
  endAsk:"你的回饋會直接影響下一版的設計（約 3 分鐘）：",
  endFeedback:"📝 填寫遊戲回饋 Give Feedback ↗",
  endPid:"匿名遊玩代碼：{id}",
  endKeep:"繼續探索", endLearned:"這次你認識了：",
  endFacts:["貓空纜車：2007 年通車、2008 年停駛、2010 年復駛","貓空地名與溪床壺穴的關係","壺穴如何形成，以及地質學家如何判斷先後","山區挑夫與木柵鐵觀音的茶文化"],
  // tutorial
  tutMapNode:"練習林地", tutScene:"練習林地",
  tutStump:"樹樁", tutAcorn:"練習橡實", tutAcornDesc:"教學用的道具。真正的冒險中，道具可以「使用」或放進機關裡。",
  tutStumpText:"樹樁的洞裡藏著一顆亮晶晶的橡實。",
  tutPuzzle:"練習拼圖", tutPuzzleOk:"拼好了！",
  tutMossyHint:"提示 1 / 3：每個機關都有三層提示，越後面越具體，沒有任何懲罰。",
  tutDone:"太好了！你已經學會所有操作。貓空站已解鎖。",
  tutGo:"開始冒險 →",
  speaker:"Mossy"
},
en:{
  chooseLang:"Choose Your Language / 選擇語言",
  langHint:"You can switch language any time. / 遊戲中可隨時切換語言，進度不會遺失。",
  profileTitle:"Welcome to Maokong, Memory Guardian",
  profileSub:"Everything here is optional. It stays in your browser and is never uploaded.",
  nickname:"Nickname (optional)", nickPh:"e.g. Wanderer",
  region:"Country or region (optional)", regionPh:"e.g. Japan, France, Taiwan",
  next:"Next", back:"Back", skip:"Skip", replay:"Replay", start:"Start adventure",
  storyKicker:"Prologue",
  voiceOn:"🔊 Voice: on (device voice)", voiceOff:"🔇 Voice: off", pause:"Ⅱ Pause", resume:"▶ Resume",
  toTutorial:"Continue to the tutorial →", skipAll:"Skip tutorial and start",
  tutBanner:"TUTORIAL · Training Grove (about 60 seconds)",
  tutSkip:"Skip tutorial",
  brandSub:"The Memory Network · Playtest",
  btnMap:"Map", btnBag:"Bag", btnHint:"Hint", btnMenu:"Menu", btnLang:"中文",
  objective:"Objective",
  menuTitle:"Menu", menuFeedback:"📝 Give feedback", menuIntro:"🎓 Replay the tutorial", menuStory:"📖 The story so far",
  menuExport:"⬇️ Export play log (JSON)", menuReset:"🗑️ Reset progress", menuVersion:"Version",
  menuPlayerId:"Your anonymous play ID (you can share it in the feedback form):",
  resetConfirm:"Clear all progress and start over?",
  storageWarn:"⚠️ Your browser blocks local storage. You can play, but progress will not survive a page reload.",
  close:"Close", backToScene:"Back to scene",
  mapTitle:"Memory Network Map",
  mapIntro:"Maokong’s places are linked by the memory network. From Maokong Station two routes branch out: Route A for tea culture, Route B for mountain village life. Tap any place to read a short history first.",
  routeA:"Route A · Tea culture", routeB:"Route B · Mountain village", playable:"Open in this playtest", comingSoon:"Full version",
  notInPlaytest:"“{name}” opens in the full version. In this playtest, explore Maokong Station and the Pothole Trail.",
  lockedValley:"First open the station cabinet at Maokong Station to find the way to the valley.",
  enter:"Enter", done:"Done", playtestNote:"Playtest: 11 places, both routes fully open.",
  progress:"Progress",
  bagTitle:"🎒 Memory Bag", bagEmpty:"Your bag is empty. Tap glowing objects in a scene to investigate.",
  use:"Use", view:"View", selectForGate:"Select", selected:"Selected",
  useNothing:"There is nowhere to use this here.",
  gotItem:"New item: {item}",
  newClue:"New clue added to the duty roster!",
  hintTitle:"Three-level hints", hintLevel:"Hint {n} / 3", hintMore:"Give me another hint", hintNone:"No puzzle needs a hint right now. Try exploring!",
  hintNoPenalty:"Hints have no penalty. Use them freely.",
  talk:"Talk",
  check:"Check", resetPuzzle:"Reset", deselect:"Deselect",
  wrongTry:"Try again!", attempts:"Attempts: {n}",
  factTag:"History / fact", fictionTag:"Fiction",
  readMore:"Culture notes",
  goMap:"Back to the map →", goValley:"Go to the Pothole Trail →",
  jigTitle:"Puzzle 1 | Choose 16 of 18: The Lost Memory Picture",
  jigIntro:"Only sixteen of these eighteen pieces belong to this picture of Maokong. Tap one piece, then another piece (or a gap), and they swap. Leave the two pieces from “another valley” in the spare tray.",
  jigTray:"Spare tray (two pieces that don’t belong should end up here)",
  jigSwaps:"Swaps: {n}",
  jigOk:"The memory picture is restored! Three red cabins ride the cable up to Maokong Station on the hilltop.",
  jigTrayWrong:"A piece that belongs to the picture is still in the spare tray. Check cable direction, cabin colour and terrain.",
  jigWrong:"{n} squares are still in the wrong place. Follow the cable, the ridgeline and the station roof across each seam.",
  jigDecoyOnBoard:"The board still holds {n} piece(s) from the other valley.",
  jigNote:"Field note: the other valley",
  logicTitle:"Puzzle 2 | The Duty-Roster Lock",
  logicIntro:"The memory network scrambled one night’s duty roster. Four people each carried a different object. Use the clues you find around the station and place exactly one ✓ in each row.",
  logicHow:"Tap a cell to cycle: blank → ✕ ruled out → ✓ confirmed. ✕ marks are just notes and are never graded.",
  logicClues:"Clues found {n} / 5",
  clueMissing:"??? Not found yet. (Hint: {where})",
  logicNeedRow:"Each row needs exactly one ✓ (row {row} has {n}).",
  logicDupCol:"“{item}” is marked for more than one person. Each object belongs to one person only.",
  logicContradict:"“{person} carried the {item}” contradicts this clue: {clue}",
  logicOk:"Roster solved! The maintenance worker carried the compass — and the cabinet key was in their tool bag.",
  person:"Person", itemCol:"Object",
  ovTitle:"Puzzle 3 | Align the Two Maps",
  ovIntro:"The porter’s old map (translucent) marks landmarks with old symbols — and it has been both turned and shifted. Rotate it with ↻ and slide it with the arrows until its three landmarks sit exactly on the bridge, old tree and stone marker of the new map.",
  ovNeedPlate:"You can’t read the old symbols… Maybe the object from the station cabinet helps. Open your bag and “Use” it on this map.",
  ovOpenBag:"🎒 Open bag",
  ovLegend:"Symbol key from the copper plate",
  ovShift:"Old map now: rotated {r}°, horizontal {x}, vertical {y}",
  ovUp:"Up", ovRotate:"Rotate 90° clockwise", ovDown:"Down", ovLeft:"Left", ovRight:"Right",
  ovOk:"All three landmarks line up! A mark appears on the old map: the oldest potholes lie downstream.",
  ovWrong:"Not aligned yet: {n} / 3 landmarks overlap. Careful — the old map also has three marks that are not landmarks.",
  ovPlateUsed:"You lay the copper plate on the old map. The meaning of the symbols appears!",
  potTitle:"Puzzle 4 | Reading the Potholes’ Ages",
  potIntro:"Four potholes overlap in the streambed. Using the principle of cross-cutting relationships, tap them in order from OLDEST to YOUNGEST.",
  potSeq:"Your order (oldest → youngest)",
  potOk:"Correct! Pebble takes a rubbing of the rock texture from the rim of the oldest pothole.",
  potWrongPair:"You placed {a} before {b} (so {a} is older). Look closely where they meet: whose rim is complete?",
  potWrongFar:"You placed {a} before {b}, but they don’t touch. Compare each with the pothole between them.",
  potUndo:"↶ Undo",
  potLocked:"Pebble: “We don’t know where the oldest potholes are yet… The porter’s old map should mark them. Let’s align that map first!”",
  gateTitle:"Final Puzzle | The Mycelium Gate",
  gateIntro:"The gate has two sockets. Choose two items from your bag to place in them and reconnect the memories of both places.",
  gateLeft:"Left socket: engraved with three mountain landmarks", gateRight:"Right socket: a wavy rock-grain pattern",
  gateActivate:"✨ Activate the gate",
  gateNeedTwo:"Choose exactly two items (you have {n}).",
  gateWrong:"“{item}” doesn’t fit. One socket shows mountain landmarks; the other shows rock grain.",
  gateOk:"Both items begin to glow!",
  endTitle:"The memories are reconnected!",
  endText:"The gondola, the mountain paths and the potholes in the stream were all part of one memory network. You recovered more than clues: you recovered stories that help others discover Maokong.",
  endMossy:"Thank you, {name}. Both routes’ memories are back, and Maokong’s memory network is glowing again!",
  endTime:"Play time: {m} min", endHints:"Hints used: {n}", endTries:"Attempts: {n}",
  endAsk:"Your feedback directly shapes the next version (about 3 minutes):",
  endFeedback:"📝 Give Feedback 填寫回饋 ↗",
  endPid:"Anonymous play ID: {id}",
  endKeep:"Keep exploring", endLearned:"What you discovered:",
  endFacts:["The Maokong Gondola: opened 2007, suspended 2008, reopened 2010","How the name “Maokong” relates to streambed potholes","How potholes form, and how geologists tell which came first","Mountain porters and Muzha Tieguanyin tea culture"],
  tutMapNode:"Training Grove", tutScene:"Training Grove",
  tutStump:"Tree stump", tutAcorn:"Practice acorn", tutAcornDesc:"A tutorial item. In the real adventure, items can be “used” or placed into mechanisms.",
  tutStumpText:"A shiny acorn is hidden in a hollow of the stump.",
  tutPuzzle:"Practice puzzle", tutPuzzleOk:"Solved!",
  tutMossyHint:"Hint 1 / 3: Every puzzle has three hint levels, each more specific. There is no penalty.",
  tutDone:"Great! You’ve learned every control. Maokong Station is unlocked.",
  tutGo:"Start the adventure →",
  speaker:"Mossy"
}};

/* ---------- prologue (15 s) ---------- */
const STORY = [
 {t:0, zh:"貓空的山林裡，藏著一張看不見的「記憶菌絲網」，連起茶香、山路與人們的故事。", en:"Beneath the hills of Maokong lies an invisible memory network, linking tea, mountain paths and people’s stories."},
 {t:4, zh:"但一場名為「The Fading（褪色）」的異變，正讓這些記憶一點一點消失。", en:"But a strange change called The Fading is making these memories disappear, one by one."},
 {t:8, zh:"你好，我是 Mossy。我需要一位記憶守護者——就是你。", en:"Hello, I’m Mossy. I need a Memory Guardian — and that’s you."},
 {t:12,zh:"跟我一起走進貓空，把記憶找回來吧！", en:"Come with me into Maokong. Let’s bring the memories back!"}
];
const STORY_LEN = 15;

/* ---------- tutorial steps ---------- */
const TUT_STEPS = [
 {id:"map",  zh:"嗨，我是 Mossy！貓空的記憶正在消失，需要你幫忙找回來。先練習一下：點地圖上跳動的「練習林地」。", en:"Hi, I’m Mossy! Maokong’s memories are fading and I need your help. Let’s practise first: tap the bouncing “Training Grove” on the map."},
 {id:"hot",  zh:"場景裡發光的東西可以調查。點一下「樹樁」。", en:"Glowing things in a scene can be investigated. Tap the “Tree stump”."},
 {id:"bag",  zh:"你拿到了道具！點上方的 🎒「背包」看看它。", en:"You got an item! Tap 🎒 “Bag” at the top to look at it."},
 {id:"puz",  zh:"拼圖：先點一片，再點另一片，兩片會交換。把圖拼回來！", en:"Puzzle: tap one piece, then another, and they swap. Fix the picture!"},
 {id:"npc",  zh:"卡住的時候，點 Mossy 的「對話」或上方的「提示」。", en:"When you’re stuck, tap “Talk” next to Mossy, or “Hint” at the top."},
 {id:"end",  zh:"完成機關就能解鎖新地點。準備好了嗎？", en:"Solving puzzles unlocks new places. Ready?"}
];

/* ---------- items ---------- */
const ITEMS = {
 log:{ico:"📒", zh:"維護員筆記", en:"Maintenance log",
   d:{zh:"一本潮濕的值班筆記，記著兩條值班表線索。可隨時在這裡重讀。", en:"A damp duty notebook holding two roster clues. Re-read it here any time."}},
 tally:{ico:"🎋", zh:"挑夫竹籤", en:"Porter’s tally stick",
   d:{zh:"挑夫用來記錄挑運次數的竹籤，背面刻著一條線索。", en:"A bamboo stick porters used to count their loads. A clue is carved on the back."}},
 pic:{ico:"🖼️", zh:"纜車記憶圖", en:"Gondola memory picture",
   d:{zh:"你修復的貓空記憶圖：鋼索由左下往右上升，通往山頂的貓空站。", en:"The picture you restored: the cable rises from lower left to Maokong Station on the hilltop."}},
 plate:{ico:"🪙", zh:"站務室銅片", en:"Station copper plate",
   d:{zh:"刻著三座山地標的銅片，背面有一排古老符號的對照表。看起來能用在一張舊地圖上。", en:"A copper plate engraved with three mountain landmarks. The back has a key to some old symbols — it looks useful on an old map."}},
 rubbing:{ico:"📜", zh:"溪谷岩層拓印", en:"Valley rock rubbing",
   d:{zh:"從最古老的壺穴邊緣拓下的波浪狀岩紋。", en:"A rubbing of the wavy rock grain from the rim of the oldest pothole."}},
 core:{ico:"✨", zh:"菌絲記憶核", en:"Mycelium memory core",
   d:{zh:"兩個場景的記憶連結後形成的發光核心。", en:"A glowing core formed when the memories of both places reconnected."}}
};

/* ---------- logic puzzle: single source of truth ----------
   The solution is NOT hard-coded: it is computed from these clues at runtime
   (solveLogic in game.js) and the tests assert it is unique and matches the README. */
const LOGIC = {
 people:[{zh:"茶師",en:"Tea master"},{zh:"旅人",en:"Traveler"},{zh:"維護員",en:"Maintenance worker"},{zh:"挑夫",en:"Porter"}],
 things:[{zh:"茶籃",en:"tea basket"},{zh:"地圖",en:"map"},{zh:"指南針",en:"compass"},{zh:"燈籠",en:"lantern"}],
 // forbid: [personIndex, thingIndex]
 clues:[
  {id:"c1", src:"log",     forbid:[[1,0],[1,2]], zh:"旅人沒有帶茶籃，也沒有帶指南針。", en:"The traveler carried neither the tea basket nor the compass.",
    where:{zh:"站務室的筆記本",en:"the notebook in the station"}},
  {id:"c2", src:"log",     forbid:[[0,3],[0,1]], zh:"茶師沒有帶燈籠，也沒有帶地圖。", en:"The tea master carried neither the lantern nor the map.",
    where:{zh:"站務室的筆記本",en:"the notebook in the station"}},
  {id:"c3", src:"porter",  forbid:[[3,1],[3,2]], zh:"挑夫帶的不是地圖，也不是指南針。", en:"The porter carried neither the map nor the compass.",
    where:{zh:"挑夫的竹籤",en:"the porter’s tally stick"}},
  {id:"c4", src:"board",   forbid:[[1,3]],       zh:"提著燈籠的人不是旅人。", en:"Whoever carried the lantern was not the traveler.",
    where:{zh:"告示板",en:"the notice board"}},
  {id:"c5", src:"cabinet", forbid:[[2,0],[2,3]], zh:"維護員沒有帶茶籃，也沒有帶燈籠。", en:"The maintenance worker carried neither the tea basket nor the lantern.",
    where:{zh:"站務櫃上的名牌",en:"the name tag on the station cabinet"}}
 ]
};

/* ---------- map-alignment puzzle (single source of truth) ----------
   Grid 9 x 6. New map landmarks are fixed; the old map is drawn at (landmark + offset).
   The player starts at offset START and must reach offset 0,0. Hints are generated from START. */
const OVERLAY = {
 cols:8, rows:8,
 // old map starts rotated (k quarter-turns clockwise) AND shifted. Solved when k%4==0 and x==y==0.
 start:{x:-2, y:1, k:3},
 marks:[
  {k:"bridge", x:4, y:5, ico:"🌉", glyph:"≡", zh:"橋", en:"bridge"},
  {k:"tree",   x:2, y:2, ico:"🌳", glyph:"♣", zh:"老樹", en:"old tree"},
  {k:"stone",  x:6, y:3, ico:"🪨", glyph:"▲", zh:"石碑", en:"stone marker"}
 ],
 decoys:[
  {x:6, y:6, glyph:"✕", zh:"舊營地（不是地標）", en:"old campsite (not a landmark)"},
  {x:1, y:5, glyph:"○", zh:"水井（不是地標）", en:"well (not a landmark)"},
  {x:4, y:1, glyph:"◇", zh:"茶寮（不是地標）", en:"tea hut (not a landmark)"}
 ],
 star:{x:1, y:7},
 limit:4
};

/* ---------- pothole puzzle (single source of truth) ----------
   order = oldest -> youngest. cuts: [younger, older] pairs that physically overlap. */
const POTHOLES = {
 pots:{A:{x:205,y:150,r:50}, B:{x:355,y:128,r:44}, C:{x:118,y:178,r:56}, D:{x:290,y:170,r:47}},
 order:["C","A","D","B"],
 cuts:[["A","C"],["D","A"],["B","D"]]
};

/* ---------- hotspots & documents ---------- */
const DOCS = {
 gondola:{type:"fact", zh:{t:"貓空纜車的轉折", b:"貓空纜車於 2007 年 7 月 4 日通車，連接臺北市立動物園與貓空，全長約 4 公里，設有動物園、動物園南、指南宮、貓空四個載客站。2008 年颱風豪雨使塔柱周邊土石流失，纜車在同年 10 月停駛；經過檢修與邊坡整治，於 2010 年 3 月底恢復營運。"},
   en:{t:"Turning points of the Maokong Gondola", b:"The Maokong Gondola opened on 4 July 2007. It runs about 4 km from Taipei Zoo to Maokong, with four passenger stations: Taipei Zoo, Taipei Zoo South, Zhinan Temple and Maokong. In 2008, typhoon rains washed away soil around a support tower, and service stopped that October. After repairs and slope stabilisation, it reopened at the end of March 2010."}},
 porters:{type:"fact", zh:{t:"挑夫與山路", b:"在公路與纜車出現之前，山區的茶葉、農產與日用品，常仰賴人力沿著山路挑運。挑夫用扁擔挑起重擔，往返於茶園、村落與山下市集之間。今天貓空的許多步道，仍讓人想像當年翻山越嶺的生活。"},
   en:{t:"Porters and mountain paths", b:"Before roads and the gondola, tea, crops and everyday goods in these hills were often carried on foot. Porters balanced heavy loads on shoulder poles, walking between tea farms, villages and the markets below. Many of Maokong’s trails today still trace that way of life."}},
 tea:{type:"fact", zh:{t:"木柵鐵觀音", b:"木柵是臺灣鐵觀音茶的重要產區。一般記載，19 世紀末前後，張迺妙等茶人從福建安溪帶回鐵觀音茶苗，在木柵山區栽種，逐漸發展出焙火較重、帶熟果香的木柵鐵觀音風格。貓空一帶也以文山包種茶和山間茶館聞名。"},
   en:{t:"Muzha Tieguanyin tea", b:"Muzha is one of Taiwan’s best-known homes of Tieguanyin oolong. According to common accounts, tea growers including Zhang Nai-miao brought Tieguanyin plants from Anxi in Fujian around the end of the 19th century and grew them in the Muzha hills. Over time a distinctive, more deeply roasted style with ripe-fruit notes developed. Maokong is also known for Wenshan Baozhong tea and hillside teahouses."}},
 otherValley:{type:"fiction", zh:{t:"調查筆記：另一座山谷", b:"混進來的兩片碎片，來自另一座山谷的記憶。那裡的纜車鋼索由左上往右下「下降」，車廂漆成藍色，山壁上還掛著一道瀑布。而這張貓空記憶圖裡，鋼索由左下往右上「上升」，三個車廂都是紅色。"},
   en:{t:"Field note: the other valley", b:"Two stray pieces come from the memory of another valley. There, the cable DESCENDS from upper left to lower right, the cabins are painted blue, and a waterfall hangs on the cliff. In this picture of Maokong, the cable RISES from lower left to upper right, and all three cabins are red."}},
 potholes:{type:"fact", zh:{t:"壺穴是怎麼形成的？", b:"壺穴是溪床岩盤上圓形或橢圓形的凹洞。水流在岩面的低窪處形成漩渦，帶著砂石不斷旋轉、磨蝕岩石，凹洞便慢慢加深、擴大。這需要很長的時間，也和岩石的軟硬、水量與砂石多寡有關。"},
   en:{t:"How do potholes form?", b:"Potholes are round or oval hollows in a streambed’s bedrock. Where water swirls in a dip in the rock, it spins sand and pebbles around and around, grinding the hollow deeper and wider. This takes a very long time, and depends on how hard the rock is, how much water flows and how much sediment it carries."}},
 name:{type:"fact", zh:{t:"「貓空」這個名字", b:"貓空一帶的溪谷岩床佈滿壺穴，坑坑洞洞、凹凸不平。臺語形容這種樣子為「皺空」（jiàu-khang），日治時期改寫為發音相近的「貓空」，地名就此沿用。所以「貓空」和貓咪其實沒有直接關係！"},
   en:{t:"The name “Maokong”", b:"The rocky streambeds here are full of potholes, bumpy and uneven. In Taiwanese, that look was described as “jiàu-khang” (皺空, roughly “wrinkled hollows”). During the Japanese colonial era it was written with the similar-sounding characters 貓空 — literally “cat + empty”. So the name has nothing to do with cats!"}},
 crosscut:{type:"fact", zh:{t:"小岩的野外筆記：截切關係", b:"地質學家判斷先後順序時，常用「截切關係」：如果一個地質特徵切過另一個，切過去的那個比較年輕。在溪床上，新的壺穴變大時會咬破旁邊舊壺穴的邊緣——邊緣保持完整的較年輕，被咬掉一塊的較古老。"},
   en:{t:"Pebble’s field note: cross-cutting", b:"Geologists often use the principle of cross-cutting relationships: if one feature cuts across another, the one doing the cutting is younger. In a streambed, a growing new pothole bites into the rim of an older neighbour. The pothole whose rim stays complete is younger; the one with a bite taken out is older."}}
};

/* Hint text. Some third-level hints are generated from puzzle data in game.js. */
const HINTS = {
 explore:{zh:["先點擊場景裡發光的物件，看看能找到什麼。","有「新」光圈的物件都還沒調查過。","從「地圖框」開始，修復記憶圖。"],
          en:["Tap glowing objects in the scene to see what you can find.","Objects with a pulsing ring haven’t been investigated yet.","Start with the “Map frame” and restore the memory picture."]},
 jigsaw:{zh:["先讀「調查筆記：另一座山谷」（在地圖框旁），它說明了混進來的碎片長什麼樣子。","這張貓空圖的鋼索由左下往右上「上升」、車廂是紅的。鋼索往下走、有藍色車廂或瀑布的碎片，放到候選區。","從四個角開始：太陽在左上、貓空站在右上角山頂、茶園在右下角、小車站在左下角。上排的太陽、白雲、飛鳥都橫跨兩片，接縫要接得起來；再沿鋼索把三個紅色車廂接起來。"],
         en:["Read “Field note: the other valley” (next to the puzzle). It describes the stray pieces.","In this picture the cable RISES to the right and the cabins are red. Pieces with a descending cable, a blue cabin or a waterfall go to the spare tray.","Start with the corners: the sun is top-left, Maokong Station top-right on the hill, tea bushes bottom-right, a small station bottom-left. In the top row the sun, the cloud and the birds each span two pieces — their halves must join. Then link the three red cabins along the cable."]},
 logic:{zh:["先找齊五條線索：筆記本（兩條）、告示板、挑夫竹籤、站務櫃名牌。","看旅人：他不帶茶籃、不帶指南針，也不提燈籠——只剩一種可能。","旅人帶地圖。再看維護員：不帶茶籃、不帶燈籠，地圖又被旅人拿走了，所以他帶指南針。剩下茶師和挑夫，用線索排除就好。"],
        en:["Find all five clues first: the notebook (two), the notice board, the porter’s tally stick and the cabinet name tag.","Look at the traveler: no tea basket, no compass, and not the lantern — only one option remains.","The traveler has the map. The maintenance worker has no basket and no lantern, and the map is taken, so: the compass. Use the clues to settle the tea master and the porter."]},
 plate:{zh:["舊地圖上的符號需要對照表。","你在站務櫃拿到了一件刻著地標的道具。","打開背包，對「站務室銅片」按「使用」。"],
        en:["The old map’s symbols need a key.","You took an engraved object from the station cabinet.","Open your bag and press “Use” on the Station copper plate."]},
 overlay:{zh:["先比較兩張地圖角落的「北方箭頭 N」。舊地圖被轉歪了，先用 ↻ 把它的箭頭轉到朝上。","轉正之後，用銅片的對照表找出 ≡、♣、▲ 各是哪個地標。先只對齊一組（例如 ♣ 對老樹），再看另外兩組有沒有一起重合。✕、○、◇ 都不是地標。"],
          en:["Compare the “N” north arrows in the corners of both maps. The old map has been turned — use ↻ until its arrow points up.","Once it’s upright, use the copper plate’s key to work out which landmark ≡, ♣ and ▲ stand for. Align one pair first (e.g. ♣ on the old tree), then check the other two. ✕, ○ and ◇ are not landmarks."]},
 potholes:{zh:["讀小岩的「截切關係」筆記：切過別人的那一個比較年輕。","兩個壺穴交疊時，邊緣完整的較年輕。找出「沒有咬掉任何壺穴」、自己卻被咬掉的那一個——它最老。"],
           en:["Read Pebble’s note on cross-cutting: whatever cuts across another is younger.","Where two potholes overlap, the one with the complete rim is younger. Find the one that bites into no other pothole but has been bitten — it is the oldest."]},
 gate:{zh:["看看兩個凹槽的圖案：一個是山的地標，一個是岩石紋理。","哪件道具刻著三座山的地標？哪件道具記錄了岩石的紋理？","放入「站務室銅片」與「溪谷岩層拓印」。"],
       en:["Look at the two sockets: one shows mountain landmarks, the other rock grain.","Which item is engraved with three mountain landmarks? Which records the texture of rock?","Place the Station copper plate and the Valley rock rubbing."]},
 toValley:{zh:["貓空站的任務完成了，下一站在別的地方。","地圖上「壺穴步道」已經亮起來了。","點上方的「地圖」，再點「壺穴步道」。進去後調查「舊地圖」。"],
         en:["You’ve finished at Maokong Station. The next place is elsewhere.","The “Pothole Trail” is now glowing on the map.","Tap “Map” at the top, then “Pothole Trail”. Inside, examine the “Old map”."]}
};

const SCENES = {
 station:{
  chapter:{zh:"第一章 · 交通的記憶", en:"Chapter 1 · Memories of the journey"},
  name:{zh:"貓空站", en:"Maokong Station"}, sign:"貓空站",
  lead:{zh:"纜車站的記憶圖被撕碎了，站務櫃也被一道值班表鎖鎖住。調查站內，找出通往溪谷的線索。", en:"The station’s memory picture has been torn apart, and the cabinet is sealed with a duty-roster lock. Investigate the station and find the way to the valley."},
  npc:"mossy",
  hots:[
   {id:"frame",  x:50, y:40, ico:"🖼️", zh:"地圖框", en:"Map frame"},
   {id:"board",  x:19, y:30, ico:"📋", zh:"告示板", en:"Notice board"},
   {id:"log",    x:79, y:66, ico:"📒", zh:"筆記本", en:"Notebook"},
   {id:"porter", x:24, y:72, ico:"🎋", zh:"挑夫竹籤", en:"Tally stick"},
   {id:"cabinet",x:82, y:36, ico:"🗄️", zh:"站務櫃", en:"Cabinet"}
  ]},
 valley:{
  chapter:{zh:"第二章 · 岩石的記憶", en:"Chapter 2 · Memories in the rock"},
  name:{zh:"壺穴步道", en:"Pothole Trail"}, sign:"壺穴步道",
  lead:{zh:"溪谷裡的岩盤佈滿圓形凹洞。地質探險家小岩在這裡等你。校準挑夫的舊地圖，找出最古老的壺穴，再打開記憶菌絲門。", en:"The bedrock here is dotted with round hollows. Pebble, a rock explorer, is waiting for you. Align the porter’s old map, find the oldest potholes, then open the Mycelium Gate."},
  npc:"pebble",
  hots:[
   {id:"oldmap",  x:22, y:30, ico:"🗺️", zh:"舊地圖", en:"Old map"},
   {id:"rocks",   x:47, y:70, ico:"🪨", zh:"溪床岩盤", en:"Streambed"},
   {id:"sign",    x:73, y:24, ico:"🪧", zh:"步道告示", en:"Trail sign"},
   {id:"potfield",x:78, y:74, ico:"🕳️", zh:"壺穴群", en:"Potholes"},
   {id:"gate",    x:50, y:33, ico:"🍄", zh:"菌絲門", en:"Gate"}
  ]}
};

/* Station dialogue with Mossy (choices) and valley dialogue with Pebble */
const DIALOGUE = {
 mossy:{name:{zh:"Mossy",en:"Mossy"},
  open:{zh:"這裡是貓空纜車的終點站。記憶褪色以後，連站務員的值班表都散掉了……你想先問我什麼？",
        en:"This is the top station of the Maokong Gondola. Since The Fading began, even the station’s duty roster has fallen apart… What would you like to ask me?"},
  q:[
   {q:{zh:"什麼是記憶菌絲網？",en:"What is the memory network?"},
    a:{zh:"菌絲在土裡連起一棵棵樹。我們相信貓空的記憶也是這樣連在一起的：茶園、山路、纜車和溪谷，彼此都有關係。（這是遊戲的奇幻設定喔！）",
       en:"Fungal threads link trees together underground. We imagine Maokong’s memories are linked the same way: tea farms, paths, the gondola and the valley all connect. (That part is our fantasy story!)"}},
   {q:{zh:"纜車一直都在嗎？",en:"Has the gondola always been here?"},
    a:{zh:"沒有喔。纜車 2007 年才通車，在那之前，茶葉和貨物多半靠人力挑下山。告示板上有更多故事。",
       en:"No! The gondola only opened in 2007. Before that, tea and goods were mostly carried down the mountain by hand. The notice board has more."}},
   {q:{zh:"我該從哪裡開始？",en:"Where should I start?"},
    a:{zh:"先修復地圖框裡的記憶圖。小心，有兩片碎片是別的山谷混進來的。",
       en:"Start by restoring the picture in the map frame. Careful — two pieces slipped in from another valley."}}
  ]},
 pebble:{name:{zh:"小岩",en:"Pebble"},
  open:{zh:"你就是 Mossy 說的記憶守護者？我是小岩，專門研究岩石。這片溪床的壺穴，記錄了好幾萬年的水流。",
        en:"You must be the Memory Guardian Mossy told me about! I’m Pebble, and I study rocks. The potholes in this streambed hold a record of water flowing for a very long time."},
  q:[
   {q:{zh:"貓空的名字跟貓有關嗎？",en:"Is “Maokong” named after cats?"},
    a:{zh:"哈哈，很多人都這樣以為！其實跟這些坑坑洞洞的壺穴有關。去看看那邊的步道告示吧。",
       en:"Ha, lots of people think so! It actually comes from these bumpy potholes. Go and read the trail sign over there."}},
   {q:{zh:"怎麼知道哪個壺穴比較老？",en:"How can you tell which pothole is older?"},
    a:null, doc:"crosscut"},
   {q:{zh:"我們要做什麼？",en:"What do we need to do?"},
    a:{zh:"先校準挑夫的舊地圖，它標出了最古老的壺穴。然後我們從那裡拓下岩紋，就能打開菌絲門。",
       en:"First align the porter’s old map — it marks the oldest potholes. Then we take a rubbing of the rock there, and that opens the Mycelium Gate."}}
  ]}
};

/* objectives shown under the top bar */
const OBJ = {
 enterStation:{zh:"在地圖上點「貓空站」開始調查。", en:"Tap “Maokong Station” on the map to begin."},
 jig:{zh:"修復地圖框裡的記憶圖（18 選 16）。", en:"Restore the memory picture in the map frame (choose 16 of 18)."},
 logic:{zh:"找齊線索，解開站務櫃的值班表鎖（已找到 {n} / 5）。", en:"Find the clues and crack the cabinet’s duty-roster lock (found {n} / 5)."},
 toValley:{zh:"打開地圖，前往「壺穴步道」。", en:"Open the map and travel to the “Pothole Trail”."},
 plate:{zh:"調查挑夫的舊地圖，用站務室銅片解讀它的符號。", en:"Examine the porter’s old map and use the copper plate to read its symbols."},
 overlay:{zh:"校準舊地圖，讓三個地標同時重合。", en:"Align the old map so all three landmarks overlap."},
 pot:{zh:"到「壺穴群」判讀壺穴年代（最老 → 最年輕）。", en:"Go to the “Potholes” and order them from oldest to youngest."},
 gate:{zh:"把兩件正確的道具放進記憶菌絲門。", en:"Place the two right items into the Mycelium Gate."},
 done:{zh:"試玩完成！請花 3 分鐘填寫回饋表單，幫助我們改進。", en:"Playtest complete! Please spend 3 minutes on the feedback form to help us improve."}
};
const MISC = {
 tutGrove:{zh:"練習林地", en:"Training Grove"},
 nextLbl:{zh:"下一步", en:"Next"},
 cabinetLocked:{zh:"櫃門上有一道「值班表鎖」，但被發光的菌絲纏住了。先修復地圖框裡的記憶圖，菌絲才會退開。", en:"The cabinet door has a “duty-roster lock”, but glowing threads are wrapped around it. Restore the memory picture in the frame first and the threads will pull back."},
 cabinetTag:{zh:"櫃子上的名牌寫著：", en:"A name tag on the cabinet reads:"},
 cabinetOpen:{zh:"櫃門打開了。你已經拿走了裡面的銅片。", en:"The cabinet is open. You already took the copper plate inside."},
 cabinetGot:{zh:"櫃門「喀」一聲打開——裡面放著一片刻著三座山的銅片！", en:"Click! The cabinet swings open — inside is a copper plate engraved with three mountains!"},
 logTitle:{zh:"維護員筆記", en:"Maintenance log"},
 logText:{zh:"潮濕的筆記本上，只剩兩行字還看得清楚：", en:"Only two lines in the damp notebook are still readable:"},
 boardTitle:{zh:"告示板", en:"Notice board"},
 boardText:{zh:"告示板一角釘著一張褪色的值班便條：", en:"A faded duty note is pinned to a corner of the board:"},
 porterTitle:{zh:"挑夫竹籤", en:"Porter’s tally stick"},
 porterText:{zh:"扁擔旁的竹籤上刻著一行字：", en:"A line is carved into the tally stick beside the shoulder pole:"},
 frameDone:{zh:"記憶圖已修復。", en:"The memory picture is restored."},
 rocksTitle:{zh:"溪床岩盤", en:"Streambed bedrock"},
 signTitle:{zh:"步道告示", en:"Trail sign"},
 picTitle:{zh:"纜車記憶圖", en:"Gondola memory picture"},
 open:{zh:"打開", en:"Open"},
 continueBtn:{zh:"繼續", en:"Continue"},
 valleyOpened:{zh:"兩條路線都解鎖了！路線 A 往「小天空步道、壺穴步道」，路線 B 往「樟樹步道」。", en:"Both routes are unlocked! Route A heads to the Xiaotiankong and Pothole Trails; Route B to the Camphor Tree Trail."},
 plateAlready:{zh:"銅片的對照表已經放在舊地圖上了。", en:"The copper plate’s key is already on the old map."},
 storyText:{zh:"貓空的土地、自然景觀與人們的記憶，透過一張神秘的「記憶菌絲網」彼此連結。一場名為 The Fading 的異變，正讓茶文化、地方歷史與人們的生活記憶逐漸消失。你受邀成為記憶守護者，和 Mossy 一起探索貓空、解開謎題，修復菌絲網。\n\n遊戲中的角色、菌絲網與記憶碎片是虛構的；標示「史實」的資料卡則是真實的貓空歷史與地理。", en:"Maokong’s land, landscapes and people’s memories are linked by a mysterious memory network. A strange change called The Fading is erasing tea culture, local history and everyday memories. You have been invited to become a Memory Guardian: explore Maokong with Mossy, solve puzzles and repair the network.\n\nThe characters, the network and the memory fragments are fiction. Cards marked “History / fact” contain real history and geography of Maokong."},
 npcStation0:{zh:"這些碎片看起來好像……但山稜和鋼索不會無緣無故斷掉。先看看地圖框吧！", en:"These pieces look so alike… but ridgelines and cables don’t just break off. Let’s look at the map frame!"},
 npcStation1:{zh:"記憶圖修好了！現在站務櫃的菌絲退開了，去找值班表的線索吧。", en:"The picture is fixed! The threads around the cabinet have pulled back. Let’s find the roster clues."},
 npcStation2:{zh:"銅片到手了！溪谷就在山下，我們出發吧。", en:"We have the copper plate! The valley is just down the hill. Let’s go."},
 npcValley0:{zh:"挑夫的舊地圖就在那塊石頭上。符號很古老，你帶了什麼能幫忙解讀的東西嗎？", en:"The porter’s old map is on that rock. The symbols are ancient — did you bring anything that could help read them?"},
 npcValley1:{zh:"太好了，現在可以看懂符號了！把舊地圖對齊新地圖吧。", en:"Great, now we can read the symbols! Line the old map up with the new one."},
 npcValley2:{zh:"舊地圖標出了最古老的壺穴群！去下游的「壺穴群」看看。", en:"The old map marks the oldest potholes! Let’s check the “Potholes” downstream."},
 npcValley3:{zh:"拓印完成！現在去打開菌絲門吧。", en:"Rubbing done! Now let’s open the Mycelium Gate."},
 npcValley4:{zh:"我們做到了！記憶又連起來了。", en:"We did it! The memories are connected again."},
 logicHidden:{zh:"這個 ✓ 和一條你還沒找到的線索矛盾。繼續在站內搜尋吧。", en:"That ✓ contradicts a clue you haven’t found yet. Keep searching the station."},
 ovWrongSym:{zh:"有 {k} 個地標上壓著符號，但符號和銅片的對照不符。", en:"{k} landmark(s) have a symbol on them, but it doesn’t match the copper plate’s key."},
 practiceAcornUse:{zh:"這是教學用的道具，留著當紀念吧！", en:"This is just a tutorial item — keep it as a souvenir!"},
 rubbingView:{zh:"波浪狀的岩紋，邊緣有一道被新壺穴咬過的弧線。", en:"Wavy rock grain, with an arc where a younger pothole bit into the rim."}
};

/* "About Maokong" panel on the world map — real history, marked as fact */
const ABOUT = {
 title:{zh:"認識貓空", en:"About Maokong"},
 intro:{zh:"貓空位在臺北市文山區（舊稱木柵）的山區，是臺北盆地邊緣的茶鄉。這裡有茶園、步道、溪谷壺穴，也有搭纜車上山喝茶的城市生活。", en:"Maokong lies in the hills of Wenshan District (formerly Muzha) on the edge of the Taipei Basin. It is a tea-growing area of tea farms, hiking trails and potholed streams — and a place where city people ride a gondola up the mountain for tea."},
 timeline:[
  {y:{zh:"19 世紀末前後", en:"Late 1800s"}, t:{zh:"一般記載，張迺妙等茶人從福建安溪帶回鐵觀音茶苗，在木柵山區種植，日後發展成「木柵鐵觀音」。", en:"According to common accounts, tea growers including Zhang Nai-miao brought Tieguanyin plants from Anxi, Fujian, and planted them in the Muzha hills — the start of “Muzha Tieguanyin”."}},
  {y:{zh:"日治時期", en:"Japanese era"}, t:{zh:"溪谷岩床坑坑洞洞，臺語叫「皺空」（jiàu-khang），後來改寫成發音相近的「貓空」。", en:"The bumpy, potholed streambeds were called “jiàu-khang” (wrinkled hollows) in Taiwanese; the name was later written with the similar-sounding characters 貓空."}},
  {y:{zh:"公路與纜車之前", en:"Before roads"}, t:{zh:"茶葉與日用品多靠挑夫沿山路挑運，往返茶園、村落與山下市集。", en:"Tea and everyday goods were mostly carried by porters along mountain paths, between tea farms, villages and markets below."}},
  {y:{zh:"1980 年", en:"1980"}, t:{zh:"時任臺北市長李登輝推動成立「木柵觀光茶園」，茶農開放茶園讓市民參觀，上山喝茶的茶館文化逐漸興盛。", en:"Under then-Taipei Mayor Lee Teng-hui, the Muzha Tourist Tea Garden was set up. Farmers opened their tea gardens to visitors, and hillside teahouse culture grew."}},
  {y:{zh:"2007 年", en:"2007"}, t:{zh:"7 月 4 日貓空纜車通車，從動物園到貓空全長約 4 公里。", en:"On 4 July the Maokong Gondola opened, running about 4 km from Taipei Zoo to Maokong."}},
  {y:{zh:"2008–2010 年", en:"2008–2010"}, t:{zh:"颱風豪雨造成塔柱周邊土石流失，纜車 2008 年 10 月停駛，2010 年 3 月底恢復營運。", en:"Typhoon rains eroded soil around a tower; the gondola stopped in October 2008 and reopened at the end of March 2010."}},
  {y:{zh:"今天", en:"Today"}, t:{zh:"台北大縱走第七段穿過政大後山與貓空一帶；茶園、步道與壺穴，都是認識貓空的入口。", en:"Section 7 of the Taipei Grand Hike crosses the hills behind NCCU and Maokong. Tea farms, trails and potholes are all ways into Maokong’s story."}}
 ]
};
