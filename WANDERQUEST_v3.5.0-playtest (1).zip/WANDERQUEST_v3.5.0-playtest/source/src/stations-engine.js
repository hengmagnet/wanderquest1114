/* ===================== v3.2: places, routes and the 9 data-driven stations ===================== */
const t2 = (k, vars) => { const v = UI2[lang()][k]; if (v === undefined) { console.warn("missing UI2 key", k); return k; } return fill(v, vars); };
const ORDER_ALL = ["station","a2","valley","a4","a5","a6","b2","b3","b4","b5","b6"];
const PREV = {station:null, a2:"station", valley:"station", a4:"valley", a5:"a4", a6:"a5", b2:"station", b3:"b2", b4:"b3", b5:"b4", b6:"b5"};
const nodeName = id => L(ART.MAP_NODES.find(n => n.id === id));
const isGeneric = id => !!STN[id];
function st(id){ if (!S.st) S.st = {}; if (!S.st[id]) S.st[id] = {}; return S.st[id]; }
function placeDone(id){ if (id === "station") return F("logic"); if (id === "valley") return F("gate"); return !!(S.st && S.st[id] && S.st[id].done); }
function placeOpen(id){ const p = PREV[id]; return p === null || placeDone(p); }
function suggestedNext(){ return ORDER_ALL.find(id => placeOpen(id) && !placeDone(id)) || null; }
function routeLabel(id){ if (id === "station") return t2("routeShared"); return ROUTE_A.includes(id) ? t2("routeAName") : t2("routeBName"); }

/* reward items for each station */
Object.keys(STN).forEach(id => { const r = STN[id].reward;
  ITEMS["r_"+id] = {ico:r.ico, zh:r.zh, en:r.en, d:{zh:"記憶碎片 · "+STN[id].name.zh+"："+PLACES[id].zh, en:"Memory fragment · "+STN[id].name.en+": "+PLACES[id].en}}; });

function docAny(key){ return DOCS[key] || DOCS2[key]; }

/* ---------- map: place card ---------- */
MODALS.place = function(a){
  const id = a.id, open = placeOpen(id), done = placeDone(id);
  let b = `<p class="small muted" style="margin:0">${esc(routeLabel(id))}</p>
    <div class="card"><span class="tag fact">${esc(t("factTag"))}</span><p style="margin:.4em 0 0">${esc(L(PLACES[id]))}</p></div>`;
  if (done) b += `<div class="feedback ok">${esc(t2("placeDone"))}</div>`;
  else if (!open) b += `<div class="feedback info">🔒 ${esc(t2("placeLocked",{prev:nodeName(PREV[id])}))}</div>`;
  b += `<div class="actions">${open ? `<button class="btn-primary pulse-target" data-act="enterPlace" data-arg="${id}" id="btn-enter">${esc(t2("placeEnter"))}</button>` : ""}<button data-act="close" id="btn-ok">${esc(t("close"))}</button></div>`;
  return sheet(nodeName(id), b);
};
ACT.enterPlace = id => {
  M = null; if (!placeOpen(id)) return render();
  timeTick(); S.scene = id; logEv("scene", id); save(); render(); window.scrollTo(0,0);
};

/* ---------- generic scene ---------- */
function genericSceneView(id){
  const s = STN[id], done = placeDone(id), showSign = lang() === "en";
  const nxt = nextTarget();
  const hots = s.hots.map(h => {
    const seen = S.seen.includes(id+":"+h.id), isN = nxt === "hot-"+h.id;
    return `<button class="hot ${seen?"seen":"new"} ${isN?"next":""}" ${isN?`data-next="👇 ${esc(L(MISC.nextLbl))}"`:""} style="left:${h.x}%;top:${h.y}%" data-act="hot" data-arg="${h.id}" id="hot-${h.id}"><span class="ico">${h.ico}</span><span class="htxt">${esc(L(h))}</span></button>`;
  }).join("");
  let after = "";
  if (done) {
    const n = suggestedNext();
    after = `<div class="feedback ok">${esc(t2("stnDone",{item:L(STN[id].reward)}))} ${n?`<br>${esc(t2("stnNext",{name:nodeName(n)}))}`:""}
      <div class="actions"><button class="btn-primary pulse-target" data-act="goMap" id="btn-stn-map">${esc(t2("stnBackMap"))}</button></div></div>`;
  }
  return `<div class="scene-head"><div><span class="chapter">${esc(L(s.chapter))}</span>
      <h1>${esc(L(s.name))}${showSign?`<span class="zh-sign" lang="zh-Hant">${s.sign}</span>`:""}</h1></div>
      <button data-act="goMap">← ${esc(t("btnMap"))}</button></div>
    <p class="muted" style="margin:0">${esc(L(s.lead))}</p>
    <div class="scenebox">${ART2.sceneSVG(s)}${hots}</div>
    <div class="npcbar"><img src="${IMG.mossy}" alt="Mossy"><p><b>Mossy${lang()==="zh"?"：":": "}</b>${esc(L(s.npc))}</p>
      <button class="talk btn-gold" data-act="genericTalk" id="btn-talk">💬 ${esc(t("talk"))}</button></div>
    <div class="steps"><span class="step ${done?"done":"now"}">${done?"✓":"▶"} ${esc(L(s.obj))}</span></div>${after}`;
}
function genericHot(id, hid){
  const s = STN[id], h = s.hots.find(x => x.id === hid); if (!h) return;
  markSeen(id+":"+hid);
  if (h.mech) return openModal("mech", {id});
  if (h.doc) return openModal("info", {title:h, docs:[h.doc]});
}
ACT.genericTalk = () => openModal("hint");

function stComplete(id){
  const S0 = st(id); if (S0.done) return;
  timeTick();
  S0.done = true; S0.doneAt = Date.now(); logEv("solved", id); award("r_"+id); save();
  placeReported(id);
}
function afterComplete(id){
  // called when the player closes a solved mechanism
  const all = ORDER_ALL.every(placeDone);
  if (all) { S.tEnd = S.tEnd || Date.now(); save(); M = {type:"ending", fb:null}; root.innerHTML = gameScreen(); renderModal(); return true; }
  if (id === "a6" || id === "b6") { M = {type:"routeEnd", arg:{route: id === "a6" ? "A" : "B"}, fb:null}; root.innerHTML = gameScreen(); renderModal(); return true; }
  return false;
}
MODALS.routeEnd = function(a){
  const other = a.route === "A" ? "b2" : "a2";
  const otherRoute = a.route === "A" ? ROUTE_B : ROUTE_A;
  const otherNext = otherRoute.find(id => placeOpen(id) && !placeDone(id));
  const name = a.route === "A" ? t2("routeAName") : t2("routeBName");
  const b = `<div class="ending"><div class="core">${a.route === "A" ? "🍵" : "🥾"}</div><h2>${esc(t2("routeEndTitle",{route:name}))}</h2><p>${esc(t2("routeEndText"))}</p>
    ${otherNext ? `<p><b>${esc(t2("routeEndOther",{name:nodeName(otherNext)}))}</b></p>` : ""}
    <div class="actions" style="justify-content:center"><button class="btn-primary" data-act="goMap" id="btn-route-map">${esc(t2("goMapBtn"))}</button></div></div>`;
  void other;
  return sheet(t2("routeEndTitle",{route:name}), b, true);
};

/* ---------- mechanism modal ---------- */
MODALS.mech = function(a){
  const id = a.id, s = STN[id], done = placeDone(id);
  let body = `<p>${esc(L(s.intro))}</p>` + MECH[s.kind].render(id, done) + fbHTML();
  body += done ? `${M && M.fb && M.fb.cls==="ok" ? "" : `<div class="feedback ok">${esc(t2("stnDone",{item:L(s.reward)}))}</div>`}<div class="actions"><button class="btn-primary" data-act="mechClose" data-arg="${id}" id="btn-ok">${esc(t2("stnContinue"))}</button></div>`
               : MECH[s.kind].controls(id);
  return sheet(L(s.title), body, true);
};
ACT.mechClose = id => { M = null; renderModal(); if (!afterComplete(id)) { root.innerHTML = gameScreen(); } };
function mechSolved(id, msgFn){ stComplete(id); setFb("ok", msgFn || (() => t2("stnDone",{item:L(STN[id].reward)}))); renderModal(); }
function mechFail(id, f){ tryCount(id); setFb("bad", f); renderModal(); }
const ctl = (id, extra = "") => `<div class="actions">${extra}</div>`;

const MECH = {};

/* spot the difference (A2) */
MECH.spot = {
  render(id, done){
    const S0 = st(id), found = done ? MECHDATA[id].targets.map((_,i)=>i) : (S0.found || []);
    const marks = found.map(i => { const g = MECHDATA[id].targets[i]; return `<circle cx="${g.x}" cy="${g.y}" r="${g.r}" fill="none" stroke="#e2b45c" stroke-width="5"/>`; }).join("");
    const newSvg = ART2.SPOT_NEW.replace("</svg>", marks + "</svg>");
    return `<div class="logic-wrap"><div><div class="small muted">${esc(t2("spotLeft"))}</div><div class="potwrap" style="aspect-ratio:400/260">${ART2.SPOT_OLD}</div></div>
      <div><div class="small"><b>${esc(t2("spotRight"))}</b></div><div class="potwrap" style="aspect-ratio:400/260;cursor:crosshair" data-act="spotClick" data-arg="${id}" id="spot-new">${newSvg}</div></div></div>
      <p class="small" style="text-align:center"><b>${esc(t2("spotFound",{n:found.length}))}</b></p>
      <ul class="cluelist">${found.map(i=>`<li>✔ ${esc(L(MECHDATA[id].targets[i]))}</li>`).join("")}</ul>`;
  },
  controls(id){ return ctl(id, `<button data-act="spotReset" data-arg="${id}">${esc(t2("stnReset"))}</button>`); }
};
ACT.spotClick = (id, el, ev) => {
  if (placeDone(id)) return;
  const r = el.getBoundingClientRect(), x = (ev.clientX - r.left) / r.width * 400, y = (ev.clientY - r.top) / r.height * 260;
  const S0 = st(id); S0.found = S0.found || [];
  const hit = MECHDATA[id].targets.findIndex((g,i) => !S0.found.includes(i) && Math.hypot(g.x-x, g.y-y) <= g.r);
  if (hit < 0) { const already = MECHDATA[id].targets.some(g => Math.hypot(g.x-x,g.y-y) <= g.r); if (!already) mechFail(id, () => t2("spotMiss")); return; }
  S0.found.push(hit); save(); M.fb = null;
  if (S0.found.length === MECHDATA[id].targets.length) return mechSolved(id);
  renderModal();
};
ACT.spotReset = id => { st(id).found = []; M.fb = null; save(); renderModal(); };

/* sorting (A4) */
MECH.sort = {
  render(id, done){
    const D = MECHDATA[id], S0 = st(id); const a = done ? D.samples.map(s=>s.ans) : (S0.a || D.samples.map(()=>-1));
    return `<div class="bag-grid">${D.samples.map((s,i)=>`<div class="item ${a[i]>=0?"sel":""}"><span class="small">${esc(L(s))}</span>
      <button data-act="sortTap" data-arg="${id}:${i}" id="sort-${i}" ${done?"disabled":""}>${a[i]<0?"❔ "+esc(t2("sortTap")):(a[i]===0?"🟤 ":"🟢 ")+esc(L(D.jars[a[i]]))}</button></div>`).join("")}</div>`;
  },
  controls(id){ return ctl(id, `<button class="btn-primary" data-act="sortCheck" data-arg="${id}" id="btn-mech-check">${esc(t2("stnCheck"))}</button>`); }
};
ACT.sortTap = a => { const [id,i] = a.split(":"); const D = MECHDATA[id], S0 = st(id); S0.a = S0.a || D.samples.map(()=>-1); S0.a[+i] = S0.a[+i] === 0 ? 1 : 0; M.fb = null; save(); renderModal(); };
ACT.sortCheck = id => { const D = MECHDATA[id], a = st(id).a || D.samples.map(()=>-1);
  const unset = a.filter(v=>v<0).length; if (unset) return mechFail(id, () => t2("sortUnset",{n:unset}));
  const wrong = D.samples.filter((s,i)=>s.ans!==a[i]).length; if (wrong) return mechFail(id, () => t2("sortWrong",{n:wrong}));
  mechSolved(id); };

/* pipes (A5) */
const DIRV = {t:[-1,0,"b"], b:[1,0,"t"], l:[0,-1,"r"], r:[0,1,"l"]};
function pipesInit(id){ const D = MECHDATA[id], S0 = st(id);
  if (!S0.rot) { do { S0.rot = D.tiles.map(row => row.map(() => Math.floor(Math.random()*4))); } while (pipesFlow(id, S0.rot).done); save(); }
  return S0.rot; }
function pipesFlow(id, rot){
  const D = MECHDATA[id], n = D.size, wet = new Set(); let done = false;
  const opens = (r,c) => ART2.OPEN[D.tiles[r][c]][rot[r][c]%4];
  if (!opens(0,0).includes("t")) return {wet, done};
  const q = [[0,0]]; wet.add("0,0");
  while (q.length) { const [r,c] = q.shift();
    for (const d of opens(r,c)) { if (r===n-1 && c===n-1 && d==="b") done = true;
      const [dr,dc,back] = DIRV[d], nr = r+dr, nc = c+dc;
      if (nr<0||nc<0||nr>=n||nc>=n) continue;
      if (!opens(nr,nc).includes(back)) continue;
      const k = nr+","+nc; if (!wet.has(k)) { wet.add(k); q.push([nr,nc]); } } }
  return {wet, done};
}
MECH.pipes = {
  render(id, done){
    const D = MECHDATA[id], rot = done && !st(id).rot ? D.sol : pipesInit(id), fl = pipesFlow(id, rot), n = D.size;
    let cells = ""; for (let r=0;r<n;r++) for (let c=0;c<n;c++) {
      cells += `<button class="tile" style="padding:0" data-act="pipeTap" data-arg="${id}:${r}:${c}" id="pipe-${r}-${c}" ${done||D.tiles[r][c]==="X"?"disabled":""} aria-label="${r+1}-${c+1}">${ART2.pipeTile(D.tiles[r][c], rot[r][c], fl.wet.has(r+","+c))}</button>`; }
    return `<div class="small" style="max-width:360px;margin:0 auto">⬇ ${esc(t2("pipesIn"))}</div>
      <div class="board n4" style="max-width:360px" id="pipe-board">${cells}</div>
      <div class="small" style="max-width:360px;margin:0 auto;text-align:right">${esc(t2("pipesOut"))} ⬇</div>
      <p class="small muted" style="text-align:center">${esc(t2("pipesTap"))}</p>`;
  },
  controls(id){ return ctl(id, `<button class="btn-primary" data-act="pipeCheck" data-arg="${id}" id="btn-mech-check">${esc(t2("stnCheck"))}</button>`); }
};
ACT.pipeTap = a => { const [id,r,c] = a.split(":"); const rot = pipesInit(id); rot[+r][+c] = (rot[+r][+c]+1)%4; M.fb = null; save();
  if (pipesFlow(id, rot).done) return mechSolved(id); renderModal(); };
ACT.pipeCheck = id => { if (pipesFlow(id, pipesInit(id)).done) return mechSolved(id); mechFail(id, () => t2("pipesWrong")); };

/* process order (A6) */
MECH.process = {
  render(id, done){
    const D = MECHDATA[id], S0 = st(id);
    if (!S0.tray) { let o; do { o = shuffle(D.steps.map(s=>s.id)); } while (o.join() === D.steps.map(s=>s.id).join()); S0.tray = o; save(); }
    const order = done ? D.steps.map(s=>s.id) : (S0.order || []);
    const step = sid => D.steps.find(s=>s.id===sid);
    return `<h3>${esc(t2("procSlots"))}</h3><ol class="cluelist" style="list-style:none">${D.steps.map((_,i)=>`<li class="${order[i]?"":"missing"}">${i+1}. ${order[i]?esc(L(step(order[i]))):"……"}</li>`).join("")}</ol>
      ${done ? "" : `<h3>${esc(t2("procTray"))}</h3><div class="choices">${S0.tray.filter(sid=>!order.includes(sid)).map(sid=>`<button data-act="procPick" data-arg="${id}:${sid}" id="proc-${sid}">${esc(L(step(sid)))}</button>`).join("")}</div>`}`;
  },
  controls(id){ return ctl(id, `<button class="btn-primary" data-act="procCheck" data-arg="${id}" id="btn-mech-check" ${(st(id).order||[]).length<6?"disabled":""}>${esc(t2("stnCheck"))}</button><button data-act="procUndo" data-arg="${id}">${esc(t2("procUndo"))}</button><button data-act="procReset" data-arg="${id}">${esc(t2("stnReset"))}</button>`); }
};
ACT.procPick = a => { const [id,sid] = a.split(":"); const S0 = st(id); S0.order = S0.order || []; if (!S0.order.includes(sid)) S0.order.push(sid); M.fb = null; save(); renderModal(); };
ACT.procUndo = id => { (st(id).order||[]).pop(); M.fb = null; save(); renderModal(); };
ACT.procReset = id => { st(id).order = []; M.fb = null; save(); renderModal(); };
ACT.procCheck = id => { const D = MECHDATA[id], order = st(id).order || [], right = D.steps.map(s=>s.id);
  const i = right.findIndex((sid,k) => order[k] !== sid);
  if (i < 0) return mechSolved(id);
  const placed = order[i], why = D.why[placed];
  // the step placed at i belongs later => explain why it can't happen yet
  if (why && right.indexOf(placed) > i) return mechFail(id, () => t2("procWrongWhy",{n:i+1, why:L(D.why[placed])}));
  mechFail(id, () => t2("procWrong",{n:i+1})); };

/* logic grid (B2, B4) — solution computed from clues, like puzzle 2 */
function gridSolve(G){ const forb = new Set(); G.clues.forEach(c=>c.forbid.forEach(([p,th])=>forb.add(p+","+th)));
  return perms(G.people.length).filter(a => a.every((th,p)=>!forb.has(p+","+th))); }
MECH.grid = {
  render(id, done){
    const G = MECHDATA[id].grid, S0 = st(id), n = G.people.length;
    const g = done ? G.answer.flatMap((th,p)=>G.things.map((_,k)=>k===th?2:0)) : (S0.g || Array(n*n).fill(0));
    const rows = G.people.map((p,pi)=>`<tr><th scope="row">${esc(L(p))}</th>${G.things.map((th,ti)=>{const v=g[pi*n+ti];
      return `<td><button class="m${v}" data-act="gridCell" data-arg="${id}:${pi*n+ti}" id="g-${pi}-${ti}" ${done?"disabled":""} aria-label="${esc(L(p))} / ${esc(L(th))}">${["","✕","✓"][v]}</button></td>`}).join("")}</tr>`).join("");
    return `<div class="logic-wrap"><div><table class="logic"><thead><tr><th></th>${G.things.map(th=>`<th>${esc(L(th))}</th>`).join("")}</tr></thead><tbody>${rows}</tbody></table>
      <p class="small muted">${esc(t("logicHow"))}</p></div><div><ul class="cluelist">${G.clues.map(c=>`<li>“${esc(L(c))}”</li>`).join("")}</ul></div></div>`;
  },
  controls(id){ return ctl(id, `<button class="btn-primary" data-act="gridCheck" data-arg="${id}" id="btn-mech-check">${esc(t2("stnCheck"))}</button><button data-act="gridReset" data-arg="${id}">${esc(t2("stnReset"))}</button>`); }
};
ACT.gridCell = a => { const [id,i] = a.split(":"); const G = MECHDATA[id].grid, n = G.people.length, S0 = st(id); S0.g = S0.g || Array(n*n).fill(0); S0.g[+i] = (S0.g[+i]+1)%3; M.fb = null; save(); renderModal(); };
ACT.gridReset = id => { st(id).g = null; M.fb = null; save(); renderModal(); };
ACT.gridCheck = id => { const G = MECHDATA[id].grid, n = G.people.length, g = st(id).g || Array(n*n).fill(0);
  const as = []; for (let p=0;p<n;p++){ const row = g.slice(p*n,p*n+n); if (row.filter(v=>v===2).length !== 1) return mechFail(id, () => t2("gridWrongRow")); as.push(row.indexOf(2)); }
  if (new Set(as).size !== n) return mechFail(id, () => t2("gridDup"));
  if (as.every((th,p)=>th===G.answer[p])) return mechSolved(id);
  const c = G.clues.find(c => c.forbid.some(([p,th]) => as[p]===th));
  mechFail(id, () => c ? t2("gridContra",{clue:L(c)}) : t("wrongTry")); };

/* 9-piece jigsaw with 2 decoys (B3) */
function jig9Init(id){ const S0 = st(id); if (!S0.board) { let ids; do { ids = shuffle([...Array(11).keys()]); } while (ids.slice(0,9).every((v,i)=>v===i)); S0.board = ids.slice(0,9); S0.tray = ids.slice(9); save(); } return S0; }
function jig9Tile(id, piece, where, i){
  const sel = SEL && SEL.id === id && SEL.where === where && SEL.i === i;
  const style = piece >= 9 ? `background-image:url("${ART2.DAY_URI[piece-9]}");background-size:100% 100%` : `background-image:url("${ART2.NIGHT_URI}");background-size:300% 300%;background-position:${(piece%3)*50}% ${Math.floor(piece/3)*50}%`;
  return `<button class="tile${sel?" sel":""}" style='${style}' data-act="j9Tap" data-arg="${id}:${where}:${i}" data-piece="${piece}" aria-label="${where} ${i+1}"></button>`;
}
MECH.jig9 = {
  render(id, done){
    const S0 = done && !st(id).board ? {board:[0,1,2,3,4,5,6,7,8], tray:[9,10]} : jig9Init(id);
    return `<div class="jig"><div><div class="board" style="grid-template-columns:repeat(3,1fr);max-width:360px" id="j9-board">${S0.board.map((p,i)=>jig9Tile(id,p,"board",i)).join("")}</div></div>
      <div>${done?"":`<div class="tray-label">${esc(t2("jig9Tray"))}</div><div class="tray" id="j9-tray">${S0.tray.map((p,i)=>jig9Tile(id,p,"tray",i)).join("")}</div>`}</div></div>`;
  },
  controls(id){ return ctl(id, `<button class="btn-primary" data-act="j9Check" data-arg="${id}" id="btn-mech-check">${esc(t2("stnCheck"))}</button><button data-act="j9Reset" data-arg="${id}">${esc(t2("stnReset"))}</button>`); }
};
ACT.j9Tap = a => { const [id,where,i] = a.split(":"); if (placeDone(id)) return; const S0 = jig9Init(id);
  if (!SEL || SEL.id !== id) { SEL = {id, where, i:+i}; return renderModal(); }
  if (SEL.where === where && SEL.i === +i) { SEL = null; return renderModal(); }
  const A = S0[SEL.where], B = S0[where]; [A[SEL.i], B[+i]] = [B[+i], A[SEL.i]]; SEL = null; M.fb = null; save(); renderModal(); };
ACT.j9Reset = id => { const S0 = st(id); S0.board = null; jig9Init(id); SEL = null; M.fb = null; renderModal(); };
ACT.j9Check = id => { const S0 = jig9Init(id);
  if (S0.board.every((p,i)=>p===i)) return mechSolved(id);
  if (S0.tray.some(p=>p<9)) return mechFail(id, () => t2("jig9Tray2"));
  mechFail(id, () => t2("jig9Wrong",{n:S0.board.filter((p,i)=>p!==i).length})); };

/* sound memory (B5) */
let AC = null, SIMON_PLAYING = false;
function tone(f){ try { AC = AC || new (window.AudioContext || window.webkitAudioContext)(); const o = AC.createOscillator(), g = AC.createGain();
  o.type = "sine"; o.frequency.value = f; g.gain.setValueAtTime(0.0001, AC.currentTime); g.gain.exponentialRampToValueAtTime(0.25, AC.currentTime+0.03); g.gain.exponentialRampToValueAtTime(0.0001, AC.currentTime+0.45);
  o.connect(g); g.connect(AC.destination); o.start(); o.stop(AC.currentTime+0.5); } catch(e){} }
function simonFlash(i){ const el = document.getElementById("simon-"+i); if (el) { el.classList.add("lit"); setTimeout(()=>el.classList.remove("lit"), 420); } tone(MECHDATA.b5.instruments[i].f); }
MECH.simon = {
  render(id, done){
    const D = MECHDATA[id], S0 = st(id), round = S0.round || 0;
    const status = done ? "" : SIMON_PLAYING ? t2("simonWatch") : S0.seq ? t2("simonYour") : "";
    return `<p class="small" style="text-align:center"><b>${done?"":esc(t2("simonRound",{r:round+1, n:D.rounds[Math.min(round,2)]}))}</b> ${esc(status)}</p>
      <div class="bag-grid" style="grid-template-columns:repeat(3,1fr)" id="simon-pad">${D.instruments.map((ins,i)=>`<button class="simon" data-act="simonTap" data-arg="${id}:${i}" id="simon-${i}" ${done?"disabled":""}><span style="font-size:30px">${ins.ico}</span><br><span class="small">${esc(L(ins))}</span></button>`).join("")}</div>
      <p class="small muted" style="text-align:center">${(S0.input||[]).length ? "●".repeat(S0.input.length) : ""}</p>`;
  },
  controls(id){ const S0 = st(id); return ctl(id, `<button class="btn-gold" data-act="simonListen" data-arg="${id}" id="btn-simon-listen">${esc(S0.seq ? t2("simonAgain") : t2("simonListen"))}</button>`); }
};
ACT.simonListen = id => { if (SIMON_PLAYING) return; const D = MECHDATA[id], S0 = st(id), round = S0.round || 0;
  if (!S0.seq) { S0.seq = Array.from({length:D.rounds[round]}, () => Math.floor(Math.random()*D.instruments.length)); }
  S0.input = []; save(); SIMON_PLAYING = true; M.fb = null; renderModal(); logEv("simon_listen", round);
  S0.seq.forEach((n,k) => setTimeout(() => simonFlash(n), 700 + k*750));
  setTimeout(() => { SIMON_PLAYING = false; if (M && M.type === "mech") renderModal(); }, 700 + S0.seq.length*750 + 200); };
ACT.simonTap = a => { const [id,i] = a.split(":"); if (SIMON_PLAYING || placeDone(id)) return; const D = MECHDATA[id], S0 = st(id);
  simonFlash(+i); if (!S0.seq) return;
  S0.input = S0.input || []; S0.input.push(+i);
  const k = S0.input.length - 1;
  if (S0.seq[k] !== +i) { S0.input = []; save(); return mechFail(id, () => t2("simonWrong")); }
  if (S0.input.length === S0.seq.length) { S0.round = (S0.round||0) + 1; S0.seq = null; S0.input = []; save();
    if (S0.round >= D.rounds.length) return mechSolved(id);
    setFb("ok", () => t2("simonGood")); return renderModal(); }
  save(); M.fb = null; renderModal(); };

/* route planning (B6) */
MECH.path = {
  render(id, done){
    const D = MECHDATA[id], S0 = st(id); const path = S0.path || [D.start];
    const on = (r,c) => path.findIndex(p=>p[0]===r&&p[1]===c);
    let cells = "";
    D.h.forEach((row,r) => row.forEach((hv,c) => {
      const k = on(r,c), cliff = hv < 0, isS = r===D.start[0]&&c===D.start[1], isG = r===D.goal[0]&&c===D.goal[1], isW = r===D.water[0]&&c===D.water[1];
      const shade = cliff ? "#5a4a46" : ["#e9f3dc","#d4e8c4","#bcdcab","#a3cd92","#8ab97b","#73a566"][hv];
      cells += `<button class="tile" style="background:${shade};${k>=0?"outline:4px solid #c4553a;outline-offset:-4px;":""}font-weight:800;color:${cliff?"#fff":"#213a31"}" data-act="pathTap" data-arg="${id}:${r}:${c}" id="path-${r}-${c}" ${done?"disabled":""}>
        <span style="font-size:13px">${cliff?"⛔":isS?"🚩":isG?"🏁":isW?"💦":""}</span><br>${cliff?"":hv}${k>0?`<sup style="color:#c4553a">${k}</sup>`:""}</button>`;
    }));
    return `<div class="board" style="grid-template-columns:repeat(6,1fr);max-width:420px" id="path-board">${cells}</div>
      <p class="small" style="text-align:center">${esc(t2("pathLen",{n:path.length-1}))}</p>`;
  },
  controls(id){ return ctl(id, `<button data-act="pathUndo" data-arg="${id}">${esc(t2("pathUndo"))}</button><button data-act="pathReset" data-arg="${id}">${esc(t2("stnReset"))}</button><button class="btn-primary" data-act="pathCheck" data-arg="${id}" id="btn-mech-check">${esc(t2("stnCheck"))}</button>`); }
};
ACT.pathTap = a => { const [id,r,c] = a.split(":").map((v,i)=>i?+v:v); if (placeDone(id)) return; const D = MECHDATA[id], S0 = st(id);
  S0.path = S0.path || [D.start]; const last = S0.path[S0.path.length-1];
  if (last[0]===r && last[1]===c) return;
  const prevIdx = S0.path.findIndex(p=>p[0]===r&&p[1]===c);
  if (prevIdx >= 0 && prevIdx === S0.path.length-2) { S0.path.pop(); save(); M.fb = null; return renderModal(); }   // tap previous square = step back
  const hv = D.h[r][c], hl = D.h[last[0]][last[1]];
  let why = null;
  if (Math.abs(last[0]-r) + Math.abs(last[1]-c) !== 1) why = t2("pathNotAdj");
  else if (hv < 0) why = t2("pathCliff");
  else if (prevIdx >= 0) why = t2("pathVisited");
  else if (Math.abs(hv-hl) > 1) why = t2("pathSteep",{a:hl, b:hv});
  if (why) { const w = why; return mechFail(id, () => t2("pathWrongStep",{why:w})); }
  S0.path.push([r,c]); save(); M.fb = null;
  if (r===D.goal[0] && c===D.goal[1]) return ACT.pathCheck(id);
  renderModal(); };
ACT.pathUndo = id => { const S0 = st(id); if (S0.path && S0.path.length > 1) S0.path.pop(); M.fb = null; save(); renderModal(); };
ACT.pathReset = id => { st(id).path = null; M.fb = null; save(); renderModal(); };
ACT.pathCheck = id => { const D = MECHDATA[id], path = st(id).path || [D.start], last = path[path.length-1];
  if (!(last[0]===D.goal[0] && last[1]===D.goal[1])) return mechFail(id, () => t2("pathNeedGoal"));
  if (!path.some(p=>p[0]===D.water[0]&&p[1]===D.water[1])) return mechFail(id, () => t2("pathNeedWater"));
  mechSolved(id); };

/* ---------- intro history dialog (must be read to enter) ---------- */
function historyScreen(){
  const items = [{y:null, t:ABOUT.intro}, ...ABOUT.timeline];
  const i = Math.max(0, Math.min(items.length-1, S.hIdx||0)), it = items[i], last = i === items.length-1;
  return `<div class="overlay"><div class="ob-card">
    <div class="ob-kicker">WANDERQUEST · ${esc(L(ABOUT.title))}</div>
    <h2 style="color:#fbe9b6;margin-top:6px">${esc(t2("histTitle"))}</h2>
    <div class="dlg" style="margin-top:14px"><img src="${IMG.mossy}" alt="Mossy" style="border-radius:16px"><div class="bubble" style="color:#213a31" id="hist-bubble">
      ${it.y ? `<span class="tag fact">${esc(t("factTag"))}</span><h3 style="margin:.3em 0;color:#7a5517">📜 ${esc(L(it.y))}</h3>` : `<b>Mossy${lang()==="zh"?"：":": "}</b>`}<p style="margin:.3em 0 0">${esc(L(it.t))}</p></div></div>
    <div style="display:flex;gap:6px;justify-content:center;margin:14px 0">${items.map((_,k)=>`<span style="width:9px;height:9px;border-radius:50%;background:${k<=i?"#f3d58f":"#45685c"}"></span>`).join("")}</div>
    <div class="ob-actions" style="justify-content:space-between">
      <button class="btn-ghost" data-act="histBack" ${i===0?"disabled":""}>${esc(t2("histBack"))}</button>
      ${last ? `<button class="btn-gold" data-act="histGo" id="btn-hist-go">${esc(t2("histGo"))}</button>` : `<button class="btn-gold" data-act="histNext" id="btn-hist-next">${esc(t2("histNext"))}</button>`}
    </div><p class="small" style="text-align:center;opacity:.75">${esc(t2("histRead"))}</p></div></div>`;
}
ACT.histNext = () => { S.hIdx = (S.hIdx||0) + 1; save(); render(); };
ACT.histBack = () => { S.hIdx = Math.max(0,(S.hIdx||0) - 1); save(); render(); };
ACT.histGo = () => { S.histRead = true; logEv("history_read"); onboardNext(); };

/* ---------- journey timeline (always visible under the objective) ---------- */
function journeyHTML(){
  const chip = id => {
    const n = ART.MAP_NODES.find(x => x.id === id), done = placeDone(id), here = S.scene === id, open = placeOpen(id);
    const cls = here ? "here" : done ? "done" : open ? "open" : "locked";
    const ico = done && !here ? "✓" : open || here ? n.ico : "🔒";
    return `<button class="jchip ${cls}" data-act="node" data-arg="${id}" id="prog-${id}" title="${esc(L(n))}" aria-label="${esc(L(n))}${here?" · "+esc(t2("jHere")):""}">
      <span class="jdot">${ico}</span><span class="jname">${esc(L(n))}</span>${here?`<span class="jhere">${esc(t2("jHere"))}</span>`:""}</button>`;
  };
  const done = ORDER_ALL.filter(placeDone).length;
  return `<nav class="journey" aria-label="${esc(t2("jTitle"))}">
    <div class="jhead"><b>🧭 ${esc(t2("jTitle"))}</b><span class="jcount">${done} / ${ORDER_ALL.length}</span><span class="jbar"><i style="width:${done/ORDER_ALL.length*100}%"></i></span></div>
    <div class="jtrack"><span class="jlabel ja">${esc(t2("jRouteA"))}</span><div class="jchips">${ROUTE_A.map(chip).join('<span class="jline"></span>')}</div></div>
    <div class="jtrack"><span class="jlabel jb">${esc(t2("jRouteB"))}</span><div class="jchips">${ROUTE_B.map(chip).join('<span class="jline"></span>')}</div></div>
  </nav>`;
}

/* ---------- sign-up and "welcome back" (no server: data stays on this device) ---------- */
const natName = () => { if (S.nat === "OTHER") return S.natOther || "—"; const n = NATIONS.find(x => x.code === S.nat); return n ? L(n) : "—"; };
function onboardNext(){
  if (!S.registered) S.screen = "register";
  else if (!S.histRead) { S.screen = "history"; S.hIdx = 0; }
  else if (!S.flags.tutorial) return startTutorial();
  else S.screen = "game";
  save(); render();
}
let REG_ERR = null;
function registerScreen(){
  const opts = NATIONS.map(n => `<option value="${n.code}" ${S.nat===n.code?"selected":""}>${esc(L(n))}</option>`).join("");
  return `<div class="overlay"><div class="ob-card">
    <div class="ob-kicker">WANDERQUEST · ${esc(t("brandSub"))}</div>
    <h1 style="color:#fbe9b6">${esc(t2("regTitle"))}</h1><p>${esc(t2("regSub"))}</p>
    <label class="field"><span>${esc(t2("regName"))} *</span><input id="in-name" maxlength="40" autocomplete="name" required placeholder="${esc(t2("regNamePh"))}" value="${esc(S.name)}"></label>
    <label class="field"><span>${esc(t2("regNat"))} *</span><select id="in-nat" required data-act="regNatChange"><option value="">${esc(t2("regNatPick"))}</option>${opts}</select></label>
    <label class="field ${S.nat==="OTHER"?"":"hidden"}" id="other-wrap"><span>${esc(t2("regNatOther"))} *</span><input id="in-nat-other" maxlength="40" value="${esc(S.natOther||"")}"></label>
    ${REG_ERR ? `<div class="feedback bad" id="reg-err" role="alert">${esc(t2(REG_ERR))}</div>` : ""}
    <p class="small" style="opacity:.85" id="reg-privacy">${esc(t2(SHEET_ENDPOINT ? "regPrivacyCloud" : "regPrivacy"))}</p>
    <div class="ob-actions"><button class="btn-gold" data-act="regGo" id="btn-register">${esc(t2("regGo"))}</button>
      <button class="btn-ghost" data-act="backLang">${esc(t("back"))}</button></div></div></div>`;
}
document.addEventListener("change", ev => { if (ev.target && ev.target.id === "in-nat") { const w = document.getElementById("other-wrap"); if (w) w.classList.toggle("hidden", ev.target.value !== "OTHER"); } });
ACT.regNatChange = () => {};
ACT.regGo = () => {
  const name = (document.getElementById("in-name").value || "").trim().slice(0,40);
  const nat = document.getElementById("in-nat").value;
  const other = (document.getElementById("in-nat-other").value || "").trim().slice(0,40);
  S.name = name; S.nat = nat; S.natOther = other;
  REG_ERR = !name ? "regErrName" : !nat ? "regErrNat" : (nat === "OTHER" && !other) ? "regErrOther" : null;
  if (REG_ERR) { render(); const f = document.getElementById(REG_ERR === "regErrName" ? "in-name" : REG_ERR === "regErrNat" ? "in-nat" : "in-nat-other"); if (f) f.focus(); return; }
  S.registered = true; S.registeredAt = Date.now(); setSession(); logEv("register", nat); report("register"); onboardNext();
};
function sessionOK(){ try { return window.sessionStorage.getItem("wq-session") === "1"; } catch(e){ return SESSION_FALLBACK; } }
let SESSION_FALLBACK = false, LANG_FALLBACK = false;
function langChosen(){ try { return window.sessionStorage.getItem("wq-lang") === "1" || LANG_FALLBACK; } catch(e){ return LANG_FALLBACK; } }
function setLangChosen(){ LANG_FALLBACK = true; try { window.sessionStorage.setItem("wq-lang","1"); } catch(e){} }
function setSession(){ SESSION_FALLBACK = true; try { window.sessionStorage.setItem("wq-session","1"); } catch(e){} }
function loginScreen(){
  return `<div class="overlay"><div class="ob-card" style="text-align:center">
    <div class="ob-kicker">WANDERQUEST</div>
    <img src="${IMG.mossy}" alt="Mossy" style="width:110px;border-radius:18px;margin:10px auto;display:block">
    <h1 style="color:#fbe9b6">${esc(t2("loginTitle",{name:S.name}))}</h1>
    <p>${esc(t2("loginSub",{nat:natName(), n:ORDER_ALL.filter(placeDone).length}))}</p>
    <div class="ob-actions" style="justify-content:center;flex-direction:column;align-items:center">
      <button class="btn-gold" data-act="loginGo" id="btn-login">${esc(t2("loginGo"))}</button>
      <button class="btn-ghost" data-act="loginNew" id="btn-login-new">${esc(t2("loginNew",{name:S.name}))}</button>
      <button class="btn-ghost small" data-act="loginLang" id="btn-login-lang">🌐 Language / 語言</button></div></div></div>`;
}
ACT.loginLang = () => { LANG_FALLBACK = false; try { window.sessionStorage.removeItem("wq-lang"); } catch(err){} render(); };
ACT.loginGo = () => { setSession(); logEv("login"); report("login", S.scene); render(); };
ACT.loginNew = () => { if (!confirm(t2("loginNewConfirm",{name:S.name}))) return;
  const l = S.lang; store.del(KEY); S = freshState(); S.lang = l; S.screen = "register"; setSession(); save(); render(); };

/* ---------- feedback invitation (final ending only) ---------- */
function feedbackBlock(id){
  return `<div class="card fbcard"><h3>💌 ${esc(t2("fbTitle"))}</h3><p>${esc(t2("fbText"))}</p><p><b>${esc(t2("fbTime"))}</b></p>
    <a class="cta" href="${FEEDBACK_URL}" target="_blank" rel="noopener noreferrer" id="${id}">${esc(t2("fbBtn"))}</a>
    <p class="small muted" style="margin-top:10px">${esc(t("endPid",{id:S.pid}))}</p></div>`;
}

/* ---------- backend: send progress rows to the team's Google Sheet (only if SHEET_ENDPOINT is set) ---------- */
function snapshot(ev){
  const done = {}; ORDER_ALL.forEach(id => { if (placeDone(id)) done[id] = id === "station" ? S.flags.logicAt : id === "valley" ? S.flags.gateAt : (S.st[id] && S.st[id].doneAt) || Date.now(); });
  return { app:"wanderquest", v:VERSION, pid:S.pid, name:S.name, nationality: S.nat === "OTHER" ? S.natOther : ((NATIONS.find(n=>n.code===S.nat)||{}).en || S.nat),
    lang:S.lang, registeredAt:S.registeredAt || null, done, doneCount:Object.keys(done).length, current:S.scene,
    routeA:ROUTE_A.every(placeDone), routeB:ROUTE_B.every(placeDone), finishedAt: ORDER_ALL.every(placeDone) ? (S.tEnd || Date.now()) : null,
    minutes: S.t0 ? Math.round(((S.tEnd || Date.now()) - S.t0)/60000) : 0, hints:totalHints(), tries:totalTries(),
    seconds: Object.fromEntries(ORDER_ALL.map(id => [id, Math.round(((S.time||{})[id]||0)/1000)])),
    activeMinutes: Math.round(Object.values(S.time||{}).reduce((a,b)=>a+b,0)/6000)/10, event:ev };
}
function report(type, place, detail){
  if (!SHEET_ENDPOINT || !S.registered) return;
  if (!Array.isArray(S.outbox)) S.outbox = [];
  S.outbox.push(snapshot({type, place: place || "", detail: detail === undefined ? "" : String(detail), t: Date.now()}));
  if (S.outbox.length > 60) S.outbox.splice(0, S.outbox.length - 60);
  save(); flushOutbox();
}
let FLUSHING = false;
async function flushOutbox(){
  if (FLUSHING || !SHEET_ENDPOINT || !Array.isArray(S.outbox) || !S.outbox.length || typeof fetch !== "function") return;
  FLUSHING = true;
  try {
    while (S.outbox.length) {
      const item = S.outbox[0];
      // text/plain + no-cors avoids a CORS preflight, which Apps Script does not answer
      await fetch(SHEET_ENDPOINT, {method:"POST", mode:"no-cors", headers:{"Content-Type":"text/plain;charset=utf-8"}, body:JSON.stringify(item), keepalive:true});
      S.outbox.shift(); save();
    }
  } catch(e){ /* offline: keep the rows and retry next time */ }
  FLUSHING = false;
}
function placeReported(id){
  report("place_done", id, Math.round(((S.time||{})[id]||0)/1000));
  if (!S.reported) S.reported = {};
  if (!S.reported.A && ROUTE_A.every(placeDone)) { S.reported.A = true; report("route_done", "", "A"); }
  if (!S.reported.B && ROUTE_B.every(placeDone)) { S.reported.B = true; report("route_done", "", "B"); }
  if (!S.reported.all && ORDER_ALL.every(placeDone)) { S.reported.all = true; report("game_done", "", playMinutes()+" min"); }
}
setTimeout(flushOutbox, 1500);
window.addEventListener("online", flushOutbox);

/* ---------- per-place play time: counts only while that place is open on screen and unsolved ---------- */
let TICK_LAST = Date.now();
function timeTick(force){
  const now = Date.now(), dt = now - TICK_LAST; TICK_LAST = now;
  if (!force && typeof document !== "undefined" && document.visibilityState === "hidden") return;
  if (dt <= 0 || dt > 90000) return;                       // device asleep / long gap: don't count
  const id = S.scene;
  if (S.screen === "game" && ORDER_ALL.includes(id) && !placeDone(id)) {
    if (!S.time) S.time = {};
    S.time[id] = (S.time[id] || 0) + dt; save();
  }
}
setInterval(() => timeTick(), 2000);
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") timeTick(true); else TICK_LAST = Date.now(); });
window.addEventListener("pagehide", () => timeTick(true));
