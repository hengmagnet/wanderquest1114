/* WANDERQUEST v3.0 — procedural SVG art (original, no external images). */
const ART = (() => {
const svgURI = s => "data:image/svg+xml;charset=utf-8," + encodeURIComponent(s);

/* ---------- Puzzle 1: the Maokong memory picture (400 x 400, 16 tiles of 100) ----------
   Every tile carries at least one unique feature so no two tiles look interchangeable.
   tests/check_puzzle.py renders this and verifies all 16 tiles + 2 decoys are visually distinct. */
const cableY = x => 315 - 0.5 * x;               // cable rises left -> right
function cabin(x, color) {
  const y = cableY(x);
  return `<line x1="${x}" y1="${y}" x2="${x}" y2="${y+12}" stroke="#2c3b3a" stroke-width="3"/>
  <rect x="${x-15}" y="${y+12}" width="30" height="24" rx="6" fill="${color}" stroke="#2c3b3a" stroke-width="3"/>
  <rect x="${x-10}" y="${y+16}" width="20" height="9" rx="2" fill="#d9eef0"/>`;
}
const PUZZLE_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
<defs><linearGradient id="sk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9fd0d8"/><stop offset=".55" stop-color="#e9efd0"/><stop offset="1" stop-color="#f6e2b0"/></linearGradient></defs>
<rect width="400" height="400" fill="url(#sk)"/>
<!-- sun straddles tiles 0|1 -->
<circle cx="100" cy="52" r="30" fill="#f6c95e"/><circle cx="100" cy="52" r="40" fill="none" stroke="#f6c95e" stroke-width="4" stroke-dasharray="6 9"/>
<!-- cloud straddles tiles 1|2 -->
<g fill="#ffffff"><ellipse cx="180" cy="44" rx="32" ry="15"/><ellipse cx="206" cy="36" rx="24" ry="17"/><ellipse cx="230" cy="48" rx="20" ry="11"/></g>
<!-- birds straddle tiles 2|3 -->
<path d="M282 30q8-8 16 0q8-8 16 0M268 62q6-6 12 0q6-6 12 0M300 72q6-6 12 0q6-6 12 0" fill="none" stroke="#3b4a48" stroke-width="3"/>
<ellipse cx="240" cy="86" rx="22" ry="8" fill="#ffffff"/>
<!-- back ridge (rows 1-2) -->
<path d="M0 205 L60 150 L130 188 L210 132 L300 178 L400 152 L400 400 L0 400Z" fill="#8fbf9f"/>
<path d="M45 165 l15-15 l15 13z M195 147 l15-15 l16 14z" fill="#e8f2e4"/>
<!-- front hill -->
<path d="M0 342 C120 334 200 282 258 214 S330 160 400 160 L400 400 L0 400Z" fill="#4f8a62"/>
<path d="M0 372 C150 360 260 320 400 300 L400 400 L0 400Z" fill="#3d7353"/>
<!-- t3 flag on station -->
<line x1="372" y1="36" x2="372" y2="104" stroke="#3b4a48" stroke-width="4"/><path d="M372 38 l24 9 l-24 9z" fill="#c4553a"/>
<!-- t7 Maokong station on the hilltop -->
<path d="M292 112 L340 82 L392 112Z" fill="#a9583f" stroke="#3b3b33" stroke-width="4"/>
<rect x="298" y="112" width="88" height="50" fill="#f3e3bd" stroke="#3b3b33" stroke-width="4"/>
<rect x="304" y="120" width="76" height="16" fill="#2f5a49"/><text x="342" y="132" font-family="Arial,Helvetica,sans-serif" font-size="11" font-weight="700" fill="#fff" text-anchor="middle">MAOKONG</text>
<rect x="346" y="140" width="20" height="22" fill="#7a5b3c"/><rect x="310" y="141" width="22" height="13" fill="#bfe0de"/>
<!-- pylons -->
<path d="M120 255 L112 330 M120 255 L128 330 M113 300 L127 300 M112 330 L128 330" stroke="#5a5f58" stroke-width="4" fill="none"/>
<path d="M240 195 L233 250 M240 195 L247 250 M234 225 L246 225" stroke="#5a5f58" stroke-width="4" fill="none"/>
<!-- the cable -->
<line x1="10" y1="${cableY(10)}" x2="350" y2="${cableY(350)}" stroke="#263533" stroke-width="5"/>
${cabin(70,"#c4553a")}${cabin(182,"#c4553a")}${cabin(292,"#c4553a")}
<!-- t12 small zoo station -->
<rect x="4" y="318" width="62" height="40" fill="#e9d6a8" stroke="#3b3b33" stroke-width="4"/>
<path d="M0 320 L35 296 L70 320Z" fill="#6d8f7a" stroke="#3b3b33" stroke-width="4"/>
<text x="35" y="345" font-family="Arial,Helvetica,sans-serif" font-size="12" font-weight="700" fill="#3b3b33" text-anchor="middle">ZOO</text>
<rect x="10" y="372" width="70" height="8" rx="4" fill="#d9c08a"/>
<!-- t13 pond, flowers and a tiny red mushroom -->
<ellipse cx="150" cy="370" rx="38" ry="14" fill="#7fc0c8" stroke="#4d8f96" stroke-width="3"/>
<g fill="#f2a2b4"><circle cx="112" cy="388" r="4"/><circle cx="126" cy="392" r="4"/><circle cx="186" cy="386" r="4"/></g>
<path d="M180 352 q12-16 24 0z" fill="#c4553a"/><rect x="189" y="352" width="6" height="10" fill="#f3e3bd"/><circle cx="188" cy="347" r="2" fill="#fff"/><circle cx="197" cy="349" r="2" fill="#fff"/>
<!-- tea bushes rows 2-3 right -->
${[[230,300],[262,292],[294,284],[326,276],[358,268],[390,262],[214,336],[246,328],[278,320],[310,312],[342,306],[374,300],[236,372],[268,364],[300,356],[332,350],[364,344],[396,338]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="15" ry="10" fill="#2f6b45" stroke="#24553a" stroke-width="2"/>`).join("")}
<!-- winding path -->
<path d="M200 400 C230 380 260 395 300 370 S360 330 340 300 S300 260 330 200" fill="none" stroke="#e7d39c" stroke-width="8" stroke-linecap="round" stroke-dasharray="1 0"/>
<!-- t15 teapot sign -->
<rect x="356" y="364" width="36" height="28" rx="4" fill="#f3e3bd" stroke="#3b3b33" stroke-width="3"/><text x="374" y="384" font-size="16" text-anchor="middle">🍵</text>
<!-- t4 hawk / t5 kite / t9 butterfly / t10 bench / t11 lamp / t8 leaf — small unique markers -->
<path d="M30 118 q10-6 20 0 q10-6 20 0" fill="none" stroke="#3b4a48" stroke-width="3"/>
<path d="M150 115 l12 -12 l12 12 l-12 14z" fill="#e2b45c" stroke="#7a5517" stroke-width="2"/><path d="M162 129 q-4 14 6 24" fill="none" stroke="#7a5517" stroke-width="2"/>
<g fill="#f0b75b"><ellipse cx="164" cy="285" rx="6" ry="4"/><ellipse cx="172" cy="285" rx="6" ry="4"/></g>
<rect x="262" y="246" width="26" height="5" fill="#7a5b3c"/><rect x="264" y="251" width="3" height="8" fill="#7a5b3c"/><rect x="283" y="251" width="3" height="8" fill="#7a5b3c"/>
<line x1="318" y1="210" x2="318" y2="244" stroke="#3b4a48" stroke-width="3"/><circle cx="318" cy="208" r="6" fill="#f6c95e" stroke="#3b4a48" stroke-width="2"/>
<path d="M28 248 q14 -16 28 0 q-14 10 -28 0z" fill="#6aa86f"/>
</svg>`;

/* The two decoys from "another valley": cable DESCENDS, blue cabin, waterfall. */
const DECOY_SVG = [
`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
<defs><linearGradient id="d1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c8e0d6"/><stop offset="1" stop-color="#dde9cf"/></linearGradient></defs>
<rect width="100" height="100" fill="url(#d1)"/><path d="M0 92 L40 70 L100 88 L100 100 L0 100Z" fill="#8fbf9f"/>
<line x1="0" y1="18" x2="100" y2="68" stroke="#263533" stroke-width="5"/>
<line x1="50" y1="43" x2="50" y2="55" stroke="#2c3b3a" stroke-width="3"/>
<rect x="35" y="55" width="30" height="24" rx="6" fill="#3d76b8" stroke="#2c3b3a" stroke-width="3"/><rect x="40" y="59" width="20" height="9" rx="2" fill="#d9eef0"/></svg>`,
`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
<rect width="100" height="100" fill="#4f8a62"/><path d="M0 0 L100 0 L100 30 L0 14Z" fill="#cfe3d8"/>
<line x1="0" y1="6" x2="100" y2="26" stroke="#263533" stroke-width="5"/>
<path d="M30 30 L70 34 L72 100 L28 100Z" fill="#6b6f66"/>
<path d="M44 32 Q50 60 46 100 L58 100 Q62 62 56 33Z" fill="#e8f6fb"/><path d="M47 40 L47 96 M53 40 L53 96" stroke="#9fd0e8" stroke-width="2"/>
<ellipse cx="52" cy="96" rx="18" ry="5" fill="#ffffff"/></svg>`
];

const PUZZLE_URI = svgURI(PUZZLE_SVG);
const DECOY_URI = DECOY_SVG.map(svgURI);

/* Tutorial 2x2 picture */
const PRACTICE_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><rect width="200" height="200" fill="#dcefe9"/>
<circle cx="24" cy="44" r="30" fill="#f6c95e"/>
<g fill="#ffffff"><ellipse cx="96" cy="62" rx="26" ry="13"/><ellipse cx="118" cy="52" rx="22" ry="16"/><ellipse cx="142" cy="64" rx="20" ry="11"/></g>
<path d="M0 168 Q110 110 200 112 V200 H0Z" fill="#5f9a6c"/>
<path d="M76 146 q24-40 48 0z" fill="#c4553a"/><rect x="93" y="146" width="14" height="24" fill="#f3e3bd"/><circle cx="90" cy="134" r="4" fill="#fff"/><circle cx="108" cy="128" r="5" fill="#fff"/>
<text x="16" y="188" font-family="Arial" font-size="20" font-weight="700" fill="#fff">GO!</text></svg>`;
const PRACTICE_URI = svgURI(PRACTICE_SVG);

/* ---------- scene backdrops (1600 x 900) ---------- */
const STATION_SVG = `<svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
<defs><linearGradient id="ss" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a8d6dc"/><stop offset="1" stop-color="#f3e7c4"/></linearGradient></defs>
<rect width="1600" height="900" fill="url(#ss)"/>
<path d="M0 420 L200 300 L420 380 L640 260 L900 360 L1150 250 L1400 340 L1600 290 V900 H0Z" fill="#9cc6a6"/>
<path d="M0 520 C300 470 600 520 900 450 S1400 420 1600 440 V900 H0Z" fill="#5d9670"/>
<line x1="-20" y1="300" x2="1620" y2="90" stroke="#26403b" stroke-width="7"/>
<g transform="translate(1120 150)"><line x1="0" y1="0" x2="0" y2="30" stroke="#26403b" stroke-width="5"/><rect x="-36" y="30" width="72" height="56" rx="12" fill="#c4553a" stroke="#26403b" stroke-width="5"/><rect x="-26" y="40" width="52" height="22" rx="4" fill="#d9eef0"/></g>
<!-- station platform -->
<rect x="0" y="560" width="1600" height="340" fill="#d8c79e"/>
<rect x="0" y="560" width="1600" height="16" fill="#b9a678"/>
<path d="M0 230 L800 130 L1600 230 L1600 260 L0 260Z" fill="#8a4a35" opacity=".92"/>
<rect x="60" y="260" width="20" height="300" fill="#6d5a45"/><rect x="1520" y="260" width="20" height="300" fill="#6d5a45"/>
<!-- wall with frame -->
<rect x="610" y="280" width="380" height="250" rx="10" fill="#7a5b3c"/><rect x="630" y="300" width="340" height="210" fill="#e9e1c8"/>
<g opacity=".55">${[0,1,2,3].map(r=>[0,1,2,3].map(c=>`<rect x="${640+c*82}" y="${306+r*50}" width="78" height="46" fill="${(r+c)%2?'#c9d9c2':'#b5cdb0'}"/>`).join("")).join("")}</g>
<!-- notice board -->
<rect x="190" y="210" width="230" height="170" rx="8" fill="#a07a4e"/><rect x="204" y="224" width="202" height="142" fill="#efe3c2"/>
<rect x="216" y="236" width="80" height="56" fill="#fff"/><rect x="306" y="240" width="86" height="40" fill="#f6d9a0"/><rect x="230" y="302" width="150" height="50" fill="#dbe9f5"/>
<!-- cabinet -->
<rect x="1215" y="250" width="200" height="300" rx="8" fill="#5f7d6e" stroke="#2f4a3f" stroke-width="6"/><line x1="1315" y1="256" x2="1315" y2="544" stroke="#2f4a3f" stroke-width="5"/>
<circle cx="1300" cy="400" r="8" fill="#e2b45c"/><circle cx="1330" cy="400" r="8" fill="#e2b45c"/><rect x="1265" y="300" width="100" height="30" fill="#efe3c2"/>
<!-- bench + notebook -->
<rect x="1150" y="610" width="320" height="22" fill="#7a5b3c"/><rect x="1170" y="632" width="16" height="60" fill="#7a5b3c"/><rect x="1434" y="632" width="16" height="60" fill="#7a5b3c"/>
<rect x="1240" y="590" width="70" height="22" fill="#e0c870" transform="rotate(-6 1275 600)"/>
<!-- porter pole & baskets -->
<line x1="280" y1="640" x2="520" y2="610" stroke="#8b6a3e" stroke-width="10" stroke-linecap="round"/>
<path d="M290 650 h70 l-10 70 h-50z M450 625 h70 l-10 70 h-50z" fill="#c7a46a" stroke="#7a5b3c" stroke-width="4"/>
<!-- tea basket & plants -->
<g fill="#2f6b45">${[60,110,160,1530,1570].map(x=>`<ellipse cx="${x}" cy="575" rx="34" ry="22"/>`).join("")}</g>
</svg>`;

const VALLEY_SVG = `<svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
<defs><linearGradient id="vs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#b6dccd"/><stop offset="1" stop-color="#e9efd8"/></linearGradient>
<radialGradient id="gl" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#e8ffd0" stop-opacity=".9"/><stop offset="1" stop-color="#c9f0a8" stop-opacity="0"/></radialGradient></defs>
<rect width="1600" height="900" fill="url(#vs)"/>
<path d="M0 380 L260 220 L520 330 L800 190 L1080 310 L1340 200 L1600 300 V900 H0Z" fill="#7fb08d"/>
<path d="M0 470 C320 420 640 480 960 420 S1400 400 1600 430 V900 H0Z" fill="#4c8361"/>
<!-- stream -->
<path d="M0 640 C300 600 520 700 820 650 S1300 590 1600 640 V760 C1300 720 1000 800 760 770 S300 720 0 760Z" fill="#7cc0c4"/>
<path d="M60 690 q40 -12 80 0 M420 700 q40 -12 80 0 M900 690 q40-12 80 0 M1300 668 q40-12 80 0" stroke="#e8f8f8" stroke-width="5" fill="none"/>
<!-- bedrock with potholes -->
<path d="M560 560 C700 520 900 540 1000 580 L980 640 C860 620 700 630 580 640Z" fill="#9b958a"/>
${[[640,590,30],[720,600,22],[820,584,34],[910,600,20]].map(([x,y,r])=>`<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.5}" fill="#4f5d5a" stroke="#6f6a60" stroke-width="5"/>`).join("")}
<path d="M1120 760 C1220 700 1420 700 1520 760 L1500 840 C1380 860 1220 860 1130 830Z" fill="#a39d90"/>
${[[1200,775,28],[1260,770,22],[1330,780,34],[1420,770,24]].map(([x,y,r])=>`<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.5}" fill="#4f5d5a" stroke="#77716a" stroke-width="5"/>`).join("")}
<!-- old map on a rock -->
<rect x="250" y="330" width="230" height="160" rx="6" fill="#e9d9ad" transform="rotate(-5 365 410)" stroke="#a88a52" stroke-width="5"/>
<path d="M280 380 q60 30 120 0 t60 20" stroke="#b07a48" stroke-width="4" fill="none" transform="rotate(-5 365 410)"/>
<!-- mycelium gate -->
<ellipse cx="800" cy="300" rx="190" ry="190" fill="url(#gl)"/>
<path d="M690 470 C680 330 700 250 800 220 C900 250 920 330 910 470" fill="none" stroke="#5c3f2c" stroke-width="26" stroke-linecap="round"/>
<path d="M660 250 q140 -150 280 0z" fill="#c4553a" stroke="#5c3f2c" stroke-width="8"/>
<g fill="#f3e3bd"><circle cx="740" cy="200" r="14"/><circle cx="810" cy="175" r="18"/><circle cx="870" cy="215" r="12"/></g>
<path d="M720 470 C760 400 840 400 880 470" stroke="#c9f0a8" stroke-width="4" fill="none" stroke-dasharray="8 8"/>
<!-- trail sign -->
<rect x="1150" y="170" width="18" height="250" fill="#7a5b3c"/><rect x="1060" y="170" width="200" height="80" rx="8" fill="#2f5a49" stroke="#1f3d32" stroke-width="5"/>
<text x="1160" y="218" font-family="sans-serif" font-size="34" font-weight="700" fill="#fff" text-anchor="middle">壺穴</text>
<!-- trees -->
${[[90,420],[1480,400],[1540,430]].map(([x,y])=>`<rect x="${x-8}" y="${y}" width="16" height="70" fill="#6d5a45"/><circle cx="${x}" cy="${y-20}" r="55" fill="#2f6b45"/>`).join("")}
</svg>`;

/* ---------- prologue film (1200 x 600) ---------- */
const FILM_SVG = `<svg viewBox="0 0 1200 600" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
<defs><linearGradient id="fs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#18403a"/><stop offset=".6" stop-color="#2d6a5a"/><stop offset="1" stop-color="#c9b37a"/></linearGradient></defs>
<rect width="1200" height="600" fill="url(#fs)"/>
${Array.from({length:30},(_,i)=>`<circle cx="${(i*137)%1200}" cy="${(i*71)%240}" r="${1+i%3}" fill="#fff" opacity=".6"/>`).join("")}
<circle cx="980" cy="110" r="46" fill="#f6dfa0" opacity=".9"/>
<path d="M0 330 L180 230 L360 300 L560 200 L780 290 L980 210 L1200 280 V600 H0Z" fill="#2b5a4a"/>
<path d="M0 420 C260 370 520 430 780 380 S1100 360 1200 380 V600 H0Z" fill="#1d4337"/>
<line x1="0" y1="250" x2="1200" y2="120" stroke="#0f2621" stroke-width="5"/>
<g transform="translate(640 181)"><line x1="0" y1="0" x2="0" y2="22" stroke="#0f2621" stroke-width="4"/><rect x="-26" y="22" width="52" height="40" rx="9" fill="#c4553a"/></g>
<g>
<path class="myc" d="M80 560 C200 480 260 520 360 470 S520 420 600 480 S820 520 900 450 S1080 430 1160 500"/>
<path class="myc" d="M200 590 C260 520 330 560 420 520 S600 560 700 520"/>
<path class="myc" d="M640 600 C700 540 780 560 860 520 S1000 540 1100 560"/>
<path class="myc restore" d="M80 560 C200 480 260 520 360 470 S520 420 600 480 S820 520 900 450 S1080 430 1160 500"/>
</g></svg>`;

/* ---------- world map (1600 x 1100) — schematic, not to scale ---------- */
const MAP_NODES = [
 {id:"station", x:47, y:48, ico:"🚡", route:"S", zh:"貓空站", en:"Maokong Station"},
 {id:"a2", x:36, y:30, ico:"☁️", route:"A", zh:"小天空步道", en:"Xiaotiankong Trail"},
 {id:"valley", x:22, y:38, ico:"💧", route:"A", zh:"壺穴步道", en:"Pothole Trail"},
 {id:"a4", x:14, y:58, ico:"🍵", route:"A", zh:"茶展中心步道", en:"Tea Exhibition Trail"},
 {id:"a5", x:24, y:76, ico:"🌿", route:"A", zh:"健康步道", en:"Health Trail"},
 {id:"a6", x:38, y:86, ico:"🏛️", route:"A", zh:"茶研發推廣中心", en:"Tea Research & Promotion Center"},
 {id:"b2", x:60, y:30, ico:"🌳", route:"B", zh:"樟樹步道", en:"Camphor Tree Trail"},
 {id:"b3", x:77, y:22, ico:"⛰️", route:"B", zh:"登高步道", en:"Denggao Trail"},
 {id:"b4", x:87, y:42, ico:"🌸", route:"B", zh:"杏花林", en:"Apricot Blossom Grove"},
 {id:"b5", x:80, y:64, ico:"🏞️", route:"B", zh:"樟湖步道", en:"Zhanghu Trail"},
 {id:"b6", x:64, y:80, ico:"🥾", route:"B", zh:"貓空越嶺步道", en:"Maokong Ridge Trail"}
];
function pathThrough(ids){ return ids.map((id,i)=>{const n=MAP_NODES.find(m=>m.id===id);return (i?"L":"M")+(n.x*16)+" "+(n.y*11)}).join(" "); }
const MAP_SVG = `<svg class="mapbg" viewBox="0 0 1600 1100" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
<rect width="1600" height="1100" fill="#d6e6c8"/>
${[[300,250,260],[1200,200,300],[1300,800,260],[400,850,240],[800,500,200]].map(([x,y,r])=>`<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.6}" fill="#bcd5ac"/><ellipse cx="${x}" cy="${y}" rx="${r*.6}" ry="${r*.36}" fill="#a9c99a"/>`).join("")}
<path d="M0 640 C200 600 300 700 520 660 S900 760 1100 720 S1400 640 1600 700" fill="none" stroke="#8cc3c9" stroke-width="22"/>
<path d="${pathThrough(["station","a2","valley","a4","a5","a6"])}" fill="none" stroke="#c4553a" stroke-width="10" stroke-dasharray="18 14" stroke-linecap="round"/>
<path d="${pathThrough(["station","b2","b3","b4","b5","b6"])}" fill="none" stroke="#3d76b8" stroke-width="10" stroke-dasharray="18 14" stroke-linecap="round"/>
<path d="${pathThrough(["station","valley"])}" fill="none" stroke="#e2b45c" stroke-width="7" stroke-linecap="round"/>
<text x="1560" y="1080" font-family="sans-serif" font-size="30" fill="#6b7f67" text-anchor="end">schematic · 示意圖</text>
</svg>`;

/* ---------- Puzzle 3: overlay map ---------- */
function overlaySVG(off, plateUsed, solved) {
  const C = 60, W = OVERLAY.cols*C, H = OVERLAY.rows*C;
  const cx = x => x*C + C/2, cy = y => y*C + C/2;
  const k = ((off.k||0)%4+4)%4;
  let s = `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">
  <rect width="${W}" height="${H}" fill="#dcead2"/>
  <path d="M0 ${cy(5)+20} C90 ${cy(4)} 170 ${cy(6)} ${cx(4)} ${cy(5)} S380 ${cy(3)} ${W} ${cy(4)}" stroke="#86c1c6" stroke-width="28" fill="none"/>`;
  for (let i=1;i<OVERLAY.cols;i++) s += `<line x1="${i*C}" y1="0" x2="${i*C}" y2="${H}" stroke="#b9cfb0" stroke-width="1"/>`;
  for (let j=1;j<OVERLAY.rows;j++) s += `<line x1="0" y1="${j*C}" x2="${W}" y2="${j*C}" stroke="#b9cfb0" stroke-width="1"/>`;
  // new-map north arrow (top-right)
  s += `<g transform="translate(${W-34} 40)"><path d="M0 -24 L9 6 L0 0 L-9 6Z" fill="#2f6b45"/><text y="22" font-size="16" font-weight="800" text-anchor="middle" fill="#2f6b45" font-family="Arial">N</text></g>`;
  OVERLAY.marks.forEach(m => { s += `<circle cx="${cx(m.x)}" cy="${cy(m.y)}" r="25" fill="#fffdf3" stroke="#2f6b45" stroke-width="3"/><text x="${cx(m.x)}" y="${cy(m.y)+10}" font-size="28" text-anchor="middle">${m.ico}</text>`; });
  // old map: rotated about the grid centre, then shifted
  s += `<g transform="translate(${off.x*C} ${off.y*C}) rotate(${k*90} ${W/2} ${H/2})" opacity="${plateUsed?.8:.45}">
    <rect x="4" y="4" width="${W-8}" height="${H-8}" fill="#f1dcae" fill-opacity=".22" stroke="#a5743f" stroke-width="4" stroke-dasharray="10 8"/>
    <g transform="translate(${W/2} ${H/2})"><circle r="22" fill="#fff6e0" stroke="#9a4f22" stroke-width="2" opacity=".9"/><path d="M0 -18 L7 4 L0 0 L-7 4Z" fill="#9a4f22"/><text y="17" font-size="11" font-weight="800" text-anchor="middle" fill="#9a4f22" font-family="Arial">N</text></g>`;
  const glyph = (x,y,g) => `<text x="${cx(x)}" y="${cy(y)+14}" font-size="40" font-weight="900" text-anchor="middle" fill="#9a4f22" stroke="#fff6e0" stroke-width="2" paint-order="stroke">${g}</text>`;
  OVERLAY.marks.forEach(m => s += glyph(m.x,m.y,m.glyph));
  OVERLAY.decoys.forEach(d => s += glyph(d.x,d.y,d.glyph));
  if (solved) s += `<text x="${cx(OVERLAY.star.x)}" y="${cy(OVERLAY.star.y)+16}" font-size="44" text-anchor="middle" fill="#c4553a">★</text>`;
  s += `</g></svg>`;
  return s;
}

/* ---------- Puzzle 4: potholes ---------- */
function potholeSVG(seq) {
  const P = POTHOLES.pots;
  let s = `<svg viewBox="0 0 500 300" xmlns="http://www.w3.org/2000/svg">
  <defs><radialGradient id="pw" cx=".45" cy=".4" r=".7"><stop offset="0" stop-color="#5f8f93"/><stop offset="1" stop-color="#203a3d"/></radialGradient>
  <pattern id="rk" width="40" height="40" patternUnits="userSpaceOnUse"><rect width="40" height="40" fill="#a59e90"/><path d="M0 10 Q20 4 40 12 M0 30 Q20 24 40 32" stroke="#958d7f" stroke-width="2" fill="none"/></pattern></defs>
  <rect width="500" height="300" fill="url(#rk)"/>
  <path d="M0 270 C120 250 300 290 500 262 V300 H0Z" fill="#86c1c6" opacity=".75"/>`;
  // draw oldest first so younger potholes physically cut across older rims
  POTHOLES.order.forEach(k => {
    const p = P[k];
    s += `<g class="pot" data-act="pot" data-arg="${k}" data-pot="${k}" role="button" tabindex="0" aria-label="${k}">
      <circle cx="${p.x}" cy="${p.y}" r="${p.r+8}" fill="#8c8577"/>
      <circle class="rim" cx="${p.x}" cy="${p.y}" r="${p.r}" fill="url(#pw)" stroke="#e8e0cc" stroke-width="6"/>
      <circle cx="${p.x}" cy="${p.y}" r="${p.r*0.55}" fill="none" stroke="#3f6a6d" stroke-width="3" opacity=".7"/>
    </g>`;
  });
  // labels on top (not part of the cross-cutting drawing)
  Object.entries(P).forEach(([k,p]) => {
    const n = seq.indexOf(k);
    s += `<g pointer-events="none"><circle cx="${p.x}" cy="${p.y}" r="17" fill="${n>=0?'#e2b45c':'#fffdf3'}" stroke="#213a31" stroke-width="2"/>
    <text x="${p.x}" y="${p.y+7}" font-family="Arial,Helvetica,sans-serif" font-size="20" font-weight="800" text-anchor="middle" fill="#213a31">${k}</text>
    ${n>=0?`<text x="${p.x+22}" y="${p.y-18}" font-family="Arial" font-size="16" font-weight="800" fill="#fff" stroke="#213a31" stroke-width="3" paint-order="stroke">${n+1}</text>`:""}</g>`;
  });
  return s + `</svg>`;
}

return {PUZZLE_SVG, PUZZLE_URI, DECOY_SVG, DECOY_URI, PRACTICE_URI, STATION_SVG, VALLEY_SVG, FILM_SVG, MAP_SVG, MAP_NODES, overlaySVG, potholeSVG, cableY};
})();
