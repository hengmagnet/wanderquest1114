// Runs backend/Code.gs against a mocked Google Sheets API, feeding it the rows the game actually sent.
const fs = require('fs'), vm = require('vm');
const [codePath, postsPath, outPath] = process.argv.slice(2);
const sheets = {};
function Sheet(name){ this.name = name; this.rows = []; }
Sheet.prototype = {
  getLastRow(){ return this.rows.length; },
  appendRow(r){ this.rows.push(r.slice()); },
  getRange(r, c, nr, nc){ const sh = this; return {
    setValues(v){ v.forEach((row,i)=>{ sh.rows[r-1+i] = sh.rows[r-1+i] || []; row.forEach((x,j)=> sh.rows[r-1+i][c-1+j] = x); }); return this; },
    getValues(){ const out=[]; for(let i=0;i<nr;i++){ const row=[]; for(let j=0;j<nc;j++) row.push((sh.rows[r-1+i]||[])[c-1+j] ?? ''); out.push(row);} return out; },
    setFontWeight(){ return this; }, setBackground(){ return this; } }; },
  setFrozenRows(){}
};
const ctx = {
  SpreadsheetApp:{ getActiveSpreadsheet: () => ({ getSheetByName: n => sheets[n] || null, insertSheet: n => (sheets[n] = new Sheet(n)) }) },
  LockService:{ getScriptLock: () => ({ waitLock(){}, releaseLock(){} }) },
  ContentService:{ createTextOutput: t => t },
  Utilities:{ formatDate: (d) => new Date(d.getTime() + 8*3600e3).toISOString().replace('T',' ').slice(0,19) }
};
vm.createContext(ctx); vm.runInContext(fs.readFileSync(codePath,'utf8'), ctx);
const results = fs.readFileSync(postsPath,'utf8').trim().split('\n').map(body => ctx.doPost({postData:{contents:body}}));
const bad = results.filter(r => r !== 'ok');
fs.writeFileSync(outPath, JSON.stringify(Object.values(sheets).map(s => ({name:s.name, rows:s.rows}))));
console.log(`doPost calls: ${results.length}, ok: ${results.length - bad.length}${bad.length ? ', errors: '+bad.slice(0,3).join(' | ') : ''}`);
Object.values(sheets).forEach(s => console.log(`  sheet "${s.name}": ${s.rows.length - 1} data rows`));
