"""Render the jigsaw picture, cut it into 16 tiles, and assert every tile and decoy is visually distinct."""
import subprocess, sys, itertools, os
import numpy as np
from PIL import Image
d = sys.argv[1]
subprocess.run(['node', os.path.join(os.path.dirname(__file__), 'dump_art.js'), d], check=True)
subprocess.run(['rsvg-convert', '-w', '400', '-h', '400', f'{d}/puzzle.svg', '-o', f'{d}/puzzle.png'], check=True)
for i in range(2):
    subprocess.run(['rsvg-convert', '-w', '100', '-h', '100', f'{d}/decoy{i}.svg', '-o', f'{d}/decoy{i}.png'], check=True)
im = np.asarray(Image.open(f'{d}/puzzle.png').convert('RGB')).astype(float)
tiles = {f't{r*4+c}': im[r*100:(r+1)*100, c*100:(c+1)*100] for r in range(4) for c in range(4)}
for i in range(2):
    tiles[f'decoy{i}'] = np.asarray(Image.open(f'{d}/decoy{i}.png').convert('RGB')).astype(float)
worst = (1e9, None)
fails = []
for a, b in itertools.combinations(tiles, 2):
    diff = np.abs(tiles[a] - tiles[b]).mean(axis=2)
    frac = (diff > 40).mean()          # share of pixels that clearly differ
    if frac < worst[0]: worst = (frac, (a, b))
    if frac < 0.06: fails.append((a, b, round(frac, 3)))
print('closest pair:', worst[1], 'differing pixels: %.1f%%' % (worst[0]*100))
if fails:
    print('FAIL: too similar ->', fails); sys.exit(1)
print('PASS: all 16 tiles + 2 decoys are visually distinct (>=6% clearly different pixels per pair)')
