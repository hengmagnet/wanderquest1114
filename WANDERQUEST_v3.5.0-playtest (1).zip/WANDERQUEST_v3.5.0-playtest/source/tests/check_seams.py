"""Human-eye ambiguity check: if two tiles were swapped (or a decoy put in), how visible would the seams be?
Seam error = mean colour difference across every internal edge of the board. Solved board = baseline."""
import sys, itertools, numpy as np
from PIL import Image
def load(p, size): return np.asarray(Image.open(p).convert('RGB').resize((size,size))).astype(float)
def run(name, img, n, decoys):
    T = img.shape[0]//n
    tiles = [img[r*T:(r+1)*T, c*T:(c+1)*T] for r in range(n) for c in range(n)] + decoys
    def seam(board):
        e = []
        for r in range(n):
            for c in range(n):
                a = tiles[board[r*n+c]]
                if c < n-1: e.append(np.abs(a[:,-1]-tiles[board[r*n+c+1]][:,0]).mean())
                if r < n-1: e.append(np.abs(a[-1]-tiles[board[(r+1)*n+c]][0]).mean())
        return np.array(e)
    base = seam(list(range(n*n)))
    worst = []
    for i, j in itertools.combinations(range(n*n), 2):
        b = list(range(n*n)); b[i], b[j] = b[j], b[i]
        worst.append(((seam(b)-base).max(), f"swap {i}<->{j}"))
    for d in range(len(decoys)):
        for pos in range(n*n):
            b = list(range(n*n)); b[pos] = n*n+d
            worst.append(((seam(b)-base).max(), f"decoy{d} at {pos}"))
    worst.sort()
    print(f"{name}: mean seam on the solved board {base.mean():.1f}. Least visible mistakes (extra colour jump at the worst seam, 0-255):")
    for v, w in worst[:6]: print(f"   {w:18s} +{v:.1f}")
    return worst[0][0]
d = sys.argv[1]
r1 = run("Puzzle 1 (station, 4x4)", load(f"{d}/art/puzzle.png", 400), 4, [load(f"{d}/art/decoy{i}.png", 100) for i in range(2)])
r2 = run("Night view (Denggao, 3x3)", load(f"{d}/j9/night.png", 300), 3, [load(f"{d}/j9/day{i}.png", 100) for i in range(2)])
