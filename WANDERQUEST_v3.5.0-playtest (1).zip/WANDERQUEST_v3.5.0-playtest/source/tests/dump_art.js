// Loads content.js + art.js in a sandbox and writes the puzzle SVGs to disk.
const fs=require('fs'),vm=require('vm'),path=require('path');
const ctx={};vm.createContext(ctx);
for(const f of ['content.js','art.js']) vm.runInContext(fs.readFileSync(path.join(__dirname,'../src',f),'utf8')+'\n;globalThis.ART=typeof ART!=="undefined"?ART:undefined;globalThis.LOGIC=LOGIC;globalThis.OVERLAY=OVERLAY;globalThis.POTHOLES=POTHOLES;',ctx);
const out=process.argv[2];fs.mkdirSync(out,{recursive:true});
fs.writeFileSync(out+'/puzzle.svg',ctx.ART.PUZZLE_SVG);
ctx.ART.DECOY_SVG.forEach((s,i)=>fs.writeFileSync(out+`/decoy${i}.svg`,s));
console.log('ok');
