// Every UI key must exist in both zh and en; every {zh,en} content object must have both, non-empty.
const fs=require('fs'),vm=require('vm'),path=require('path');
const ctx={};vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/content.js'),'utf8')+'\n'+fs.readFileSync(path.join(__dirname,'../src/stations-data.js'),'utf8')+';globalThis.ALL={UI,STORY,TUT_STEPS,ITEMS,LOGIC,OVERLAY,DOCS,HINTS,SCENES,DIALOGUE,OBJ,MISC,ABOUT,PLACES,STN,DOCS2,MECHDATA,UI2,NATIONS};',ctx);
const A=ctx.ALL;let bad=[];
for(const U of [A.UI,A.UI2]){const zk=Object.keys(U.zh),ek=Object.keys(U.en);zk.filter(k=>!ek.includes(k)).forEach(k=>bad.push('missing en: '+k));ek.filter(k=>!zk.includes(k)).forEach(k=>bad.push('missing zh: '+k));}
const zk=Object.keys(A.UI.zh),ek=Object.keys(A.UI.en);
zk.filter(k=>!ek.includes(k)).forEach(k=>bad.push('UI missing en: '+k));
ek.filter(k=>!zk.includes(k)).forEach(k=>bad.push('UI missing zh: '+k));
let n=0;
(function walk(o,p){ if(!o||typeof o!=='object')return;
  if('zh' in o||'en' in o){ n++; for(const l of ['zh','en']){ const v=o[l]; if(v===undefined||v===''||(Array.isArray(v)&&!v.length)) bad.push(p+' missing '+l);} 
    if(Array.isArray(o.zh)&&Array.isArray(o.en)&&o.zh.length!==o.en.length) bad.push(p+' hint count differs'); }
  for(const k of Object.keys(o)) if(k!=='zh'&&k!=='en') walk(o[k],p+'.'+k);
})(A,'');
console.log(`UI keys: ${zk.length} zh / ${ek.length} en; bilingual content objects checked: ${n}`);
if(bad.length){console.log('FAIL',bad);process.exit(1)} else console.log('PASS: every string exists in both languages');
