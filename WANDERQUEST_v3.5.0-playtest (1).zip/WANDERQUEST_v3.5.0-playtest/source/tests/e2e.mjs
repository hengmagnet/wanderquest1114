// WANDERQUEST end-to-end playtests: real clicks in headless Chrome.
// Usage: node tests/e2e.mjs <path-to-index.html> <screenshot-dir>
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import fs from 'fs';
const FILE = 'file://' + fs.realpathSync(process.argv[2]);
const SHOTS = process.argv[3]; fs.mkdirSync(SHOTS, { recursive: true });
const FORM = 'https://docs.google.com/forms/d/e/1FAIpQLSf5dCTCsEz6x8AaLq9NlYHxR8DTBQU8JEJxZrZIe1ujxjjjUw/viewform';
const results = [];
const pass = (name, ok, detail = '') => { results.push({ name, ok, detail }); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`); };
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });

const EN_ALLOW = ['中文', '選擇語言', '遊戲中可隨時切換語言，進度不會遺失。', '填寫回饋', '皺空', '貓空', '示意圖', '壺穴'];
async function cjkLeak(page) {
  return page.evaluate((allow) => {
    const clone = document.body.cloneNode(true);
    clone.querySelectorAll('.zh-sign,script,style,noscript').forEach(e => e.remove());
    // innerText needs layout; use textContent of visible-ish nodes instead
    let txt = clone.textContent;
    allow.forEach(a => { txt = txt.split(a).join(''); });
    const m = txt.match(/[㐀-鿿　-〿＀-￯]+/g);
    return m ? [...new Set(m)].slice(0, 12) : [];
  }, EN_ALLOW);
}
async function newPage(viewport, opts = {}) {
  const ctx = await browser.newContext({ reducedMotion: 'reduce', viewport, hasTouch: !!opts.touch, isMobile: !!opts.touch, deviceScaleFactor: 1 });
  if (opts.blockStorage) await ctx.addInitScript(() => { Object.defineProperty(window, 'localStorage', { get() { throw new Error('blocked'); } }); });
  const page = await ctx.newPage();
  page.errors = [];
  page.on('pageerror', e => page.errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') page.errors.push(m.text()); });
  page.on('dialog', d => d.accept());
  await page.goto(FILE);
  return { ctx, page };
}
const state = page => page.evaluate(() => window.WQ.state);
const fbText = page => page.locator('#fb').innerText().catch(() => '');
const fbClass = page => page.locator('#fb').getAttribute('class').catch(() => '');
async function close(page) { await page.click('#btn-close'); }
async function scan(page, label, lang, leaks) { if (lang !== 'en') return; const l = await cjkLeak(page); if (l.length) leaks.push(`${label}: ${l.join(' | ')}`); }

async function onboarding(page, lang, { tutorial = true, name = 'Tester', region = 'Japan', leaks = [] } = {}) {
  await page.click(lang === 'en' ? '#pick-en' : '#pick-zh');
  // sign-up: name and nationality are required
  await scan(page, 'register', lang, leaks);
  await page.click('#btn-register');
  const e1 = await page.locator('#reg-err').count();
  await page.fill('#in-name', name); await page.click('#btn-register');
  const e2 = await page.locator('#reg-err').count();
  await page.selectOption('#in-nat', 'OTHER'); await page.click('#btn-register');
  const e3 = await page.locator('#reg-err').count();
  await page.selectOption('#in-nat', 'JP'); await page.click('#btn-register');
  const st0 = await state(page);
  pass(`[${lang}] sign-up rejects missing name, missing nationality and empty "Other", then accepts`, e1 && e2 && e3 && st0.registered && st0.name === name && st0.nat === 'JP');
  // history dialog: must click through every line; the "enter" button only exists on the last one
  let lines = 0;
  while (await page.locator('#btn-hist-next').count()) { if (await page.locator('#btn-hist-go').count()) throw new Error('enter button shown early'); await scan(page, 'history', lang, leaks); await page.click('#btn-hist-next'); lines++; }
  await page.click('#btn-hist-go');
  pass(`[${lang}] history intro dialog must be read line by line (${lines+1} lines) before entering`, lines >= 7);
  await page.waitForSelector('#coach');
  if (!tutorial) { await page.click('#btn-tut-skip'); return; }
  // tutorial: every step through the real controls
  await scan(page, 'tutorial-map', lang, leaks);
  await page.click('#tut-node');
  await page.click('#tut-hot');
  await scan(page, 'tutorial-item', lang, leaks);
  await page.click('#btn-ok');
  await page.click('#btn-bag');
  await page.waitForSelector('#item-acorn');
  await close(page);
  // 2x2 practice puzzle: initial [3,1,2,0] -> swap slots 0 and 3
  const tiles = page.locator('#tut-board button');
  await tiles.nth(0).click(); await tiles.nth(3).click();
  await page.click('#btn-talk');
  await scan(page, 'tutorial-hint', lang, leaks);
  await page.click('#btn-ok');
  await page.click('#btn-tut-go');
}

async function solveJigsaw(page) {
  for (let guard = 0; guard < 40; guard++) {
    const board = await page.$$eval('#jig-board button', els => els.map(e => +e.dataset.piece));
    const tray = await page.$$eval('#jig-tray button', els => els.map(e => +e.dataset.piece));
    const i = board.findIndex((p, k) => p !== k);
    if (i < 0) return true;
    const j = board.indexOf(i);
    await page.locator('#jig-board button').nth(i).click();
    if (j >= 0) await page.locator('#jig-board button').nth(j).click();
    else await page.locator('#jig-tray button').nth(tray.indexOf(i)).click();
  }
  return false;
}

async function enter(page, id) { await page.click('#node-'+id, {force:true});
  try { await page.click('#btn-enter', {timeout:5000}); }
  catch(e){ await page.screenshot({path:`${SHOTS}/FAIL_enter_${id}.png`}); console.log('ENTER FAIL', id, JSON.stringify((await state(page)).st), await page.locator('.sheet-head h2').innerText().catch(()=>'no modal')); throw e; } }
async function playStation(page, lang, leaks, opts = {}) {
  await enter(page, 'station');
  await scan(page, 'station', lang, leaks);
  // Puzzle 1 — wrong first, then correct
  await page.click('#hot-frame');
  await scan(page, 'jigsaw', lang, leaks);
  await page.click('#btn-jig-check');
  pass(`[${opts.tag}] jigsaw: unsolved board is rejected`, (await fbClass(page)).includes('bad'), await fbText(page));
  // put a REAL piece in the tray (swap tray[0] with a correct board piece) to test that message
  if (opts.extraWrong) {
    const board = await page.$$eval('#jig-board button', els => els.map(e => +e.dataset.piece));
    const tray = await page.$$eval('#jig-tray button', els => els.map(e => +e.dataset.piece));
    if (tray.every(p => p >= 16)) { await page.locator('#jig-board button').nth(board.findIndex(p => p < 16)).click(); await page.locator('#jig-tray button').nth(0).click(); }
    await page.click('#btn-jig-check');
    pass(`[${opts.tag}] jigsaw: real piece left in tray is rejected with tray message`, (await fbText(page)).length > 10, await fbText(page));
  }
  const solved = await solveJigsaw(page);
  const tray = await page.$$eval('#jig-tray button', els => els.map(e => +e.dataset.piece));
  await page.click('#btn-jig-check');
  pass(`[${opts.tag}] jigsaw: correct picture (decoys ${tray.join(',')} in tray) is accepted`, solved && (await fbClass(page)).includes('ok') && (await state(page)).flags.jig, await fbText(page));
  await page.screenshot({ path: `${SHOTS}/${opts.tag}_jigsaw_solved.png` });
  await page.click('#btn-ok');
  // Collect clues
  for (const h of ['board', 'log', 'porter']) { await page.click('#hot-' + h); await scan(page, 'hot-' + h, lang, leaks); await page.click('#btn-ok'); }
  // Language switch + reload mid-scene must keep progress
  if (opts.switchLang) {
    const before = await state(page);
    await page.click('#btn-lang'); await page.click('#btn-lang');
    await page.reload();
    const after = await state(page);
    pass(`[${opts.tag}] reload + language toggle keep progress (flags, items, clues)`, after.flags.jig && after.bag.length === before.bag.length && after.clues.length === before.clues.length && after.lang === before.lang && after.scene === 'station', `bag=${after.bag} clues=${after.clues}`);
  }
  // Puzzle 2 — logic
  await page.click('#hot-cabinet');
  await scan(page, 'logic', lang, leaks);
  const answer = await page.evaluate(() => window.WQ.LOGIC_ANSWER);
  const nSol = await page.evaluate(() => window.WQ.LOGIC_SOLUTIONS.length);
  pass(`[${opts.tag}] logic: clues produce exactly one solution, equal to the documented table`, nSol === 1 && JSON.stringify(answer) === '[0,1,2,3]', `solutions=${nSol} answer=${answer}`);
  const setRow = async (p, th) => { await page.click(`#cell-${p}-${th}`); await page.click(`#cell-${p}-${th}`); };
  // wrong: tea master->compass, traveler->map, maintenance->basket, porter->lantern (the OLD buggy answer)
  for (const [p, th] of [[0, 2], [1, 1], [2, 0], [3, 3]]) await setRow(p, th);
  await page.click('#btn-logic-check');
  pass(`[${opts.tag}] logic: the old [2,1,0]-style answer is rejected with a clue-based reason`, (await fbClass(page)).includes('bad') && (await fbText(page)).length > 15, await fbText(page));
  await page.click('[data-act="logicReset"]');
  for (const [p, th] of answer.map((th, p) => [p, th])) await setRow(p, th);
  // add some ✕ marks too: they must not affect grading
  await page.click('#cell-0-1'); await page.click('#cell-3-0');
  await page.click('#btn-logic-check');
  const s2 = await state(page);
  pass(`[${opts.tag}] logic: correct table accepted (✕ notes ignored), copper plate awarded`, s2.flags.logic && s2.bag.includes('plate'), await fbText(page));
  await page.screenshot({ path: `${SHOTS}/${opts.tag}_logic_solved.png` });
  await page.click('#btn-ok');
  await page.click('#btn-go-valley');
}

async function playValley(page, lang, leaks, opts = {}) {
  await scan(page, 'valley', lang, leaks);
  for (const h of ['rocks', 'sign']) { await page.click('#hot-' + h); await scan(page, 'hot-' + h, lang, leaks); await page.click('#btn-ok'); }
  // potholes locked before overlay
  await page.click('#hot-potfield'); await page.click('#btn-ok');
  // Puzzle 3 — needs the plate from the bag
  await page.click('#hot-oldmap');
  const arrows = await page.locator('#ov-right').count();
  pass(`[${opts.tag}] overlay: controls locked until the copper plate is used`, arrows === 0);
  await page.click('#btn-ov-bag');
  await page.click('#use-plate');
  pass(`[${opts.tag}] journey timeline marks the Pothole Trail as "you are here"`, (await page.locator('#prog-valley.here').count()) >= 1);
  const lay = await page.evaluate(() => { const m = document.getElementById('ov-map').getBoundingClientRect(), u = document.getElementById('ov-up').getBoundingClientRect(), c = document.getElementById('btn-ov-check').getBoundingClientRect(); return u.top >= m.bottom && u.top - m.bottom < 60 && c.bottom <= window.innerHeight + document.querySelector('.sheet').scrollTop + 400; });
  pass(`[${opts.tag}] overlay: arrow pad sits directly under the map`, lay);
  await scan(page, 'overlay', lang, leaks);
  await page.click('#btn-ov-check');
  pass(`[${opts.tag}] overlay: misaligned map rejected`, (await fbClass(page)).includes('bad'), await fbText(page));
  // trap: move so a decoy sits on a landmark, must still be rejected
  await page.click('#ov-right'); await page.click('#ov-right'); await page.click('#ov-right'); await page.click('#ov-up'); await page.click('#ov-up'); await page.click('#ov-up');
  await page.click('#btn-ov-check');
  pass(`[${opts.tag}] overlay: decoy-on-landmark position rejected`, (await fbClass(page)).includes('bad'), await fbText(page));
  await page.click('[data-act="ovReset"]');
  // follow the generated level-3 hint literally: it must say right 2, up 1
  await close(page);
  await page.click('#btn-hint'); await page.click('#btn-hint-more'); await page.click('#btn-hint-more').catch(() => {});
  const h3 = await page.locator('#hint-3').innerText();
  pass(`[${opts.tag}] overlay: level-3 hint matches the real answer`, lang === 'en' ? /↻ 1 time/.test(h3) && /2 step\(s\) right/.test(h3) && /1 step\(s\) up/.test(h3) : /旋轉 1 次/.test(h3) && /向右移 2 格/.test(h3) && /向上移 1 格/.test(h3), h3.replace(/\n/g, ' '));
  await close(page);
  await page.click('#hot-oldmap');
  // shifting alone (without rotating) must NOT solve it
  await page.click('#ov-right'); await page.click('#ov-right'); await page.click('#ov-up');
  await page.click('#btn-ov-check');
  pass(`[${opts.tag}] overlay: correct shift but wrong rotation rejected`, (await fbClass(page)).includes('bad'), await fbText(page));
  await page.click('#ov-rotate');
  await page.click('#btn-ov-check');
  pass(`[${opts.tag}] overlay: aligned map accepted`, (await state(page)).flags.overlay, await fbText(page));
  await page.screenshot({ path: `${SHOTS}/${opts.tag}_overlay_solved.png` });
  await page.click('#btn-ok');
  // Puzzle 4 — potholes
  await page.click('#hot-potfield');
  await scan(page, 'potholes', lang, leaks);
  const clickPot = k => page.locator(`#pot-map g.pot[data-pot="${k}"] .rim`).click({ force: true, position: { x: 8, y: 30 } });
  for (const k of ['A', 'B', 'C', 'D']) await clickPot(k);
  await page.click('#btn-pot-check');
  pass(`[${opts.tag}] potholes: wrong order rejected with explanation`, (await fbClass(page)).includes('bad'), await fbText(page));
  await page.click('[data-act="potReset"]');
  const order = await page.evaluate(() => ['C', 'A', 'D', 'B']);
  for (const k of order) await clickPot(k);
  const seqShown = (await page.locator('.seq').innerText()).replace(/\s/g, '');
  await page.click('#btn-pot-check');
  const s3 = await state(page);
  pass(`[${opts.tag}] potholes: C→A→D→B accepted, rock rubbing awarded`, s3.flags.pot && s3.bag.includes('rubbing'), `sequence shown ${seqShown}`);
  await page.screenshot({ path: `${SHOTS}/${opts.tag}_potholes_solved.png` });
  await page.click('#btn-ok');
  // Final gate
  await page.click('#hot-gate');
  await scan(page, 'gate', lang, leaks);
  await page.click('#gate-plate');
  await page.click('#btn-gate-go');
  pass(`[${opts.tag}] gate: one item rejected`, (await fbClass(page)).includes('bad'), await fbText(page));
  await page.click('#gate-pic');
  await page.click('#btn-gate-go');
  pass(`[${opts.tag}] gate: wrong item (memory picture) rejected`, (await fbClass(page)).includes('bad'), await fbText(page));
  await page.click('#gate-pic'); await page.click('#gate-rubbing');
  await page.click('#btn-gate-go');
  const s4 = await state(page);
  pass(`[${opts.tag}] gate: copper plate + rock rubbing completes the Pothole Trail`, s4.flags.gate && s4.bag.includes('core'));
  await page.click('#btn-action');   // back to the map
  pass(`[${opts.tag}] after the valley the game continues on the map (not a final ending)`, (await state(page)).scene === 'map');
}

/* ---------- the 9 data-driven stations ---------- */
async function playStations(page, lang, leaks, tag) {
  const MD = await page.evaluate(() => window.WQ.MECHDATA);
  const S = () => state(page);
  const openMech = async id => {
    const hs = await page.$$eval('.scenebox .hot', els => els.map(e => e.id));
    for (const h of hs) { await page.click('#'+h, {force:true}); if (await page.locator('#btn-ok').count() && !(await page.locator('.sheet .tile, #spot-new, #sort-0, #pipe-board, #proc-pluck, #g-0-0, #j9-board, #simon-pad, #path-board').count())) { await scan(page, `${id}-${h}`, lang, leaks); await page.click('#btn-ok'); } else break; }
    await scan(page, id+'-mech', lang, leaks);
  };
  const bad = async (name, id) => pass(`[${tag}] ${id}: ${name} rejected with feedback`, (await fbClass(page)).includes('bad'), await fbText(page));
  for (const id of ['a2','a4','a5','a6','b2','b3','b4','b5','b6']) {
    await enter(page, id); await scan(page, id, lang, leaks);
    await openMech(id);
    if (id === 'a2') {
      const at = async (x,y) => { await page.locator('#spot-new').scrollIntoViewIfNeeded(); const box = await page.locator('#spot-new').boundingBox(); await page.mouse.click(box.x + x/400*box.width, box.y + y/260*box.height); };
      await at(20, 240); await bad('a click on an unchanged spot', id);
      for (const g of MD.a2.targets) await at(g.x, g.y);
    }
    if (id === 'a4') {
      await page.click('#btn-mech-check'); await bad('unsorted samples', id);
      for (let i=0;i<6;i++) { await page.click('#sort-'+i); if (MD.a4.samples[i].ans === 1) await page.click('#sort-'+i); }
      await page.click('#sort-0'); await page.click('#btn-mech-check'); await bad('one sample in the wrong jar', id);
      await page.click('#sort-0'); await page.click('#btn-mech-check');
    }
    if (id === 'a5') {
      await page.click('#btn-mech-check'); await bad('a broken channel', id);
      for (const [r,c] of MD.a5.path) {
        for (let k=0;k<4;k++) { const st = await S(); if (st.st.a5.done) break; const rot = st.st.a5.rot[r][c], need = MD.a5.sol[r][c], type = MD.a5.tiles[r][c];
          if (type === 'S' ? rot%2 === need%2 : rot%4 === need) break; await page.click(`#pipe-${r}-${c}`); }
      }
    }
    if (id === 'a6') {
      for (const s of ['pluck','roast','wither','fire','roll','ball']) await page.click('#proc-'+s);
      await page.click('#btn-mech-check'); await bad('roasting before rolling', id);
      await page.click('[data-act="procReset"]');
      for (const s of MD.a6.steps.map(s=>s.id)) await page.click('#proc-'+s);
      await page.click('#btn-mech-check');
    }
    if (id === 'b2' || id === 'b4') {
      const G = MD[id].grid;
      for (let p=0;p<4;p++) { await page.click(`#g-${p}-0`); await page.click(`#g-${p}-0`); }
      await page.click('#btn-mech-check'); await bad('a duplicated column', id);
      await page.click('[data-act="gridReset"]');
      // a full but wrong permutation (rotate answer by one)
      for (let p=0;p<4;p++) { const th = G.answer[(p+1)%4]; await page.click(`#g-${p}-${th}`); await page.click(`#g-${p}-${th}`); }
      await page.click('#btn-mech-check'); await bad('a wrong assignment', id);
      await page.click('[data-act="gridReset"]');
      for (let p=0;p<4;p++) { const th = G.answer[p]; await page.click(`#g-${p}-${th}`); await page.click(`#g-${p}-${th}`); }
      await page.click('#btn-mech-check');
    }
    if (id === 'b3') {
      await page.click('#btn-mech-check'); await bad('an unsolved night view', id);
      for (let guard=0; guard<30; guard++) {
        const board = await page.$$eval('#j9-board button', els => els.map(e => +e.dataset.piece));
        const tray = await page.$$eval('#j9-tray button', els => els.map(e => +e.dataset.piece));
        const i = board.findIndex((p,k)=>p!==k); if (i<0) break;
        const j = board.indexOf(i);
        await page.locator('#j9-board button').nth(i).click();
        if (j>=0) await page.locator('#j9-board button').nth(j).click(); else await page.locator('#j9-tray button').nth(tray.indexOf(i)).click();
      }
      await page.click('#btn-mech-check');
    }
    if (id === 'b5') {
      let first = true;
      for (let round=0; round<3; round++) {
        await page.click('#btn-simon-listen');
        const seq = (await S()).st.b5.seq; await page.waitForTimeout(700 + seq.length*750 + 400);
        if (first) { await page.click('#simon-'+((seq[0]+1)%6)); await bad('a wrong note', id); first = false;
          await page.click('#btn-simon-listen'); await page.waitForTimeout(700 + seq.length*750 + 400); }
        for (const n of seq) await page.click('#simon-'+n);
      }
    }
    if (id === 'b6') {
      await page.click('#path-3-0'); await bad('a non-adjacent step', id);
      await page.click('#path-4-0'); await page.click('#path-4-1'); await bad('a step onto a cliff', id);
      await page.click('[data-act="pathReset"]');
      for (const [r,c] of [[5,1],[5,2],[5,3],[5,4],[4,4],[4,5],[3,5],[2,5],[1,5],[0,5]]) await page.click(`#path-${r}-${c}`);
    }
    const done = (await S()).st[id] && (await S()).st[id].done;
    pass(`[${tag}] ${id}: solved with the documented answer, reward item received`, done && (await S()).bag.includes('r_'+id), await fbText(page));
    await page.screenshot({ path: `${SHOTS}/${tag}_${id}_solved.png` });
    await page.click('#btn-ok');
    if (id === 'a6') {
      pass(`[${tag}] Route A ending does not show the feedback form yet`, (await page.locator(`a[href="${FORM}"]`).count()) === 0);
      await scan(page, 'routeEndA', lang, leaks);
      await page.click('#btn-route-map');
    } else if (id === 'b6') {
      await scan(page, 'ending', lang, leaks);
      const href = await page.locator('#modal-end-feedback').getAttribute('href');
      const fbtxt = await page.locator('.fbcard').innerText();
      pass(`[${tag}] all 11 places done → final ending invites feedback (message + form in new tab)`, href === FORM && (await page.locator('#modal-end-feedback').getAttribute('target')) === '_blank' && fbtxt.length > 150, fbtxt.slice(0,60).replace(/\n/g,' '));
      await page.screenshot({ path: `${SHOTS}/${tag}_ending.png` });
      await page.click('#btn-keep');
    } else {
      await page.click('#btn-stn-map');
    }
  }
  pass(`[${tag}] journey timeline shows 11 / 11 with every stop ticked`, (await page.locator('.jcount').innerText()).replace(/\s/g,'') === '11/11' && (await page.locator('.jchip.done').count()) + (await page.locator('.jchip.here').count()) === 12 && (await page.locator('.jchip.locked').count()) === 0);
  await page.reload();
  const fin = await S();
  const tab2 = await page.context().newPage(); await tab2.goto(FILE);
  const pickerFirst = await tab2.locator('#pick-en').count() === 1 && await tab2.locator('#pick-zh').count() === 1 && (await tab2.locator('.ob-card').innerText()).includes('選擇語言') && (await tab2.locator('.ob-card').innerText()).includes('Choose Your Language');
  pass(`[${tag}] reopening the game starts with the bilingual language picker`, pickerFirst);
  await tab2.click('#pick-en');
  const loginShown = await tab2.locator('#btn-login').count();
  const loginTxt = await tab2.locator('.ob-card').innerText().catch(()=>'');
  await tab2.click('#btn-login');
  pass(`[${tag}] reopening the game shows "welcome back" with name and nationality, then continues`, loginShown === 1 && loginTxt.includes('Tester') && (await tab2.locator('.jcount').count()) === 1, loginTxt.slice(0,80).replace(/\n/g,' '));
  await tab2.close();
  pass(`[${tag}] all progress survives a reload (11 / 11 places)`, await page.evaluate(() => ['station','a2','valley','a4','a5','a6','b2','b3','b4','b5','b6'].every(window.WQ.placeDone)) && fin.screen === 'game');
}

/* ---------------- Scenario A: English, desktop, full tutorial, every wrong path ---------------- */
{
  const { ctx, page } = await newPage({ width: 1280, height: 860 });
  const leaks = [];
  await onboarding(page, 'en', { tutorial: true, leaks });
  pass('[EN-desktop] onboarding: language → profile → 6-step tutorial → map', (await state(page)).screen === 'game' && (await state(page)).flags.tutorial);
  await scan(page, 'map', 'en', leaks);
  await page.click('#node-b3', {force:true});
  const lockTxt = await page.locator('.sheet-body').innerText();
  pass('[EN-desktop] map: a locked place shows its history and what unlocks it (no Enter button)', /Opens after/.test(lockTxt) && await page.locator('#btn-enter').count() === 0, lockTxt.slice(0,90).replace(/\n/g,' '));
  await page.click('#btn-ok');
  pass('[EN-desktop] map: locked nodes stay locked', (await state(page)).scene === 'map');
  pass('[EN-desktop] map: About Maokong history timeline shown', (await page.locator('#about-maokong li').count()) >= 6);
  pass('[EN-desktop] map: next-step guide points at Maokong Station', (await page.locator('#node-station.next').count()) === 1);
  pass('[EN-desktop] map: no feedback link before the end', (await page.locator(`a[href="${FORM}"]`).count()) === 0);
  await page.click('#btn-menu'); await scan(page, 'menu', 'en', leaks);
  pass('[EN-desktop] menu: no feedback link before the end', (await page.locator(`a[href="${FORM}"]`).count()) === 0);
  await close(page);
  await playStation(page, 'en', leaks, { tag: 'EN-desktop', extraWrong: true, switchLang: true });
  await page.click('#btn-bag'); await scan(page, 'bag', 'en', leaks); await close(page);
  await page.click('#btn-hint'); await scan(page, 'hint', 'en', leaks); await close(page);
  await page.click('#btn-talk'); await page.click('#ask-1'); await scan(page, 'dialog', 'en', leaks); await close(page);
  await playValley(page, 'en', leaks, { tag: 'EN-desktop' });
  await playStations(page, 'en', leaks, 'EN-desktop');
  pass('[EN-desktop] no Chinese text leaks into the English game (bilingual signs excepted)', leaks.length === 0, leaks.join(' || '));
  pass('[EN-desktop] no JavaScript errors', page.errors.length === 0, page.errors.join(' | '));
  await ctx.close();
}

/* ---------------- Scenario B: Traditional Chinese, desktop, tutorial skipped ---------------- */
{
  const { ctx, page } = await newPage({ width: 1366, height: 900 });
  await onboarding(page, 'zh', { tutorial: false });
  pass('[ZH-desktop] skip path: language → profile → skip → map', (await state(page)).screen === 'game' && (await state(page)).lang === 'zh');
  await playStation(page, 'zh', [], { tag: 'ZH-desktop' });
  await page.reload(); // reload in the valley
  pass('[ZH-desktop] reload in the valley keeps scene and items', (await state(page)).scene === 'valley' && (await state(page)).bag.includes('plate'));
  await playValley(page, 'zh', [], { tag: 'ZH-desktop' });
  await playStations(page, 'zh', [], 'ZH-desktop');
  pass('[ZH-desktop] no JavaScript errors', page.errors.length === 0, page.errors.join(' | '));
  await ctx.close();
}

/* ---------------- Scenario C: English, phone 390x844 with touch ---------------- */
{
  const { ctx, page } = await newPage({ width: 390, height: 844 }, { touch: true });
  const leaks = [];
  const overflow = async label => { const o = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth); if (o > 1) leaks.push(`overflow ${o}px at ${label}`); };
  await page.screenshot({ path: `${SHOTS}/mobile_1_language.png` });
  await onboarding(page, 'en', { tutorial: true, leaks });
  await overflow('map'); await page.screenshot({ path: `${SHOTS}/mobile_2_map.png` });
  await enter(page, 'station'); await overflow('station'); await page.screenshot({ path: `${SHOTS}/mobile_3_station.png` });
  await page.click('#btn-map');
  await playStation(page, 'en', leaks, { tag: 'EN-mobile' });
  await overflow('valley'); await page.screenshot({ path: `${SHOTS}/mobile_4_valley.png` });
  await playValley(page, 'en', leaks, { tag: 'EN-mobile' });
  await playStations(page, 'en', leaks, 'EN-mobile');
  pass('[EN-mobile] no horizontal overflow and no Chinese leaks', leaks.length === 0, leaks.join(' || '));
  pass('[EN-mobile] no JavaScript errors', page.errors.length === 0, page.errors.join(' | '));
  await ctx.close();
}

/* ---------------- Scenario D: localStorage blocked ---------------- */
{
  const { ctx, page } = await newPage({ width: 1280, height: 860 }, { blockStorage: true });
  const shown = await page.locator('#pick-en').isVisible();
  await onboarding(page, 'en', { tutorial: false });
  const warn = await page.locator('.storage-warn').count();
  await enter(page, 'station'); await page.click('#hot-frame'); const ok = await solveJigsaw(page); await page.click('#btn-jig-check');
  pass('[storage-blocked] game loads (no white screen), shows a warning and remains playable', shown && warn === 1 && ok && (await state(page)).flags.jig, page.errors.join(' | '));
  await ctx.close();
}

await browser.close();
const failed = results.filter(r => !r.ok);
fs.writeFileSync(SHOTS + '/results.json', JSON.stringify(results, null, 2));
console.log(`\n${results.length - failed.length}/${results.length} checks passed`);
process.exit(failed.length ? 1 : 0);
