// In a real browser: screenshot every tile button and check it shows the right slice of the reference image.
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import fs from 'fs';
const [FILE, OUT] = [ 'file://'+fs.realpathSync(process.argv[2]), process.argv[3] ]; fs.mkdirSync(OUT,{recursive:true});
const b = await chromium.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox']});
for (const vp of [{width:1280,height:900,tag:'desktop'},{width:390,height:844,tag:'mobile'}]) {
  const p = await (await b.newContext({viewport:vp, reducedMotion:'reduce', deviceScaleFactor:1})).newPage();
  await p.goto(FILE);
  await p.evaluate(() => localStorage.setItem('wanderquest-v3-save', JSON.stringify({v:3,lang:'en',screen:'game',scene:'station',flags:{tutorial:true},
    jig:{board:[...Array(16).keys()],tray:[16,17],swaps:0}, st:{b3:{board:[...Array(9).keys()],tray:[9,10]}}, bag:[],clues:[],seen:[],hints:{},tries:{},ev:[],histRead:true})));
  await p.reload(); await p.click('#hot-frame');
  const n1 = await p.locator('#jig-board button').count();
  for (let i=0;i<n1;i++) await p.locator('#jig-board button').nth(i).screenshot({path:`${OUT}/${vp.tag}_p1_${i}.png`});
  for (let i=0;i<2;i++) await p.locator('#jig-tray button').nth(i).screenshot({path:`${OUT}/${vp.tag}_p1_d${i}.png`});
  await p.locator('#jig-board').screenshot({path:`${OUT}/${vp.tag}_p1_board.png`});
  await p.click('#btn-close');
  await p.evaluate(() => { const s = JSON.parse(localStorage.getItem('wanderquest-v3-save')); s.flags.logic = true; s.scene='b3'; s.st.b2={done:true}; localStorage.setItem('wanderquest-v3-save', JSON.stringify(s)); });
  await p.reload(); await p.click('#hot-pavilion', {force:true});
  for (let i=0;i<9;i++) await p.locator('#j9-board button').nth(i).screenshot({path:`${OUT}/${vp.tag}_j9_${i}.png`});
  for (let i=0;i<2;i++) await p.locator('#j9-tray button').nth(i).screenshot({path:`${OUT}/${vp.tag}_j9_d${i}.png`});
  await p.locator('#j9-board').screenshot({path:`${OUT}/${vp.tag}_j9_board.png`});
  console.log(vp.tag, 'tiles captured', n1, '+ 9');
}
await b.close();
