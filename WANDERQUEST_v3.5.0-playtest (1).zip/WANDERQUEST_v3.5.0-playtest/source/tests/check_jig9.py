"""Render the 9-piece night picture + 2 day decoys and assert all pieces are visually distinct."""
import subprocess, sys, itertools, os, json
import numpy as np
from PIL import Image
d = sys.argv[1]; os.makedirs(d, exist_ok=True)
js = """const fs=require('fs'),vm=require('vm'),p=require('path');const ctx={};vm.createContext(ctx);
for(const f of ['content.js','stations-data.js','art.js','stations-art.js'])vm.runInContext(fs.readFileSync(p.join(process.argv[1],f),'utf8')+';globalThis.ART2=typeof ART2!=="undefined"?ART2:undefined;',ctx);
fs.writeFileSync(process.argv[2]+'/night.svg',ctx.ART2.NIGHT_SVG);ctx.ART2.DAY_SVG.forEach((s,i)=>fs.writeFileSync(process.argv[2]+'/day'+i+'.svg',s));"""
subprocess.run(['node','-e',js,os.path.join(os.path.dirname(__file__),'../src'),d],check=True)
subprocess.run(['rsvg-convert','-w','300','-h','300',f'{d}/night.svg','-o',f'{d}/night.png'],check=True)
for i in range(2): subprocess.run(['rsvg-convert','-w','100','-h','100',f'{d}/day{i}.svg','-o',f'{d}/day{i}.png'],check=True)
im=np.asarray(Image.open(f'{d}/night.png').convert('RGB')).astype(float)
T={f't{r*3+c}':im[r*100:(r+1)*100,c*100:(c+1)*100] for r in range(3) for c in range(3)}
for i in range(2): T[f'day{i}']=np.asarray(Image.open(f'{d}/day{i}.png').convert('RGB')).astype(float)
worst=min(((np.abs(T[a]-T[b]).mean(axis=2)>40).mean(),a,b) for a,b in itertools.combinations(T,2))
print('closest pair: %s/%s %.1f%% pixels differ'%(worst[1],worst[2],worst[0]*100))
sys.exit(0 if worst[0]>=0.06 else 1)
