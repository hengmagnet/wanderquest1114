// Exploratory "messy human" paths on a touch phone: close with ✕/backdrop/Esc, reopen, reload mid-modal, tap things out of order.
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import fs from 'fs';
const FILE='file://'+fs.realpathSync(process.argv[2]);
const b=await chromium.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox']});
const ctx=await b.newContext({reducedMotion:'reduce',viewport:{width:390,height:844},hasTouch:true,isMobile:true});
const p=await ctx.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message)); p.on('console',m=>m.type()==='error'&&errs.push(m.text()));
const st=()=>p.evaluate(()=>window.WQ.state);
const log=(m)=>console.log(m);
await p.goto(FILE);
await p.tap('#pick-zh'); await p.fill('#in-name','Explorer'); await p.selectOption('#in-nat','FR'); await p.tap('#btn-register'); while(await p.locator('#btn-hist-next').count()) await p.tap('#btn-hist-next'); await p.tap('#btn-hist-go'); await p.waitForTimeout(300);
// tutorial, messy: tap bag early, reload mid-tutorial
await p.tap('#btn-bag'); await p.keyboard.press('Escape');
await p.reload(); log('after reload in tutorial screen='+(await st()).screen+' tutNode='+await p.locator('#tut-node').count());
await p.tap('#tut-node'); await p.tap('#tut-hot'); await p.tap('#btn-close');
log('tut step after backdrop close: coach='+(await p.locator('#coach-text').innerText()));
await p.tap('#btn-bag'); await p.tap('#btn-close');
const t=p.locator('#tut-board button'); await t.nth(0).tap(); await t.nth(3).tap();
await p.tap('#btn-hint'); await p.tap('#btn-ok'); await p.tap('#btn-tut-go');
log('screen='+(await st()).screen);
// station, out of order
await p.tap('#node-valley',{force:true}); await p.tap('#btn-ok'); await p.tap('#node-station',{force:true}); await p.tap('#btn-enter');
await p.tap('#hot-cabinet'); await p.tap('#btn-close');
await p.tap('#hot-frame');
// solve jigsaw by taps, but close & reopen halfway, and reload with modal open
async function step(){const board=await p.$$eval('#jig-board button',e=>e.map(x=>+x.dataset.piece));const tray=await p.$$eval('#jig-tray button',e=>e.map(x=>+x.dataset.piece));const i=board.findIndex((v,k)=>v!==k);if(i<0)return false;const j=board.indexOf(i);await p.locator('#jig-board button').nth(i).tap();if(j>=0)await p.locator('#jig-board button').nth(j).tap();else await p.locator('#jig-tray button').nth(tray.indexOf(i)).tap();return true;}
for(let k=0;k<5;k++) await step();
await p.tap('#btn-close'); await p.tap('#hot-frame'); for(let k=0;k<3;k++) await step();
await p.reload(); log('reload with puzzle open -> scene='+(await st()).scene+' jig saved='+!!(await st()).jig);
await p.tap('#hot-frame'); while(await step()){}
await p.tap('#btn-jig-check'); log('jig solved='+(await st()).flags.jig);
// close with ✕ instead of Continue, then reopen the frame, then what's next?
await p.tap('#btn-close'); await p.tap('#hot-frame'); log('reopen solved frame modal ok='+await p.locator('#btn-ok').count()); await p.tap('#btn-ok');
log('objective: '+await p.locator('#objective-text').innerText());
log('npc: '+await p.locator('.npcbar p').innerText());
await p.tap('#btn-map'); await p.tap('#node-valley',{force:true}); log('valley place card (locked): '+(await p.locator('.sheet-body').innerText()).replace(/\n/g,' / ').slice(0,90)); await p.tap('#btn-ok'); await p.tap('#node-station',{force:true}); await p.tap('#btn-enter'); log('back in scene='+(await st()).scene); await p.tap('#hot-cabinet'); log('cabinet opens logic: '+await p.locator('#btn-logic-check').count());
await p.screenshot({path:process.argv[3]+'/explore_logic.png'});
await p.tap('#btn-close');
await p.tap('#btn-hint'); log('hint: '+(await p.locator('.bubble').innerText()).replace(/\n/g,' '));
console.log('errors:',errs);
await b.close();
