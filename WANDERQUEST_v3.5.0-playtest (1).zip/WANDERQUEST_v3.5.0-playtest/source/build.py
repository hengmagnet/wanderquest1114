"""Build dist/index.html: one self-contained file (CSS, JS, character images all inlined)."""
import base64, pathlib, re
R = pathlib.Path(__file__).parent
src = R / 'src'
img = {k: 'data:image/webp;base64,' + base64.b64encode((R/'assets'/f'{k}.webp').read_bytes()).decode() for k in ('mossy','pebble')}
css = (src/'style.css').read_text(encoding='utf-8')
engine = (src/'stations-engine.js').read_text(encoding='utf-8')
game = (src/'game.js').read_text(encoding='utf-8')
assert '/*@@STATIONS_ENGINE@@*/' in game
game = game.replace('/*@@STATIONS_ENGINE@@*/', engine)
js = '\n'.join([(src/f).read_text(encoding='utf-8') for f in ('content.js','stations-data.js','art.js','stations-art.js')] + [game])
assert '</script' not in js.lower(), 'script terminator inside JS'
version = re.search(r'const VERSION = "([^"]+)"', js).group(1)
html = f'''<!doctype html>
<html lang="zh-Hant">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="description" content="WANDERQUEST — a bilingual (繁中 / English) story puzzle game set in Maokong, Taipei. Playtest {version}.">
<meta name="theme-color" content="#16392f">
<title>WANDERQUEST · 記憶菌絲</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ctext y='.9em' font-size='90'%3E%F0%9F%8D%84%3C/text%3E%3C/svg%3E">
<style>
{css}
</style>
</head>
<body>
<div id="root"><noscript><p style="padding:20px">WANDERQUEST needs JavaScript. / 本遊戲需要啟用 JavaScript。</p></noscript></div>
<div id="modal"></div>
<div id="toast" role="status" aria-live="polite"></div>
<!-- {version} · single-file build · no external requests except the Google Form link -->
<script>
const IMG = {{ mossy: "{img['mossy']}", pebble: "{img['pebble']}" }};
{js}
</script>
</body>
</html>
'''
(R/'dist').mkdir(exist_ok=True)
(R/'dist'/'index.html').write_text(html, encoding='utf-8')
print('built dist/index.html', version, f'{len(html.encode())/1024:.0f} KB')
