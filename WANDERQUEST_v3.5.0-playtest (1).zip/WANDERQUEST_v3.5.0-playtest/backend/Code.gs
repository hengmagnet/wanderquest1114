/**
 * WANDERQUEST 後台收集程式（Google Apps Script）
 * 使用方式：在 Google 試算表中「擴充功能 → Apps Script」，把這整個檔案貼上，
 * 然後「部署 → 新增部署作業 → 網頁應用程式」，執行身分選「我」，存取權選「所有人」。
 *
 * 會自動建立兩張工作表：
 *   玩家總覽 Players ：每位玩家一列（依遊玩代碼更新）
 *   事件紀錄 Events  ：每個事件一列（註冊、完成每一站、路線完成、全部完成…）
 */

var SHEET_PLAYERS = '玩家總覽 Players';
var SHEET_EVENTS = '事件紀錄 Events';
var PLACES = ['station','a2','valley','a4','a5','a6','b2','b3','b4','b5','b6'];
var PLACE_NAMES = {
  station:'貓空站', a2:'小天空步道', valley:'壺穴步道', a4:'茶展中心步道', a5:'健康步道', a6:'茶研發推廣中心',
  b2:'樟樹步道', b3:'登高步道', b4:'杏花林', b5:'樟湖步道', b6:'貓空越嶺步道'
};
var EVENT_NAMES = {
  register:'註冊', login:'回訪登入', place_done:'完成地點', route_done:'完成路線', game_done:'全部完成', hint:'使用提示'
};
var PLAYER_HEADERS = ['遊玩代碼','姓名','國籍','語言','註冊時間','最後活動','完成地點數','目前位置','路線A完成','路線B完成','全部完成時間','實際遊玩分鐘（各站加總）','提示次數','嘗試次數','版本']
  .concat(PLACES.map(function(p){ return PLACE_NAMES[p] + '（分鐘）'; }))
  .concat(PLACES.map(function(p){ return PLACE_NAMES[p] + ' 完成時間'; }));
var EVENT_HEADERS = ['時間','遊玩代碼','姓名','國籍','事件','地點','該站花費（分鐘）','細節','版本'];

function doGet() {
  return ContentService.createTextOutput('WANDERQUEST collector is running. 後台收集程式運作中。');
}

function doPost(e) {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var d = JSON.parse(e.postData.contents);
    if (!d || d.app !== 'wanderquest' || !d.pid) return out('ignored');
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var players = sheet_(ss, SHEET_PLAYERS, PLAYER_HEADERS);
    var events = sheet_(ss, SHEET_EVENTS, EVENT_HEADERS);
    var ev = d.event || {};
    var mins = ev.type === 'place_done' ? min_(Number(ev.detail)) : '';
    events.appendRow([ts_(ev.t), s_(d.pid), s_(d.name), s_(d.nationality), EVENT_NAMES[ev.type] || s_(ev.type),
                      PLACE_NAMES[ev.place] || s_(ev.place), mins, ev.type === 'place_done' ? '' : s_(ev.detail), s_(d.v)]);
    upsertPlayer_(players, d);
    return out('ok');
  } catch (err) {
    return out('error: ' + err);
  } finally {
    lock.releaseLock();
  }
}

function upsertPlayer_(sh, d) {
  var done = d.done || {};
  var row = [s_(d.pid), s_(d.name), s_(d.nationality), d.lang === 'en' ? 'English' : '中文',
             ts_(d.registeredAt), ts_((d.event || {}).t), Number(d.doneCount) || 0, PLACE_NAMES[d.current] || s_(d.current),
             d.routeA ? '✓' : '', d.routeB ? '✓' : '', ts_(d.finishedAt), Number(d.activeMinutes) || 0,
             Number(d.hints) || 0, Number(d.tries) || 0, s_(d.v)]
            .concat(PLACES.map(function(p){ var sec = (d.seconds || {})[p]; return done[p] ? min_(sec || 0) : (sec ? min_(sec) + '（進行中）' : ''); }))
            .concat(PLACES.map(function(p){ return done[p] ? ts_(done[p]) : ''; }));
  var last = sh.getLastRow();
  if (last > 1) {
    var ids = sh.getRange(2, 1, last - 1, 1).getValues();
    for (var i = 0; i < ids.length; i++) {
      if (String(ids[i][0]) === String(d.pid)) {
        var old = sh.getRange(i + 2, 1, 1, row.length).getValues()[0];
        if (!row[4] && old[4]) row[4] = old[4];            // keep the original registration time
        sh.getRange(i + 2, 1, 1, row.length).setValues([row]);
        return;
      }
    }
  }
  sh.appendRow(row);
}

function sheet_(ss, name, headers) {
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold').setBackground('#e8f1d6');
    sh.setFrozenRows(1);
  }
  return sh;
}
function s_(v) { return v === undefined || v === null ? '' : String(v).slice(0, 200); }
function ts_(ms) { return ms ? Utilities.formatDate(new Date(Number(ms)), 'Asia/Taipei', 'yyyy-MM-dd HH:mm:ss') : ''; }
function out(t) { return ContentService.createTextOutput(t); }
function min_(sec) { return sec ? Math.round(sec / 6) / 10 : 0; }   // seconds -> minutes, 1 decimal
